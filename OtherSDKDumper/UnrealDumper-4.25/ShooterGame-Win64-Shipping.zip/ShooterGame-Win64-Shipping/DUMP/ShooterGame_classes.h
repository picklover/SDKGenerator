// Class ShooterGame.BTDecorator_HasLoSTo
// Size: 0x90 (Inherited: 0x68)
struct UBTDecorator_HasLoSTo : UBTDecorator {
	struct FBlackboardKeySelector EnemyKey; // 0x68(0x28)
};

// Class ShooterGame.BTTask_FindPickup
// Size: 0x98 (Inherited: 0x98)
struct UBTTask_FindPickup : UBTTask_BlackboardBase {
};

// Class ShooterGame.BTTask_FindPointNearEnemy
// Size: 0x98 (Inherited: 0x98)
struct UBTTask_FindPointNearEnemy : UBTTask_BlackboardBase {
};

// Class ShooterGame.ShooterAIController
// Size: 0x348 (Inherited: 0x328)
struct AShooterAIController : AAIController {
	struct UBlackboardComponent* BlackboardComp; // 0x328(0x08)
	struct UBehaviorTreeComponent* BehaviorComp; // 0x330(0x08)
	char pad_338[0x10]; // 0x338(0x10)

	void ShootEnemy(); // Function ShooterGame.ShooterAIController.ShootEnemy // (Final|Native|Public|BlueprintCallable) // @ game+0xfcf370
	bool FindClosestEnemyWithLOS(struct AShooterCharacter* ExcludeEnemy); // Function ShooterGame.ShooterAIController.FindClosestEnemyWithLOS // (Final|Native|Public|BlueprintCallable) // @ game+0xfcecf0
	void FindClosestEnemy(); // Function ShooterGame.ShooterAIController.FindClosestEnemy // (Final|Native|Public|BlueprintCallable) // @ game+0xfcecd0
};

// Class ShooterGame.ShooterCharacter
// Size: 0x6a0 (Inherited: 0x4c0)
struct AShooterCharacter : ACharacter {
	struct USkeletalMeshComponent* Mesh1P; // 0x4b8(0x08)
	struct FName WeaponAttachPoint; // 0x4c0(0x08)
	struct TArray<struct AShooterWeapon*> DefaultInventoryClasses; // 0x4c8(0x10)
	struct TArray<struct AShooterWeapon*> Inventory; // 0x4d8(0x10)
	struct AShooterWeapon* CurrentWeapon; // 0x4e8(0x08)
	struct FTakeHitInfo LastTakeHitInfo; // 0x4f0(0x128)
	float TargetingSpeedModifier; // 0x61c(0x04)
	char bIsTargeting : 1; // 0x620(0x01)
	float RunningSpeedModifier; // 0x624(0x04)
	char bWantsToRun : 1; // 0x628(0x01)
	char pad_628_2 : 6; // 0x628(0x01)
	char pad_629[0xf]; // 0x629(0x0f)
	struct TArray<struct UMaterialInstanceDynamic*> MeshMIDs; // 0x638(0x10)
	struct UAnimMontage* DeathAnim; // 0x648(0x08)
	struct USoundCue* DeathSound; // 0x650(0x08)
	struct UParticleSystem* RespawnFX; // 0x658(0x08)
	struct USoundCue* RespawnSound; // 0x660(0x08)
	struct USoundCue* LowHealthSound; // 0x668(0x08)
	struct USoundCue* RunLoopSound; // 0x670(0x08)
	struct USoundCue* RunStopSound; // 0x678(0x08)
	struct USoundCue* TargetingSound; // 0x680(0x08)
	struct UAudioComponent* RunLoopAC; // 0x688(0x08)
	struct UAudioComponent* LowHealthWarningPlayer; // 0x690(0x08)
	char bIsDying : 1; // 0x698(0x01)
	char pad_698_1 : 7; // 0x698(0x01)
	char pad_699[0x3]; // 0x699(0x03)
	float Health; // 0x69c(0x04)

	void ServerSetTargeting(bool bNewTargeting); // Function ShooterGame.ShooterCharacter.ServerSetTargeting // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfcf1e0
	void ServerSetRunning(bool bNewRunning, bool bToggle); // Function ShooterGame.ShooterCharacter.ServerSetRunning // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfcf0d0
	void ServerEquipWeapon(struct AShooterWeapon* NewWeapon); // Function ShooterGame.ShooterCharacter.ServerEquipWeapon // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfcf010
	void OnRep_LastTakeHitInfo(); // Function ShooterGame.ShooterCharacter.OnRep_LastTakeHitInfo // (Final|Native|Protected) // @ game+0xfceff0
	void OnRep_CurrentWeapon(struct AShooterWeapon* LastWeapon); // Function ShooterGame.ShooterCharacter.OnRep_CurrentWeapon // (Final|Native|Protected) // @ game+0xfcef60
	bool IsTargeting(); // Function ShooterGame.ShooterCharacter.IsTargeting // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfcef30
	bool IsRunning(); // Function ShooterGame.ShooterCharacter.IsRunning // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfcef00
	bool IsFirstPerson(); // Function ShooterGame.ShooterCharacter.IsFirstPerson // (Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfceed0
	bool IsFiring(); // Function ShooterGame.ShooterCharacter.IsFiring // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfceea0
	struct AShooterWeapon* GetWeapon(); // Function ShooterGame.ShooterCharacter.GetWeapon // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfcee70
	float GetTargetingSpeedModifier(); // Function ShooterGame.ShooterCharacter.GetTargetingSpeedModifier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfcee40
	float GetRunningSpeedModifier(); // Function ShooterGame.ShooterCharacter.GetRunningSpeedModifier // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfcee10
	struct FRotator GetAimOffsets(); // Function ShooterGame.ShooterCharacter.GetAimOffsets // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xfcedd0
};

// Class ShooterGame.ShooterBot
// Size: 0x6b0 (Inherited: 0x6a0)
struct AShooterBot : AShooterCharacter {
	struct UBehaviorTree* BotBehavior; // 0x6a0(0x08)
	char pad_6A8[0x8]; // 0x6a8(0x08)
};

// Class ShooterGame.ShooterCharacterMovement
// Size: 0xaf0 (Inherited: 0xaf0)
struct UShooterCharacterMovement : UCharacterMovementComponent {
};

// Class ShooterGame.ShooterChatWidgetStyle
// Size: 0x938 (Inherited: 0x30)
struct UShooterChatWidgetStyle : USlateWidgetStyleContainerBase {
	struct FShooterChatStyle ChatStyle; // 0x30(0x908)
};

// Class ShooterGame.ShooterPlayerController
// Size: 0x5e8 (Inherited: 0x570)
struct AShooterPlayerController : APlayerController {
	char bInfiniteAmmo : 1; // 0x570(0x01)
	char bInfiniteClip : 1; // 0x570(0x01)
	char bHealthRegen : 1; // 0x570(0x01)
	char bGodMode : 1; // 0x570(0x01)
	char pad_570_4 : 4; // 0x570(0x01)
	char pad_571[0x68]; // 0x571(0x68)
	bool bAnalogFireTrigger; // 0x5d9(0x01)
	char pad_5DA[0x2]; // 0x5da(0x02)
	float FireTriggerThreshold; // 0x5dc(0x04)
	char pad_5E0[0x8]; // 0x5e0(0x08)

	void Suicide(); // Function ShooterGame.ShooterPlayerController.Suicide // (Exec|Native|Public) // @ game+0xfd42a0
	void SimulateInputKey(struct FKey Key, bool bPressed); // Function ShooterGame.ShooterPlayerController.SimulateInputKey // (Final|Native|Public|BlueprintCallable) // @ game+0xfd4170
	void SetGodMode(bool bEnable); // Function ShooterGame.ShooterPlayerController.SetGodMode // (Final|Exec|Native|Public) // @ game+0xfd40e0
	void ServerSuicide(); // Function ShooterGame.ShooterPlayerController.ServerSuicide // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0xfd4090
	void ServerSay(struct FString Msg); // Function ShooterGame.ShooterPlayerController.ServerSay // (Net|Native|Event|Public|NetServer|NetValidate) // @ game+0xfd3e90
	void ServerCheat(struct FString Msg); // Function ShooterGame.ShooterPlayerController.ServerCheat // (Net|NetReliableNative|Event|Public|NetServer|NetValidate) // @ game+0xfd3a20
	void Say(struct FString Msg); // Function ShooterGame.ShooterPlayerController.Say // (Exec|Native|Public) // @ game+0xfd3980
	void OnLeaderboardReadComplete(bool bWasSuccessful); // Function ShooterGame.ShooterPlayerController.OnLeaderboardReadComplete // (Final|Native|Public) // @ game+0xfd3810
	void ClientStartOnlineGame(); // Function ShooterGame.ShooterPlayerController.ClientStartOnlineGame // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xfd35b0
	void ClientSetSpectatorCamera(struct FVector CameraLocation, struct FRotator CameraRotation); // Function ShooterGame.ShooterPlayerController.ClientSetSpectatorCamera // (Net|NetReliableNative|Event|Public|HasDefaults|NetClient) // @ game+0xfd34c0
	void ClientSendRoundEndEvent(bool bIsWinner, int32_t ExpendedTimeInSeconds); // Function ShooterGame.ShooterPlayerController.ClientSendRoundEndEvent // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xfd33f0
	void ClientGameStarted(); // Function ShooterGame.ShooterPlayerController.ClientGameStarted // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xfd33d0
	void ClientEndOnlineGame(); // Function ShooterGame.ShooterPlayerController.ClientEndOnlineGame // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xfd33b0
};

// Class ShooterGame.ShooterCheatManager
// Size: 0x88 (Inherited: 0x88)
struct UShooterCheatManager : UCheatManager {

	void ToggleMatchTimer(); // Function ShooterGame.ShooterCheatManager.ToggleMatchTimer // (Final|Exec|Native|Public) // @ game+0xfcf3f0
	void ToggleInfiniteClip(); // Function ShooterGame.ShooterCheatManager.ToggleInfiniteClip // (Final|Exec|Native|Public) // @ game+0xfcf3d0
	void ToggleInfiniteAmmo(); // Function ShooterGame.ShooterCheatManager.ToggleInfiniteAmmo // (Final|Exec|Native|Public) // @ game+0xfcf3b0
	void SpawnBot(); // Function ShooterGame.ShooterCheatManager.SpawnBot // (Final|Exec|Native|Public) // @ game+0xfcf390
	void ForceMatchStart(); // Function ShooterGame.ShooterCheatManager.ForceMatchStart // (Final|Exec|Native|Public) // @ game+0xfcedb0
	void Cheat(struct FString Msg); // Function ShooterGame.ShooterCheatManager.Cheat // (Final|Exec|Native|Public) // @ game+0xfcec30
	void ChangeTeam(int32_t NewTeamNumber); // Function ShooterGame.ShooterCheatManager.ChangeTeam // (Final|Exec|Native|Public) // @ game+0xfceba0
};

// Class ShooterGame.ShooterDamageType
// Size: 0x68 (Inherited: 0x40)
struct UShooterDamageType : UDamageType {
	struct FCanvasIcon KillIcon; // 0x40(0x18)
	struct UForceFeedbackEffect* HitForceFeedback; // 0x58(0x08)
	struct UForceFeedbackEffect* KilledForceFeedback; // 0x60(0x08)
};

// Class ShooterGame.ShooterDemoSpectator
// Size: 0x598 (Inherited: 0x570)
struct AShooterDemoSpectator : APlayerController {
	char pad_570[0x28]; // 0x570(0x28)
};

// Class ShooterGame.ShooterEngine
// Size: 0xd70 (Inherited: 0xd70)
struct UShooterEngine : UGameEngine {
};

// Class ShooterGame.ShooterExplosionEffect
// Size: 0x2e0 (Inherited: 0x220)
struct AShooterExplosionEffect : AActor {
	struct UParticleSystem* ExplosionFX; // 0x220(0x08)
	struct UPointLightComponent* ExplosionLight; // 0x228(0x08)
	float ExplosionLightFadeOut; // 0x230(0x04)
	char pad_234[0x4]; // 0x234(0x04)
	struct USoundCue* ExplosionSound; // 0x238(0x08)
	struct FDecalData Decal; // 0x240(0x10)
	struct FHitResult SurfaceHit; // 0x250(0x88)
	char pad_2D8[0x8]; // 0x2d8(0x08)
};

// Class ShooterGame.ShooterGameMode
// Size: 0x368 (Inherited: 0x308)
struct AShooterGameMode : AGameMode {
	struct APawn* BotPawnClass; // 0x308(0x08)
	int32_t WarmupTime; // 0x310(0x04)
	int32_t RoundTime; // 0x314(0x04)
	int32_t TimeBetweenMatches; // 0x318(0x04)
	int32_t KillScore; // 0x31c(0x04)
	int32_t DeathScore; // 0x320(0x04)
	float DamageSelfScale; // 0x324(0x04)
	int32_t MaxBots; // 0x328(0x04)
	char pad_32C[0x4]; // 0x32c(0x04)
	struct TArray<struct AShooterAIController*> BotControllers; // 0x330(0x10)
	struct AShooterPlayerController* PlatformPlayerControllerClass; // 0x340(0x08)
	char pad_348[0x10]; // 0x348(0x10)
	struct TArray<struct AShooterPickup*> LevelPickups; // 0x358(0x10)

	void SetAllowBots(bool bInAllowBots, int32_t InMaxBots); // Function ShooterGame.ShooterGameMode.SetAllowBots // (Final|Exec|Native|Public) // @ game+0xfcf2a0
	void FinishMatch(); // Function ShooterGame.ShooterGameMode.FinishMatch // (Final|Exec|Native|Public) // @ game+0xfced90
};

// Class ShooterGame.ShooterGame_FreeForAll
// Size: 0x370 (Inherited: 0x368)
struct AShooterGame_FreeForAll : AShooterGameMode {
	struct AShooterPlayerState* WinnerPlayerState; // 0x368(0x08)
};

// Class ShooterGame.ShooterGame_Menu
// Size: 0x2c0 (Inherited: 0x2c0)
struct AShooterGame_Menu : AGameModeBase {
};

// Class ShooterGame.ShooterGame_TeamDeathMatch
// Size: 0x370 (Inherited: 0x368)
struct AShooterGame_TeamDeathMatch : AShooterGameMode {
	char pad_368[0x8]; // 0x368(0x08)
};

// Class ShooterGame.ShooterGameInstance
// Size: 0x450 (Inherited: 0x1a8)
struct UShooterGameInstance : UGameInstance {
	struct FString WelcomeScreenMap; // 0x1a8(0x10)
	struct FString MainMenuMap; // 0x1b8(0x10)
	char pad_1C8[0x288]; // 0x1c8(0x288)
};

// Class ShooterGame.ShooterGameSession
// Size: 0x340 (Inherited: 0x238)
struct AShooterGameSession : AGameSession {
	char pad_238[0x108]; // 0x238(0x108)
};

// Class ShooterGame.ShooterGameState
// Size: 0x3d8 (Inherited: 0x290)
struct AShooterGameState : AGameState {
	int32_t NumTeams; // 0x290(0x04)
	char pad_294[0x4]; // 0x294(0x04)
	struct TArray<int32_t> TeamScores; // 0x298(0x10)
	int32_t RemainingTime; // 0x2a8(0x04)
	bool bTimerPaused; // 0x2ac(0x01)
	char pad_2AD[0x3]; // 0x2ad(0x03)
	struct FString ActivityId; // 0x2b0(0x10)
	bool bEnableGameFeedback; // 0x2c0(0x01)
	char pad_2C1[0x117]; // 0x2c1(0x117)
};

// Class ShooterGame.ShooterGameUserSettings
// Size: 0x140 (Inherited: 0x120)
struct UShooterGameUserSettings : UGameUserSettings {
	int32_t GraphicsQuality; // 0x120(0x04)
	int32_t NVIDIAReflex; // 0x124(0x04)
	int32_t LatencyFlashIndicator; // 0x128(0x04)
	int32_t FramerateVisibility; // 0x12c(0x04)
	int32_t GameToRenderVisibility; // 0x130(0x04)
	int32_t GameLatencyVisibility; // 0x134(0x04)
	int32_t RenderLatencyVisibility; // 0x138(0x04)
	bool bIsLanMatch; // 0x13c(0x01)
	bool bIsDedicatedServer; // 0x13d(0x01)
	bool bIsForceSystemResolution; // 0x13e(0x01)
	char pad_13F[0x1]; // 0x13f(0x01)
};

// Class ShooterGame.ShooterGameViewportClient
// Size: 0x3b0 (Inherited: 0x360)
struct UShooterGameViewportClient : UGameViewportClient {
	char pad_360[0x50]; // 0x360(0x50)
};

// Class ShooterGame.ShooterHUD
// Size: 0x738 (Inherited: 0x310)
struct AShooterHUD : AHUD {
	char pad_310[0x38]; // 0x310(0x38)
	struct FCanvasIcon HitNotifyIcon[0x8]; // 0x348(0xc0)
	struct FCanvasIcon KillsBg; // 0x408(0x18)
	struct FCanvasIcon TimePlaceBg; // 0x420(0x18)
	struct FCanvasIcon PrimaryWeapBg; // 0x438(0x18)
	struct FCanvasIcon SecondaryWeapBg; // 0x450(0x18)
	struct FCanvasIcon Crosshair[0x5]; // 0x468(0x78)
	struct FCanvasIcon HitNotifyCrosshair; // 0x4e0(0x18)
	struct FCanvasIcon DeathMessagesBg; // 0x4f8(0x18)
	struct FCanvasIcon HealthBarBg; // 0x510(0x18)
	struct FCanvasIcon HealthBar; // 0x528(0x18)
	struct FCanvasIcon HealthIcon; // 0x540(0x18)
	struct FCanvasIcon KillsIcon; // 0x558(0x18)
	struct FCanvasIcon KilledIcon; // 0x570(0x18)
	struct FCanvasIcon TimerIcon; // 0x588(0x18)
	struct FCanvasIcon PlaceIcon; // 0x5a0(0x18)
	char pad_5B8[0x90]; // 0x5b8(0x90)
	struct UTexture2D* HitNotifyTexture; // 0x648(0x08)
	struct UTexture2D* HUDMainTexture; // 0x650(0x08)
	struct UTexture2D* HUDAssets02Texture; // 0x658(0x08)
	struct UTexture2D* LowHealthOverlayTexture; // 0x660(0x08)
	struct UFont* BigFont; // 0x668(0x08)
	struct UFont* NormalFont; // 0x670(0x08)
	char pad_678[0xc0]; // 0x678(0xc0)
};

// Class ShooterGame.ShooterImpactEffect
// Size: 0x348 (Inherited: 0x220)
struct AShooterImpactEffect : AActor {
	struct UParticleSystem* DefaultFX; // 0x220(0x08)
	struct UParticleSystem* ConcreteFX; // 0x228(0x08)
	struct UParticleSystem* DirtFX; // 0x230(0x08)
	struct UParticleSystem* WaterFX; // 0x238(0x08)
	struct UParticleSystem* MetalFX; // 0x240(0x08)
	struct UParticleSystem* WoodFX; // 0x248(0x08)
	struct UParticleSystem* GlassFX; // 0x250(0x08)
	struct UParticleSystem* GrassFX; // 0x258(0x08)
	struct UParticleSystem* FleshFX; // 0x260(0x08)
	struct USoundCue* DefaultSound; // 0x268(0x08)
	struct USoundCue* ConcreteSound; // 0x270(0x08)
	struct USoundCue* DirtSound; // 0x278(0x08)
	struct USoundCue* WaterSound; // 0x280(0x08)
	struct USoundCue* MetalSound; // 0x288(0x08)
	struct USoundCue* WoodSound; // 0x290(0x08)
	struct USoundCue* GlassSound; // 0x298(0x08)
	struct USoundCue* GrassSound; // 0x2a0(0x08)
	struct USoundCue* FleshSound; // 0x2a8(0x08)
	struct FDecalData DefaultDecal; // 0x2b0(0x10)
	struct FHitResult SurfaceHit; // 0x2c0(0x88)
};

// Class ShooterGame.ShooterLocalPlayer
// Size: 0x260 (Inherited: 0x258)
struct UShooterLocalPlayer : ULocalPlayer {
	struct UShooterPersistentUser* PersistentUser; // 0x258(0x08)
};

// Class ShooterGame.ShooterMenuItemWidgetStyle
// Size: 0x1d0 (Inherited: 0x30)
struct UShooterMenuItemWidgetStyle : USlateWidgetStyleContainerBase {
	struct FShooterMenuItemStyle MenuItemStyle; // 0x30(0x1a0)
};

// Class ShooterGame.ShooterMenuSoundsWidgetStyle
// Size: 0x68 (Inherited: 0x30)
struct UShooterMenuSoundsWidgetStyle : USlateWidgetStyleContainerBase {
	struct FShooterMenuSoundsStyle SoundsStyle; // 0x30(0x38)
};

// Class ShooterGame.ShooterMenuWidgetStyle
// Size: 0x230 (Inherited: 0x30)
struct UShooterMenuWidgetStyle : USlateWidgetStyleContainerBase {
	struct FShooterMenuStyle MenuStyle; // 0x30(0x200)
};

// Class ShooterGame.ShooterOnlineSessionClient
// Size: 0x1c8 (Inherited: 0x1c8)
struct UShooterOnlineSessionClient : UOnlineSessionClient {
};

// Class ShooterGame.ShooterOptionsWidgetStyle
// Size: 0x68 (Inherited: 0x30)
struct UShooterOptionsWidgetStyle : USlateWidgetStyleContainerBase {
	struct FShooterOptionsStyle OptionsStyle; // 0x30(0x38)
};

// Class ShooterGame.ShooterPersistentUser
// Size: 0x70 (Inherited: 0x28)
struct UShooterPersistentUser : USaveGame {
	int32_t Kills; // 0x28(0x04)
	int32_t Deaths; // 0x2c(0x04)
	int32_t Wins; // 0x30(0x04)
	int32_t Losses; // 0x34(0x04)
	int32_t BulletsFired; // 0x38(0x04)
	int32_t RocketsFired; // 0x3c(0x04)
	int32_t BotsCount; // 0x40(0x04)
	bool bIsRecordingDemos; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float Gamma; // 0x48(0x04)
	float AimSensitivity; // 0x4c(0x04)
	bool bInvertedYAxis; // 0x50(0x01)
	bool bVibrationOpt; // 0x51(0x01)
	char pad_52[0x1e]; // 0x52(0x1e)
};

// Class ShooterGame.ShooterPickup
// Size: 0x260 (Inherited: 0x220)
struct AShooterPickup : AActor {
	struct UParticleSystemComponent* PickupPSC; // 0x220(0x08)
	struct UParticleSystem* ActiveFX; // 0x228(0x08)
	struct UParticleSystem* RespawningFX; // 0x230(0x08)
	struct USoundCue* PickupSound; // 0x238(0x08)
	struct USoundCue* RespawnSound; // 0x240(0x08)
	float RespawnTime; // 0x248(0x04)
	char bIsActive : 1; // 0x24c(0x01)
	char pad_24C_1 : 7; // 0x24c(0x01)
	char pad_24D[0x3]; // 0x24d(0x03)
	struct AShooterCharacter* PickedUpBy; // 0x250(0x08)
	char pad_258[0x8]; // 0x258(0x08)

	void OnRespawnEvent(); // Function ShooterGame.ShooterPickup.OnRespawnEvent // (Event|Protected|BlueprintEvent) // @ game+0x1305ca0
	void OnRep_IsActive(); // Function ShooterGame.ShooterPickup.OnRep_IsActive // (Final|Native|Protected) // @ game+0xfd3900
	void OnPickedUpEvent(); // Function ShooterGame.ShooterPickup.OnPickedUpEvent // (Event|Protected|BlueprintEvent) // @ game+0x1305ca0
};

// Class ShooterGame.ShooterPickup_Ammo
// Size: 0x270 (Inherited: 0x260)
struct AShooterPickup_Ammo : AShooterPickup {
	int32_t AmmoClips; // 0x260(0x04)
	char pad_264[0x4]; // 0x264(0x04)
	struct AShooterWeapon* WeaponType; // 0x268(0x08)
};

// Class ShooterGame.ShooterPickup_Health
// Size: 0x268 (Inherited: 0x260)
struct AShooterPickup_Health : AShooterPickup {
	int32_t Health; // 0x260(0x04)
	char pad_264[0x4]; // 0x264(0x04)
};

// Class ShooterGame.ShooterPlayerCameraManager
// Size: 0x2820 (Inherited: 0x2810)
struct AShooterPlayerCameraManager : APlayerCameraManager {
	char pad_2810[0x10]; // 0x2810(0x10)
};

// Class ShooterGame.ShooterPlayerController_Menu
// Size: 0x570 (Inherited: 0x570)
struct AShooterPlayerController_Menu : APlayerController {
};

// Class ShooterGame.ShooterPlayerState
// Size: 0x348 (Inherited: 0x320)
struct AShooterPlayerState : APlayerState {
	int32_t TeamNumber; // 0x320(0x04)
	int32_t NumKills; // 0x324(0x04)
	int32_t NumDeaths; // 0x328(0x04)
	int32_t NumBulletsFired; // 0x32c(0x04)
	int32_t NumRocketsFired; // 0x330(0x04)
	char bQuitter : 1; // 0x334(0x01)
	char pad_334_1 : 7; // 0x334(0x01)
	char pad_335[0x3]; // 0x335(0x03)
	struct FString MatchID; // 0x338(0x10)

	void OnRep_TeamColor(); // Function ShooterGame.ShooterPlayerState.OnRep_TeamColor // (Final|Native|Public) // @ game+0xfd3960
	void InformAboutKill(struct AShooterPlayerState* KillerPlayerState, struct UDamageType* KillerDamageType, struct AShooterPlayerState* KilledPlayerState); // Function ShooterGame.ShooterPlayerState.InformAboutKill // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xfd3620
	void BroadcastDeath(struct AShooterPlayerState* KillerPlayerState, struct UDamageType* KillerDamageType, struct AShooterPlayerState* KilledPlayerState); // Function ShooterGame.ShooterPlayerState.BroadcastDeath // (Net|NetReliableNative|Event|NetMulticast|Public) // @ game+0xfd32a0
};

// Class ShooterGame.ShooterProjectile
// Size: 0x270 (Inherited: 0x220)
struct AShooterProjectile : AActor {
	struct UProjectileMovementComponent* MovementComp; // 0x220(0x08)
	struct USphereComponent* CollisionComp; // 0x228(0x08)
	struct UParticleSystemComponent* ParticleComp; // 0x230(0x08)
	struct AShooterExplosionEffect* ExplosionTemplate; // 0x238(0x08)
	char pad_240[0x28]; // 0x240(0x28)
	bool bExploded; // 0x268(0x01)
	char pad_269[0x7]; // 0x269(0x07)

	void OnRep_Exploded(); // Function ShooterGame.ShooterProjectile.OnRep_Exploded // (Final|Native|Protected) // @ game+0xfd38c0
	void OnImpact(struct FHitResult& HitResult); // Function ShooterGame.ShooterProjectile.OnImpact // (Final|Native|Public|HasOutParms) // @ game+0xfd3730
};

// Class ShooterGame.ShooterReplicationGraph
// Size: 0x5d0 (Inherited: 0x4b0)
struct UShooterReplicationGraph : UReplicationGraph {
	struct TArray<struct UObject*> SpatializedClasses; // 0x4a8(0x10)
	struct TArray<struct UObject*> NonSpatializedChildClasses; // 0x4b8(0x10)
	struct TArray<struct UObject*> AlwaysRelevantClasses; // 0x4c8(0x10)
	struct UReplicationGraphNode_GridSpatialization2D* GridNode; // 0x4d8(0x08)
	struct UReplicationGraphNode_ActorList* AlwaysRelevantNode; // 0x4e0(0x08)
	char pad_4F0[0xe0]; // 0x4f0(0xe0)
};

// Class ShooterGame.ShooterReplicationGraphNode_AlwaysRelevant_ForConnection
// Size: 0x290 (Inherited: 0x50)
struct UShooterReplicationGraphNode_AlwaysRelevant_ForConnection : UReplicationGraphNode {
	char pad_50[0x220]; // 0x50(0x220)
	struct AActor* LastPawn; // 0x270(0x08)
	struct TArray<struct FAlwaysRelevantActorInfo> PastRelevantActors; // 0x278(0x10)
	char pad_288[0x8]; // 0x288(0x08)
};

// Class ShooterGame.ShooterReplicationGraphNode_PlayerStateFrequencyLimiter
// Size: 0x78 (Inherited: 0x50)
struct UShooterReplicationGraphNode_PlayerStateFrequencyLimiter : UReplicationGraphNode {
	char pad_50[0x28]; // 0x50(0x28)
};

// Class ShooterGame.ShooterScoreboardWidgetStyle
// Size: 0x150 (Inherited: 0x30)
struct UShooterScoreboardWidgetStyle : USlateWidgetStyleContainerBase {
	struct FShooterScoreboardStyle ScoreboardStyle; // 0x30(0x120)
};

// Class ShooterGame.ShooterSpectatorPawn
// Size: 0x2a8 (Inherited: 0x2a8)
struct AShooterSpectatorPawn : ASpectatorPawn {
};

// Class ShooterGame.ShooterTeamStart
// Size: 0x258 (Inherited: 0x250)
struct AShooterTeamStart : APlayerStart {
	int32_t SpawnTeam; // 0x250(0x04)
	char bNotForPlayers : 1; // 0x254(0x01)
	char bNotForBots : 1; // 0x254(0x01)
	char pad_254_2 : 6; // 0x254(0x01)
	char pad_255[0x3]; // 0x255(0x03)
};

// Class ShooterGame.ShooterTestControllerBase
// Size: 0x70 (Inherited: 0x30)
struct UShooterTestControllerBase : UGauntletTestController {
	char pad_30[0x40]; // 0x30(0x40)
};

// Class ShooterGame.ShooterTestControllerBasicDedicatedServerTest
// Size: 0x70 (Inherited: 0x70)
struct UShooterTestControllerBasicDedicatedServerTest : UShooterTestControllerBase {
};

// Class ShooterGame.ShooterTestControllerBootTest
// Size: 0x38 (Inherited: 0x30)
struct UShooterTestControllerBootTest : UGauntletTestControllerBootTest {
	char pad_30[0x8]; // 0x30(0x08)
};

// Class ShooterGame.ShooterTestControllerDedicatedServerTest
// Size: 0x70 (Inherited: 0x70)
struct UShooterTestControllerDedicatedServerTest : UShooterTestControllerBase {
};

// Class ShooterGame.ShooterTestControllerListenServerClient
// Size: 0x70 (Inherited: 0x70)
struct UShooterTestControllerListenServerClient : UShooterTestControllerBase {
};

// Class ShooterGame.ShooterTestControllerListenServerHost
// Size: 0x70 (Inherited: 0x70)
struct UShooterTestControllerListenServerHost : UShooterTestControllerBase {
};

// Class ShooterGame.ShooterTestControllerListenServerQuickMatchClient
// Size: 0x70 (Inherited: 0x70)
struct UShooterTestControllerListenServerQuickMatchClient : UShooterTestControllerBase {
};

// Class ShooterGame.ShooterWeapon
// Size: 0x4a0 (Inherited: 0x220)
struct AShooterWeapon : AActor {
	struct FCanvasIcon PrimaryIcon; // 0x220(0x18)
	struct FCanvasIcon SecondaryIcon; // 0x238(0x18)
	struct FCanvasIcon PrimaryClipIcon; // 0x250(0x18)
	struct FCanvasIcon SecondaryClipIcon; // 0x268(0x18)
	float AmmoIconsCount; // 0x280(0x04)
	int32_t PrimaryClipIconOffset; // 0x284(0x04)
	int32_t SecondaryClipIconOffset; // 0x288(0x04)
	char pad_28C[0x4]; // 0x28c(0x04)
	struct FCanvasIcon Crosshair[0x5]; // 0x290(0x78)
	struct FCanvasIcon AimingCrosshair[0x5]; // 0x308(0x78)
	bool UseLaserDot; // 0x380(0x01)
	bool UseCustomCrosshair; // 0x381(0x01)
	bool UseCustomAimingCrosshair; // 0x382(0x01)
	bool bHideCrosshairWhileNotAiming; // 0x383(0x01)
	float TimerIntervalAdjustment; // 0x384(0x04)
	bool bAllowAutomaticWeaponCatchup; // 0x388(0x01)
	char pad_389[0x7]; // 0x389(0x07)
	struct AShooterCharacter* MyPawn; // 0x390(0x08)
	struct FWeaponData WeaponConfig; // 0x398(0x18)
	struct USkeletalMeshComponent* Mesh1P; // 0x3b0(0x08)
	struct USkeletalMeshComponent* Mesh3P; // 0x3b8(0x08)
	struct UAudioComponent* FireAC; // 0x3c0(0x08)
	struct FName MuzzleAttachPoint; // 0x3c8(0x08)
	struct UParticleSystem* MuzzleFX; // 0x3d0(0x08)
	struct UParticleSystemComponent* MuzzlePSC; // 0x3d8(0x08)
	struct UParticleSystemComponent* MuzzlePSCSecondary; // 0x3e0(0x08)
	struct UMatineeCameraShake* FireCameraShake; // 0x3e8(0x08)
	struct UForceFeedbackEffect* FireForceFeedback; // 0x3f0(0x08)
	struct USoundCue* FireSound; // 0x3f8(0x08)
	struct USoundCue* FireLoopSound; // 0x400(0x08)
	struct USoundCue* FireFinishSound; // 0x408(0x08)
	struct USoundCue* OutOfAmmoSound; // 0x410(0x08)
	struct USoundCue* ReloadSound; // 0x418(0x08)
	struct FWeaponAnim ReloadAnim; // 0x420(0x10)
	struct USoundCue* EquipSound; // 0x430(0x08)
	struct FWeaponAnim EquipAnim; // 0x438(0x10)
	struct FWeaponAnim FireAnim; // 0x448(0x10)
	char bLoopedMuzzleFX : 1; // 0x458(0x01)
	char bLoopedFireSound : 1; // 0x458(0x01)
	char bLoopedFireAnim : 1; // 0x458(0x01)
	char pad_458_3 : 3; // 0x458(0x01)
	char bPendingReload : 1; // 0x458(0x01)
	char pad_458_7 : 1; // 0x458(0x01)
	char pad_459[0x17]; // 0x459(0x17)
	int32_t CurrentAmmo; // 0x470(0x04)
	int32_t CurrentAmmoInClip; // 0x474(0x04)
	int32_t BurstCounter; // 0x478(0x04)
	char pad_47C[0x24]; // 0x47c(0x24)

	void ServerStopReload(); // Function ShooterGame.ShooterWeapon.ServerStopReload // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfd4040
	void ServerStopFire(); // Function ShooterGame.ShooterWeapon.ServerStopFire // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfd3ff0
	void ServerStartReload(); // Function ShooterGame.ShooterWeapon.ServerStartReload // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfd3fa0
	void ServerStartFire(); // Function ShooterGame.ShooterWeapon.ServerStartFire // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfd3f50
	void ServerHandleFiring(); // Function ShooterGame.ShooterWeapon.ServerHandleFiring // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfd3ae0
	void OnRep_Reload(); // Function ShooterGame.ShooterWeapon.OnRep_Reload // (Final|Native|Protected) // @ game+0xfd3940
	void OnRep_MyPawn(); // Function ShooterGame.ShooterWeapon.OnRep_MyPawn // (Final|Native|Protected) // @ game+0xfd3920
	void OnRep_BurstCounter(); // Function ShooterGame.ShooterWeapon.OnRep_BurstCounter // (Final|Native|Protected) // @ game+0xfd38a0
	struct AShooterCharacter* GetPawnOwner(); // Function ShooterGame.ShooterWeapon.GetPawnOwner // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xfd35f0
	void ClientStartReload(); // Function ShooterGame.ShooterWeapon.ClientStartReload // (Net|NetReliableNative|Event|Public|NetClient) // @ game+0xfd35d0
};

// Class ShooterGame.ShooterWeapon_Instant
// Size: 0x4f8 (Inherited: 0x4a0)
struct AShooterWeapon_Instant : AShooterWeapon {
	struct FInstantWeaponData InstantConfig; // 0x4a0(0x28)
	struct AShooterImpactEffect* ImpactTemplate; // 0x4c8(0x08)
	struct UParticleSystem* TrailFX; // 0x4d0(0x08)
	struct FName TrailTargetParam; // 0x4d8(0x08)
	struct FInstantHitInfo HitNotify; // 0x4e0(0x14)
	char pad_4F4[0x4]; // 0x4f4(0x04)

	void ServerNotifyMiss(struct FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float ReticleSpread); // Function ShooterGame.ShooterWeapon_Instant.ServerNotifyMiss // (Net|Native|Event|Protected|NetServer|NetValidate) // @ game+0xfd3d10
	void ServerNotifyHit(struct FHitResult Impact, struct FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float ReticleSpread); // Function ShooterGame.ShooterWeapon_Instant.ServerNotifyHit // (Net|NetReliableNative|Event|Protected|NetServer|NetValidate) // @ game+0xfd3b30
	void OnRep_HitNotify(); // Function ShooterGame.ShooterWeapon_Instant.OnRep_HitNotify // (Final|Native|Protected) // @ game+0xfd38e0
};

// Class ShooterGame.ShooterWeapon_Projectile
// Size: 0x4c0 (Inherited: 0x4a0)
struct AShooterWeapon_Projectile : AShooterWeapon {
	struct FProjectileWeaponData ProjectileConfig; // 0x4a0(0x20)

	void ServerFireProjectile(struct FVector Origin, struct FVector_NetQuantizeNormal ShootDir); // Function ShooterGame.ShooterWeapon_Projectile.ServerFireProjectile // (Net|NetReliableNative|Event|Protected|NetServer|HasDefaults|NetValidate) // @ game+0xfd4720
};

// Class ShooterGame.SoundNodeLocalPlayer
// Size: 0x48 (Inherited: 0x48)
struct USoundNodeLocalPlayer : USoundNode {
};

