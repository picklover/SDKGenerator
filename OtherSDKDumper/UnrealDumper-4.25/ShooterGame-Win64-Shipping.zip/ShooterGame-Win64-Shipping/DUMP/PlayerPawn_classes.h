// BlueprintGeneratedClass PlayerPawn.PlayerPawn_C
// Size: 0x6a0 (Inherited: 0x6a0)
struct APlayerPawn_C : AShooterCharacter {
};

