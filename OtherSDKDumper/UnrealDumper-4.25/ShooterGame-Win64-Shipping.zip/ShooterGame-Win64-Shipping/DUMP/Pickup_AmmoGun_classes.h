// BlueprintGeneratedClass Pickup_AmmoGun.Pickup_AmmoGun_C
// Size: 0x270 (Inherited: 0x270)
struct APickup_AmmoGun_C : AShooterPickup_Ammo {
};

