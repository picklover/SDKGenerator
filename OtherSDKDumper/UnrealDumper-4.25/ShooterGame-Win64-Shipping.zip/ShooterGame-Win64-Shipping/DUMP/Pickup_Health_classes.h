// BlueprintGeneratedClass Pickup_Health.Pickup_Health_C
// Size: 0x268 (Inherited: 0x268)
struct APickup_Health_C : AShooterPickup_Health {
};

