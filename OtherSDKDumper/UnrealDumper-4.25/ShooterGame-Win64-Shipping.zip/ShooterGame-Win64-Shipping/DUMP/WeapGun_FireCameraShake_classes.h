// BlueprintGeneratedClass WeapGun_FireCameraShake.WeapGun_FireCameraShake_C
// Size: 0x1b0 (Inherited: 0x1b0)
struct UWeapGun_FireCameraShake_C : UMatineeCameraShake {
};

