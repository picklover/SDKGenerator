// Class OculusInput.OculusHandComponent
// Size: 0x8a0 (Inherited: 0x800)
struct UOculusHandComponent : UPoseableMeshComponent {
	enum class EOculusHandType SkeletonType; // 0x800(0x01)
	enum class EOculusHandType MeshType; // 0x801(0x01)
	enum class EConfidenceBehavior ConfidenceBehavior; // 0x802(0x01)
	enum class ESystemGestureBehavior SystemGestureBehavior; // 0x803(0x01)
	char pad_804[0x4]; // 0x804(0x04)
	struct UMaterialInterface* SystemGestureMaterial; // 0x808(0x08)
	bool bInitializePhysics; // 0x810(0x01)
	bool bUpdateHandScale; // 0x811(0x01)
	char pad_812[0x6]; // 0x812(0x06)
	struct UMaterialInterface* MaterialOverride; // 0x818(0x08)
	struct TMap<enum class EBone, struct FName> BoneNameMappings; // 0x820(0x50)
	struct TArray<struct FOculusCapsuleCollider> CollisionCapsules; // 0x870(0x10)
	bool bSkeletalMeshInitialized; // 0x880(0x01)
	char pad_881[0x1f]; // 0x881(0x1f)
};

// Class OculusInput.OculusInputFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UOculusInputFunctionLibrary : UBlueprintFunctionLibrary {

	bool IsPointerPoseValid(enum class EOculusHandType DeviceHand, int32_t ControllerIndex); // Function OculusInput.OculusInputFunctionLibrary.IsPointerPoseValid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xe0f340
	bool IsHandTrackingEnabled(); // Function OculusInput.OculusInputFunctionLibrary.IsHandTrackingEnabled // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xe0f310
	struct TArray<struct FOculusCapsuleCollider> InitializeHandPhysics(enum class EOculusHandType SkeletonType, struct USkinnedMeshComponent* HandComponent, float WorldToMeters); // Function OculusInput.OculusInputFunctionLibrary.InitializeHandPhysics // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xe0f1c0
	enum class ETrackingConfidence GetTrackingConfidence(enum class EOculusHandType DeviceHand, int32_t ControllerIndex); // Function OculusInput.OculusInputFunctionLibrary.GetTrackingConfidence // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xe0f0f0
	struct FTransform GetPointerPose(enum class EOculusHandType DeviceHand, int32_t ControllerIndex); // Function OculusInput.OculusInputFunctionLibrary.GetPointerPose // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xe0eff0
	bool GetHandSkeletalMesh(struct USkeletalMesh* HandSkeletalMesh, enum class EOculusHandType SkeletonType, enum class EOculusHandType MeshType, float WorldToMeters); // Function OculusInput.OculusInputFunctionLibrary.GetHandSkeletalMesh // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xe0eea0
	float GetHandScale(enum class EOculusHandType DeviceHand, int32_t ControllerIndex); // Function OculusInput.OculusInputFunctionLibrary.GetHandScale // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xe0edd0
	enum class EOculusHandType GetDominantHand(int32_t ControllerIndex); // Function OculusInput.OculusInputFunctionLibrary.GetDominantHand // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xe0ed40
	struct FQuat GetBoneRotation(enum class EOculusHandType DeviceHand, enum class EBone BoneId, int32_t ControllerIndex); // Function OculusInput.OculusInputFunctionLibrary.GetBoneRotation // (Final|Native|Static|Public|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xe0ec30
	struct FString GetBoneName(enum class EBone BoneId); // Function OculusInput.OculusInputFunctionLibrary.GetBoneName // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xe0eb60
};

