// Class PropertyAccess.PropertyAccess
// Size: 0x28 (Inherited: 0x28)
struct UPropertyAccess : UInterface {
};

// Class PropertyAccess.PropertyEventBroadcaster
// Size: 0x28 (Inherited: 0x28)
struct UPropertyEventBroadcaster : UInterface {
};

// Class PropertyAccess.PropertyEventSubscriber
// Size: 0x28 (Inherited: 0x28)
struct UPropertyEventSubscriber : UInterface {
};

