// BlueprintGeneratedClass TaskAlwaysTrue.TaskAlwaysTrue_C
// Size: 0xb0 (Inherited: 0xa8)
struct UTaskAlwaysTrue_C : UBTTask_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa8(0x08)

	void ReceiveExecute(struct AActor* OwnerActor); // Function TaskAlwaysTrue.TaskAlwaysTrue_C.ReceiveExecute // (Event|Protected|BlueprintEvent) // @ game+0x1305ca0
	void ExecuteUbergraph_TaskAlwaysTrue(int32_t EntryPoint); // Function TaskAlwaysTrue.TaskAlwaysTrue_C.ExecuteUbergraph_TaskAlwaysTrue // (Final|UbergraphFunction) // @ game+0x1305ca0
};

