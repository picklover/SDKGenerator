// BlueprintGeneratedClass DmgType_Instant.DmgType_Instant_C
// Size: 0x68 (Inherited: 0x68)
struct UDmgType_Instant_C : UShooterDamageType {
};

