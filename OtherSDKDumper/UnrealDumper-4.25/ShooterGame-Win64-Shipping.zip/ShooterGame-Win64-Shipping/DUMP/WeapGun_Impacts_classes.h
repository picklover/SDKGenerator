// BlueprintGeneratedClass WeapGun_Impacts.WeapGun_Impacts_C
// Size: 0x350 (Inherited: 0x348)
struct AWeapGun_Impacts_C : AShooterImpactEffect {
	struct USceneComponent* DefaultSceneRoot; // 0x348(0x08)
};

