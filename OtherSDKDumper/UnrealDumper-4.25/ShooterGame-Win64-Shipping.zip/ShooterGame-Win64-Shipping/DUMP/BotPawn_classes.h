// BlueprintGeneratedClass BotPawn.BotPawn_C
// Size: 0x6b0 (Inherited: 0x6b0)
struct ABotPawn_C : AShooterBot {
};

