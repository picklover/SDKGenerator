// ScriptStruct Overlay.OverlayItem
// Size: 0x28 (Inherited: 0x00)
struct FOverlayItem {
	struct FTimespan StartTime; // 0x00(0x08)
	struct FTimespan EndTime; // 0x08(0x08)
	struct FString Text; // 0x10(0x10)
	struct FVector2D Position; // 0x20(0x08)
};

