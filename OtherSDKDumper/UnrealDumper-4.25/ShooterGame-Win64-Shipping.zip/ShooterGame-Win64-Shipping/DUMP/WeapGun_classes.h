// BlueprintGeneratedClass WeapGun.WeapGun_C
// Size: 0x4f8 (Inherited: 0x4f8)
struct AWeapGun_C : AShooterWeapon_Instant {
};

