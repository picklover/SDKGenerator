// BlueprintGeneratedClass Sanctuary_Audio.Sanctuary_Audio_C
// Size: 0x258 (Inherited: 0x228)
struct ASanctuary_Audio_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	struct USoundCue* OneShot Sound; // 0x230(0x08)
	float Min Distance; // 0x238(0x04)
	float Max Distance; // 0x23c(0x04)
	struct FTimerHandle Spawn OneShots Handle; // 0x240(0x08)
	struct AAmbientSound* InteriorAmbience_ExecuteUbergraph_Sanctuary_Audio_RefProperty; // 0x248(0x08)
	struct AAmbientSound* ExteriorAmbience_ExecuteUbergraph_Sanctuary_Audio_RefProperty; // 0x250(0x08)

	void BndEvt__AudioTrigger_Interior_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function Sanctuary_Audio.Sanctuary_Audio_C.BndEvt__AudioTrigger_Interior_K2Node_ActorBoundEvent_0_ActorBeginOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1305ca0
	void BndEvt__AudioTrigger_Balcony_01_K2Node_ActorBoundEvent_5_ActorBeginOverlapSignature__DelegateSignature(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function Sanctuary_Audio.Sanctuary_Audio_C.BndEvt__AudioTrigger_Balcony_01_K2Node_ActorBoundEvent_5_ActorBeginOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1305ca0
	void BndEvt__AudioTrigger_Balcony_02_2_K2Node_ActorBoundEvent_6_ActorBeginOverlapSignature__DelegateSignature(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function Sanctuary_Audio.Sanctuary_Audio_C.BndEvt__AudioTrigger_Balcony_02_2_K2Node_ActorBoundEvent_6_ActorBeginOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1305ca0
	void BndEvt__AudioTrigger_Balcony_01_K2Node_ActorBoundEvent_7_ActorEndOverlapSignature__DelegateSignature(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function Sanctuary_Audio.Sanctuary_Audio_C.BndEvt__AudioTrigger_Balcony_01_K2Node_ActorBoundEvent_7_ActorEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1305ca0
	void BndEvt__AudioTrigger_Balcony_02_2_K2Node_ActorBoundEvent_8_ActorEndOverlapSignature__DelegateSignature(struct AActor* OverlappedActor, struct AActor* OtherActor); // Function Sanctuary_Audio.Sanctuary_Audio_C.BndEvt__AudioTrigger_Balcony_02_2_K2Node_ActorBoundEvent_8_ActorEndOverlapSignature__DelegateSignature // (BlueprintEvent) // @ game+0x1305ca0
	void PlayOneShots(); // Function Sanctuary_Audio.Sanctuary_Audio_C.PlayOneShots // (BlueprintCallable|BlueprintEvent) // @ game+0x1305ca0
	void SpawnOneShot(); // Function Sanctuary_Audio.Sanctuary_Audio_C.SpawnOneShot // (BlueprintCallable|BlueprintEvent) // @ game+0x1305ca0
	void ReceiveBeginPlay(); // Function Sanctuary_Audio.Sanctuary_Audio_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x1305ca0
	void ExecuteUbergraph_Sanctuary_Audio(int32_t EntryPoint); // Function Sanctuary_Audio.Sanctuary_Audio_C.ExecuteUbergraph_Sanctuary_Audio // (Final|UbergraphFunction|HasDefaults) // @ game+0x1305ca0
};

