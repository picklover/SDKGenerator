// BlueprintGeneratedClass BotShootEnemy.BotShootEnemy_C
// Size: 0xa0 (Inherited: 0x98)
struct UBotShootEnemy_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)

	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function BotShootEnemy.BotShootEnemy_C.ReceiveTick // (Event|Protected|BlueprintEvent) // @ game+0x1305ca0
	void ExecuteUbergraph_BotShootEnemy(int32_t EntryPoint); // Function BotShootEnemy.BotShootEnemy_C.ExecuteUbergraph_BotShootEnemy // (Final|UbergraphFunction) // @ game+0x1305ca0
};

