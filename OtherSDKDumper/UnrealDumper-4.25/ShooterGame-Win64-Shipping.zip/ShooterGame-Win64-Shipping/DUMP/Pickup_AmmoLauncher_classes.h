// BlueprintGeneratedClass Pickup_AmmoLauncher.Pickup_AmmoLauncher_C
// Size: 0x270 (Inherited: 0x270)
struct APickup_AmmoLauncher_C : AShooterPickup_Ammo {
};

