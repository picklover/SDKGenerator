// Enum SteamVR.ESteamVRTrackedDeviceType
enum class ESteamVRTrackedDeviceType : uint8 {
	Controller = 0,
	TrackingReference = 1,
	Other = 2,
	Invalid = 3,
	ESteamVRTrackedDeviceType_MAX = 4
};

