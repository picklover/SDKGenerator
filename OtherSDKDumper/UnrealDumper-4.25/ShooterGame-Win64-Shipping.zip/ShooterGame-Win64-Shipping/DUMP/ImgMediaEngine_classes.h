// Class ImgMediaEngine.ImgMediaPlaybackComponent
// Size: 0xd8 (Inherited: 0xb0)
struct UImgMediaPlaybackComponent : UActorComponent {
	float Width; // 0xb0(0x04)
	float LODBias; // 0xb4(0x04)
	char pad_B8[0x20]; // 0xb8(0x20)
};

