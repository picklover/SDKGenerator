// Class SignificanceManager.SignificanceManager
// Size: 0x120 (Inherited: 0x28)
struct USignificanceManager : UObject {
	char pad_28[0xe0]; // 0x28(0xe0)
	struct FSoftClassPath SignificanceManagerClassName; // 0x108(0x18)
};

