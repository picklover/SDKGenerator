// Class DeveloperSettings.DeveloperSettings
// Size: 0x38 (Inherited: 0x28)
struct UDeveloperSettings : UObject {
	char pad_28[0x10]; // 0x28(0x10)
};

