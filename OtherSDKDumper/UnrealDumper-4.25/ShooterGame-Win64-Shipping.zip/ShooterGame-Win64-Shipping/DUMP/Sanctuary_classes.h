// BlueprintGeneratedClass Sanctuary.Sanctuary_C
// Size: 0x238 (Inherited: 0x228)
struct ASanctuary_C : ALevelScriptActor {
	struct TArray<struct AActor*> Locations; // 0x228(0x10)
};

