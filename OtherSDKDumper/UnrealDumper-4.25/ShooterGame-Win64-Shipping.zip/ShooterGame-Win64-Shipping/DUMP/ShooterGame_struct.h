// Enum ShooterGame.EOnlineMode
enum class EOnlineMode : uint8 {
	Offline = 0,
	LAN = 1,
	Online = 2,
	EOnlineMode_MAX = 3
};

// Enum ShooterGame.EClassRepNodeMapping
enum class EClassRepNodeMapping : uint8 {
	NotRouted = 0,
	RelevantAllConnections = 1,
	Spatialize_Static = 2,
	Spatialize_Dynamic = 3,
	Spatialize_Dormancy = 4,
	EClassRepNodeMapping_MAX = 5
};

// Enum ShooterGame.EShooterPhysMaterialType
enum class EShooterPhysMaterialType : uint8 {
	Unknown = 0,
	Concrete = 1,
	Dirt = 2,
	Water = 3,
	Metal = 4,
	Wood = 5,
	Grass = 6,
	Glass = 7,
	Flesh = 8,
	EShooterPhysMaterialType_MAX = 9
};

// ScriptStruct ShooterGame.ShooterChatStyle
// Size: 0x908 (Inherited: 0x08)
struct FShooterChatStyle : FSlateWidgetStyle {
	struct FEditableTextBoxStyle TextEntryStyle; // 0x08(0x7f8)
	struct FSlateBrush BackingBrush; // 0x800(0x88)
	struct FSlateColor BoxBorderColor; // 0x888(0x28)
	struct FSlateColor TextColor; // 0x8b0(0x28)
	struct FSlateSound RxMessgeSound; // 0x8d8(0x18)
	struct FSlateSound TxMessgeSound; // 0x8f0(0x18)
};

// ScriptStruct ShooterGame.ShooterMenuItemStyle
// Size: 0x1a0 (Inherited: 0x08)
struct FShooterMenuItemStyle : FSlateWidgetStyle {
	struct FSlateBrush BackgroundBrush; // 0x08(0x88)
	struct FSlateBrush LeftArrowImage; // 0x90(0x88)
	struct FSlateBrush RightArrowImage; // 0x118(0x88)
};

// ScriptStruct ShooterGame.ShooterMenuSoundsStyle
// Size: 0x38 (Inherited: 0x08)
struct FShooterMenuSoundsStyle : FSlateWidgetStyle {
	struct FSlateSound StartGameSound; // 0x08(0x18)
	struct FSlateSound ExitGameSound; // 0x20(0x18)
};

// ScriptStruct ShooterGame.ShooterMenuStyle
// Size: 0x200 (Inherited: 0x08)
struct FShooterMenuStyle : FSlateWidgetStyle {
	struct FSlateBrush HeaderBackgroundBrush; // 0x08(0x88)
	struct FSlateBrush LeftBackgroundBrush; // 0x90(0x88)
	struct FSlateBrush RightBackgroundBrush; // 0x118(0x88)
	struct FSlateSound MenuEnterSound; // 0x1a0(0x18)
	struct FSlateSound MenuBackSound; // 0x1b8(0x18)
	struct FSlateSound OptionChangeSound; // 0x1d0(0x18)
	struct FSlateSound MenuItemChangeSound; // 0x1e8(0x18)
};

// ScriptStruct ShooterGame.ShooterOptionsStyle
// Size: 0x38 (Inherited: 0x08)
struct FShooterOptionsStyle : FSlateWidgetStyle {
	struct FSlateSound AcceptChangesSound; // 0x08(0x18)
	struct FSlateSound DiscardChangesSound; // 0x20(0x18)
};

// ScriptStruct ShooterGame.ShooterScoreboardStyle
// Size: 0x120 (Inherited: 0x08)
struct FShooterScoreboardStyle : FSlateWidgetStyle {
	struct FSlateBrush ItemBorderBrush; // 0x08(0x88)
	struct FSlateColor KillStatColor; // 0x90(0x28)
	struct FSlateColor DeathStatColor; // 0xb8(0x28)
	struct FSlateColor ScoreStatColor; // 0xe0(0x28)
	struct FSlateSound PlayerChangeSound; // 0x108(0x18)
};

// ScriptStruct ShooterGame.TakeHitInfo
// Size: 0x128 (Inherited: 0x00)
struct FTakeHitInfo {
	float ActualDamage; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UObject* DamageTypeClass; // 0x08(0x08)
	struct TWeakObjectPtr<struct AShooterCharacter> PawnInstigator; // 0x10(0x08)
	struct TWeakObjectPtr<struct AActor> DamageCauser; // 0x18(0x08)
	int32_t DamageEventClassID; // 0x20(0x04)
	char bKilled : 1; // 0x24(0x01)
	char pad_24_1 : 7; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	char EnsureReplicationByte; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FDamageEvent GeneralDamageEvent; // 0x30(0x10)
	struct FPointDamageEvent PointDamageEvent; // 0x40(0xa8)
	struct FRadialDamageEvent RadialDamageEvent; // 0xe8(0x40)
};

// ScriptStruct ShooterGame.DecalData
// Size: 0x10 (Inherited: 0x00)
struct FDecalData {
	struct UMaterial* DecalMaterial; // 0x00(0x08)
	float DecalSize; // 0x08(0x04)
	float LifeSpan; // 0x0c(0x04)
};

// ScriptStruct ShooterGame.WeaponAnim
// Size: 0x10 (Inherited: 0x00)
struct FWeaponAnim {
	struct UAnimMontage* Pawn1P; // 0x00(0x08)
	struct UAnimMontage* Pawn3P; // 0x08(0x08)
};

// ScriptStruct ShooterGame.WeaponData
// Size: 0x18 (Inherited: 0x00)
struct FWeaponData {
	bool bInfiniteAmmo; // 0x00(0x01)
	bool bInfiniteClip; // 0x01(0x01)
	char pad_2[0x2]; // 0x02(0x02)
	int32_t MaxAmmo; // 0x04(0x04)
	int32_t AmmoPerClip; // 0x08(0x04)
	int32_t InitialClips; // 0x0c(0x04)
	float TimeBetweenShots; // 0x10(0x04)
	float NoAnimReloadDuration; // 0x14(0x04)
};

// ScriptStruct ShooterGame.InstantWeaponData
// Size: 0x28 (Inherited: 0x00)
struct FInstantWeaponData {
	float WeaponSpread; // 0x00(0x04)
	float TargetingSpreadMod; // 0x04(0x04)
	float FiringSpreadIncrement; // 0x08(0x04)
	float FiringSpreadMax; // 0x0c(0x04)
	float WeaponRange; // 0x10(0x04)
	int32_t HitDamage; // 0x14(0x04)
	struct UDamageType* DamageType; // 0x18(0x08)
	float ClientSideHitLeeway; // 0x20(0x04)
	float AllowedViewDotHitDir; // 0x24(0x04)
};

// ScriptStruct ShooterGame.InstantHitInfo
// Size: 0x14 (Inherited: 0x00)
struct FInstantHitInfo {
	struct FVector Origin; // 0x00(0x0c)
	float ReticleSpread; // 0x0c(0x04)
	int32_t RandomSeed; // 0x10(0x04)
};

// ScriptStruct ShooterGame.ProjectileWeaponData
// Size: 0x20 (Inherited: 0x00)
struct FProjectileWeaponData {
	struct AShooterProjectile* ProjectileClass; // 0x00(0x08)
	float ProjectileLife; // 0x08(0x04)
	int32_t ExplosionDamage; // 0x0c(0x04)
	float ExplosionRadius; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct UDamageType* DamageType; // 0x18(0x08)
};

