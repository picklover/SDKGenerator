// BlueprintGeneratedClass WeapLauncher.WeapLauncher_C
// Size: 0x4c0 (Inherited: 0x4c0)
struct AWeapLauncher_C : AShooterWeapon_Projectile {
};

