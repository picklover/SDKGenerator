// BlueprintGeneratedClass BotSearchEnemyLOS.BotSearchEnemyLOS_C
// Size: 0xa0 (Inherited: 0x98)
struct UBotSearchEnemyLOS_C : UBTService_BlueprintBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x98(0x08)

	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function BotSearchEnemyLOS.BotSearchEnemyLOS_C.ReceiveTick // (Event|Protected|BlueprintEvent) // @ game+0x1305ca0
	void ExecuteUbergraph_BotSearchEnemyLOS(int32_t EntryPoint); // Function BotSearchEnemyLOS.BotSearchEnemyLOS_C.ExecuteUbergraph_BotSearchEnemyLOS // (Final|UbergraphFunction) // @ game+0x1305ca0
};

