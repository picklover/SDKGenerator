// BlueprintGeneratedClass ProjRocket_Explosion.ProjRocket_Explosion_C
// Size: 0x2e0 (Inherited: 0x2e0)
struct AProjRocket_Explosion_C : AShooterExplosionEffect {
};

