// ScriptStruct FieldSystemEngine.FieldObjectCommands
// Size: 0x30 (Inherited: 0x00)
struct FFieldObjectCommands {
	struct TArray<struct FName> TargetNames; // 0x00(0x10)
	struct TArray<struct UFieldNodeBase*> RootNodes; // 0x10(0x10)
	struct TArray<struct UFieldSystemMetaData*> MetaDatas; // 0x20(0x10)
};

