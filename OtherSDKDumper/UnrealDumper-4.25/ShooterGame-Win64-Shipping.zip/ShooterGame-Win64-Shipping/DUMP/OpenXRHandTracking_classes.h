// Class OpenXRHandTracking.LiveLinkOpenXRHandTrackingSourceFactory
// Size: 0x38 (Inherited: 0x28)
struct ULiveLinkOpenXRHandTrackingSourceFactory : ULiveLinkSourceFactory {
	char pad_28[0x10]; // 0x28(0x10)
};

// Class OpenXRHandTracking.OpenXRHandTrackingLiveLinkRemapAsset
// Size: 0x80 (Inherited: 0x28)
struct UOpenXRHandTrackingLiveLinkRemapAsset : ULiveLinkRetargetAsset {
	bool bHasMetacarpals; // 0x28(0x01)
	bool bRetargetRotationOnly; // 0x29(0x01)
	enum class EQuatSwizzleAxisB SwizzleX; // 0x2a(0x01)
	enum class EQuatSwizzleAxisB SwizzleY; // 0x2b(0x01)
	enum class EQuatSwizzleAxisB SwizzleZ; // 0x2c(0x01)
	enum class EQuatSwizzleAxisB SwizzleW; // 0x2d(0x01)
	char pad_2E[0x2]; // 0x2e(0x02)
	struct TMap<struct FName, struct FName> HandTrackingBoneNameMap; // 0x30(0x50)
};

