// Enum Reflex.EReflexMode
enum class EReflexMode : uint8 {
	Disabled = 0,
	Enabled = 1,
	EnabledPlusBoost = 3,
	EReflexMode_MAX = 4
};

