// AnimBlueprintGeneratedClass HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C
// Size: 0x1060 (Inherited: 0x2c0)
struct UHeroTPP_AnimBlueprint_C : UAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpace_2; // 0x2c8(0xe8)
	struct FAnimNode_ApplyAdditive AnimGraphNode_ApplyAdditive; // 0x3b0(0xc8)
	struct FAnimNode_Slot AnimGraphNode_Slot_2; // 0x478(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend; // 0x4c0(0xc0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x580(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose; // 0x5c8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2; // 0x720(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose; // 0x748(0x28)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x770(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9; // 0x7a0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8; // 0x7c8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7; // 0x7f0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6; // 0x818(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5; // 0x840(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4; // 0x868(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x890(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x8b8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x8e0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4; // 0x908(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5; // 0x988(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpace; // 0x9b8(0xe8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0xaa0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0xad0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0xb50(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0xb80(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0xc00(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0xc30(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0xcb0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0xce0(0xb0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace; // 0xd90(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace; // 0xdb0(0x20)
	struct FAnimNode_Fabrik AnimGraphNode_Fabrik; // 0xdd0(0x190)
	float AimPitch; // 0xf60(0x04)
	float AimYaw; // 0xf64(0x04)
	float Speed; // 0xf68(0x04)
	float Direction; // 0xf6c(0x04)
	bool IsJumping; // 0xf70(0x01)
	char pad_F71[0x3]; // 0xf71(0x03)
	float JumpTime; // 0xf74(0x04)
	bool IsRunning; // 0xf78(0x01)
	char pad_F79[0x7]; // 0xf79(0x07)
	struct FTransform EffectorTransform; // 0xf80(0x30)
	struct TMap<struct UPhysicalMaterial*, struct USoundCue*> Footstep Map; // 0xfb0(0x50)
	struct TMap<struct UPhysicalMaterial*, struct USoundCue*> Jumpland Map; // 0x1000(0x50)
	struct USoundCue* Jumpland Sound; // 0x1050(0x08)
	struct USoundCue* Footstep Sound; // 0x1058(0x08)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x1305ca0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_2321A9F84E5D11B5A25F98953F512310(); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_2321A9F84E5D11B5A25F98953F512310 // (BlueprintEvent) // @ game+0x1305ca0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_2C883E9C42B867B2498D799B0A738D11(); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_2C883E9C42B867B2498D799B0A738D11 // (BlueprintEvent) // @ game+0x1305ca0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_D7F0836F46C360751AE6BC95922DEC11(); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_D7F0836F46C360751AE6BC95922DEC11 // (BlueprintEvent) // @ game+0x1305ca0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_0C5A88D14987F964D888D88152ACB029(); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.EvaluateGraphExposedInputs_ExecuteUbergraph_HeroTPP_AnimBlueprint_AnimGraphNode_TransitionResult_0C5A88D14987F964D888D88152ACB029 // (BlueprintEvent) // @ game+0x1305ca0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.BlueprintUpdateAnimation // (Event|Public|BlueprintEvent) // @ game+0x1305ca0
	void AnimNotify_Jumpland(); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.AnimNotify_Jumpland // (BlueprintCallable|BlueprintEvent) // @ game+0x1305ca0
	void AnimNotify_Footstep(); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.AnimNotify_Footstep // (BlueprintCallable|BlueprintEvent) // @ game+0x1305ca0
	void ExecuteUbergraph_HeroTPP_AnimBlueprint(int32_t EntryPoint); // Function HeroTPP_AnimBlueprint.HeroTPP_AnimBlueprint_C.ExecuteUbergraph_HeroTPP_AnimBlueprint // (Final|UbergraphFunction|HasDefaults) // @ game+0x1305ca0
};

