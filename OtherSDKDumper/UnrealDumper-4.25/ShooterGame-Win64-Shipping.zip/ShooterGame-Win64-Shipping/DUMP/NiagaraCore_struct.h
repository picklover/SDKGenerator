// ScriptStruct NiagaraCore.NiagaraCompileHash
// Size: 0x10 (Inherited: 0x00)
struct FNiagaraCompileHash {
	struct TArray<char> DataHash; // 0x00(0x10)
};

