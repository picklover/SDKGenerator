// BlueprintGeneratedClass DmgType_Explosion.DmgType_Explosion_C
// Size: 0x68 (Inherited: 0x68)
struct UDmgType_Explosion_C : UShooterDamageType {
};

