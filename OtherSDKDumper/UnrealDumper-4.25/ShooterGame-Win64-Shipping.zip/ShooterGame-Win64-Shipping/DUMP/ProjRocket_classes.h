// BlueprintGeneratedClass ProjRocket.ProjRocket_C
// Size: 0x280 (Inherited: 0x270)
struct AProjRocket_C : AShooterProjectile {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x270(0x08)
	struct UAudioComponent* Audio; // 0x278(0x08)

	void OnTakeAnyDamage_Event(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function ProjRocket.ProjRocket_C.OnTakeAnyDamage_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x1305ca0
	void ExecuteUbergraph_ProjRocket(int32_t EntryPoint); // Function ProjRocket.ProjRocket_C.ExecuteUbergraph_ProjRocket // (Final|UbergraphFunction) // @ game+0x1305ca0
};

