#pragma once
#include <cstdint>
#pragma pack(push, 1)
enum EAdManagerDelegate {
    AMD_ClickedBanner = 0,
    AMD_UserClosedAd = 1,
    AMD_MAX = 2,
};
#pragma pack(pop)
