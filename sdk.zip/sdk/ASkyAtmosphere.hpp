#pragma once
#include <cstdint>
#include "AInfo.hpp"
class USkyAtmosphereComponent;
#pragma pack(push, 1)
class ASkyAtmosphere : public AInfo {
public:
    USkyAtmosphereComponent* SkyAtmosphereComponent; // 0x220
    static ASkyAtmosphere* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
