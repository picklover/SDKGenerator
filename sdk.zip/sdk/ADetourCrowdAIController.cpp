#include "AAIController.hpp"
#include "ADetourCrowdAIController.hpp"
ADetourCrowdAIController* ADetourCrowdAIController::StaticClass() {
    static auto res = find_uobject(11143114949645688554); // Class /Script/AIModule.DetourCrowdAIController
    return (ADetourCrowdAIController*)res;
}
