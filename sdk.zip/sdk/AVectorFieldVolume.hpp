#pragma once
#include <cstdint>
#include "AActor.hpp"
class UVectorFieldComponent;
#pragma pack(push, 1)
class AVectorFieldVolume : public AActor {
public:
    UVectorFieldComponent* VectorFieldComponent; // 0x220
    static AVectorFieldVolume* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
