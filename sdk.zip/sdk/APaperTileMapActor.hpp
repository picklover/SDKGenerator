#pragma once
#include <cstdint>
#include "AActor.hpp"
class UPaperTileMapComponent;
#pragma pack(push, 1)
class APaperTileMapActor : public AActor {
public:
    UPaperTileMapComponent* RenderComponent; // 0x220
    static APaperTileMapActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
