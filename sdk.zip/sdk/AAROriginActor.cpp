#include "AAROriginActor.hpp"
#include "AActor.hpp"
AAROriginActor* AAROriginActor::StaticClass() {
    static auto res = find_uobject(16655522340890985508); // Class /Script/AugmentedReality.AROriginActor
    return (AAROriginActor*)res;
}
