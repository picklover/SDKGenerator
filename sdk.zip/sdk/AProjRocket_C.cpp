#include "AActor.hpp"
#include "AController.hpp"
#include "AProjRocket_C.hpp"
#include "AShooterProjectile.hpp"
#include "FPointerToUberGraphFrame.hpp"
#include "UAudioComponent.hpp"
#include "UDamageType.hpp"
#include "UFunction.hpp"
AProjRocket_C* AProjRocket_C::StaticClass() {
    static auto res = find_uobject(2816631531608274394); // BlueprintGeneratedClass /Game/Blueprints/Weapons/ProjRocket.ProjRocket_C
    return (AProjRocket_C*)res;
}
void AProjRocket_C::OnTakeAnyDamage_Event(AActor* DamagedActor, float Damage, UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser) {
    static auto func = (UFunction*)(find_uobject(12978202399783409340)); // Function /Game/Blueprints/Weapons/ProjRocket.ProjRocket_C.OnTakeAnyDamage_Event
    struct Params_OnTakeAnyDamage_Event {
        AActor* DamagedActor; // 0x0
        float Damage; // 0x8
        char pad_c[0x4];
        UDamageType* DamageType; // 0x10
        AController* InstigatedBy; // 0x18
        AActor* DamageCauser; // 0x20
    }; // Size: 0x28
    Params_OnTakeAnyDamage_Event params{};
    params.DamagedActor = (AActor*)DamagedActor;
    params.Damage = (float)Damage;
    params.DamageType = (UDamageType*)DamageType;
    params.InstigatedBy = (AController*)InstigatedBy;
    params.DamageCauser = (AActor*)DamageCauser;
    ProcessEvent(func, &params);
}
void AProjRocket_C::ExecuteUbergraph_ProjRocket(int32_t EntryPoint, AActor* K2Node_CustomEvent_DamagedActor, float K2Node_CustomEvent_Damage, UDamageType* K2Node_CustomEvent_DamageType, AController* K2Node_CustomEvent_InstigatedBy, AActor* K2Node_CustomEvent_DamageCauser) {
    static auto func = (UFunction*)(find_uobject(5218342034792852255)); // Function /Game/Blueprints/Weapons/ProjRocket.ProjRocket_C.ExecuteUbergraph_ProjRocket
    struct Params_ExecuteUbergraph_ProjRocket {
        int32_t EntryPoint; // 0x0
        char pad_4[0x4];
        AActor* K2Node_CustomEvent_DamagedActor; // 0x8
        float K2Node_CustomEvent_Damage; // 0x10
        char pad_14[0x4];
        UDamageType* K2Node_CustomEvent_DamageType; // 0x18
        AController* K2Node_CustomEvent_InstigatedBy; // 0x20
        AActor* K2Node_CustomEvent_DamageCauser; // 0x28
    }; // Size: 0x30
    Params_ExecuteUbergraph_ProjRocket params{};
    params.EntryPoint = (int32_t)EntryPoint;
    params.K2Node_CustomEvent_DamagedActor = (AActor*)K2Node_CustomEvent_DamagedActor;
    params.K2Node_CustomEvent_Damage = (float)K2Node_CustomEvent_Damage;
    params.K2Node_CustomEvent_DamageType = (UDamageType*)K2Node_CustomEvent_DamageType;
    params.K2Node_CustomEvent_InstigatedBy = (AController*)K2Node_CustomEvent_InstigatedBy;
    params.K2Node_CustomEvent_DamageCauser = (AActor*)K2Node_CustomEvent_DamageCauser;
    ProcessEvent(func, &params);
}
