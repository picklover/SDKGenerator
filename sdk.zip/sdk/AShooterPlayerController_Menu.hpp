#pragma once
#include <cstdint>
#include "APlayerController.hpp"
#pragma pack(push, 1)
class AShooterPlayerController_Menu : public APlayerController {
public:
    static AShooterPlayerController_Menu* StaticClass();
}; // Size: 0x570
#pragma pack(pop)
