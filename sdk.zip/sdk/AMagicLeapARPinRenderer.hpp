#pragma once
#include <cstdint>
#include "AActor.hpp"
class UClass;
#pragma pack(push, 1)
class AMagicLeapARPinRenderer : public AActor {
public:
    bool bInfoActorsVisibilityOverride; // 0x220
    char pad_221[0x5f];
    UClass* ClassToSpawn; // 0x280
    static AMagicLeapARPinRenderer* StaticClass();
    void SetVisibilityOverride(bool InVisibilityOverride);
}; // Size: 0x288
#pragma pack(pop)
