#pragma once
#include <cstdint>
#include "AShooterWeapon.hpp"
#include "FProjectileWeaponData.hpp"
#include "FVector.hpp"
#include "FVector_NetQuantizeNormal.hpp"
#pragma pack(push, 1)
class AShooterWeapon_Projectile : public AShooterWeapon {
public:
    FProjectileWeaponData ProjectileConfig; // 0x4a0
    static AShooterWeapon_Projectile* StaticClass();
    void ServerFireProjectile(FVector Origin, FVector_NetQuantizeNormal ShootDir);
}; // Size: 0x4c0
#pragma pack(pop)
