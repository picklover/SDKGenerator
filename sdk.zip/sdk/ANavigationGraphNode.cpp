#include "AActor.hpp"
#include "ANavigationGraphNode.hpp"
ANavigationGraphNode* ANavigationGraphNode::StaticClass() {
    static auto res = find_uobject(7636293299308571069); // Class /Script/NavigationSystem.NavigationGraphNode
    return (ANavigationGraphNode*)res;
}
