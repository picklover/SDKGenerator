#pragma once
#include <cstdint>
#include "AHUD.hpp"
#pragma pack(push, 1)
class ADebugCameraHUD : public AHUD {
public:
    static ADebugCameraHUD* StaticClass();
}; // Size: 0x310
#pragma pack(pop)
