#include "AActor.hpp"
#include "ALightmassPortal.hpp"
#include "ULightmassPortalComponent.hpp"
ALightmassPortal* ALightmassPortal::StaticClass() {
    static auto res = find_uobject(1430676256580579488); // Class /Script/Engine.LightmassPortal
    return (ALightmassPortal*)res;
}
