#pragma once
#include <cstdint>
#include "ALandscapeGizmoActor.hpp"
#pragma pack(push, 1)
class ALandscapeGizmoActiveActor : public ALandscapeGizmoActor {
public:
    char pad_220[0x50];
    static ALandscapeGizmoActiveActor* StaticClass();
}; // Size: 0x270
#pragma pack(pop)
