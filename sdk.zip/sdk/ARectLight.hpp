#pragma once
#include <cstdint>
#include "ALight.hpp"
class URectLightComponent;
#pragma pack(push, 1)
class ARectLight : public ALight {
public:
    URectLightComponent* RectLightComponent; // 0x230
    static ARectLight* StaticClass();
}; // Size: 0x238
#pragma pack(pop)
