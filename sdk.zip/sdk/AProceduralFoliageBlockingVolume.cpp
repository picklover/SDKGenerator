#include "AProceduralFoliageBlockingVolume.hpp"
#include "AProceduralFoliageVolume.hpp"
#include "AVolume.hpp"
AProceduralFoliageBlockingVolume* AProceduralFoliageBlockingVolume::StaticClass() {
    static auto res = find_uobject(14103925123166251272); // Class /Script/Foliage.ProceduralFoliageBlockingVolume
    return (AProceduralFoliageBlockingVolume*)res;
}
