#pragma once
#include <cstdint>
#include "AActor.hpp"
class USceneComponent;
#pragma pack(push, 1)
class ACameraRig_Crane : public AActor {
public:
    float CranePitch; // 0x220
    float CraneYaw; // 0x224
    float CraneArmLength; // 0x228
    bool bLockMountPitch; // 0x22c
    bool bLockMountYaw; // 0x22d
    char pad_22e[0x2];
    USceneComponent* TransformComponent; // 0x230
    USceneComponent* CraneYawControl; // 0x238
    USceneComponent* CranePitchControl; // 0x240
    USceneComponent* CraneCameraMount; // 0x248
    static ACameraRig_Crane* StaticClass();
}; // Size: 0x250
#pragma pack(pop)
