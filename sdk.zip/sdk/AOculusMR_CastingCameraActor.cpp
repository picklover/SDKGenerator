#include "AOculusMR_CastingCameraActor.hpp"
#include "ASceneCapture2D.hpp"
#include "UMaterial.hpp"
#include "UMaterialInstanceDynamic.hpp"
#include "UOculusMR_PlaneMeshComponent.hpp"
#include "UOculusMR_Settings.hpp"
#include "UOculusMR_State.hpp"
#include "UTexture2D.hpp"
#include "UTextureRenderTarget2D.hpp"
#include "UVRNotificationsComponent.hpp"
AOculusMR_CastingCameraActor* AOculusMR_CastingCameraActor::StaticClass() {
    static auto res = find_uobject(13206399599892716766); // Class /Script/OculusMR.OculusMR_CastingCameraActor
    return (AOculusMR_CastingCameraActor*)res;
}
