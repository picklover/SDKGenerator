#pragma once
#include <cstdint>
#include "AGameMode.hpp"
#include "FMagicLeapSharedWorldSharedData.hpp"
class AMagicLeapSharedWorldPlayerController;
#pragma pack(push, 1)
class AMagicLeapSharedWorldGameMode : public AGameMode {
public:
    FMagicLeapSharedWorldSharedData SharedWorldData; // 0x308
    char pad_318[0x10];
    float PinSelectionConfidenceThreshold; // 0x328
    char pad_32c[0xa4];
    AMagicLeapSharedWorldPlayerController* ChosenOne; // 0x3d0
    static AMagicLeapSharedWorldGameMode* StaticClass();
    bool SendSharedWorldDataToClients();
    void SelectChosenOne();
    void MagicLeapOnNewLocalDataFromClients__DelegateSignature();
    void DetermineSharedWorldData(FMagicLeapSharedWorldSharedData& NewSharedWorldData);
}; // Size: 0x3d8
#pragma pack(pop)
