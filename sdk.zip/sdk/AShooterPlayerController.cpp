#include "APlayerController.hpp"
#include "AShooterPlayerController.hpp"
#include "FKey.hpp"
#include "FRotator.hpp"
#include "FVector.hpp"
#include "UFunction.hpp"
AShooterPlayerController* AShooterPlayerController::StaticClass() {
    static auto res = find_uobject(8585328824390210155); // Class /Script/ShooterGame.ShooterPlayerController
    return (AShooterPlayerController*)res;
}
void AShooterPlayerController::Suicide() {
    static auto func = (UFunction*)(find_uobject(1555132185780432971)); // Function /Script/ShooterGame.ShooterPlayerController.Suicide
    struct Params_Suicide {
    }; // Size: 0x0
    Params_Suicide params{};
    ProcessEvent(func, &params);
}
void AShooterPlayerController::SimulateInputKey(FKey Key, bool bPressed) {
    static auto func = (UFunction*)(find_uobject(259191459706391720)); // Function /Script/ShooterGame.ShooterPlayerController.SimulateInputKey
    struct Params_SimulateInputKey {
        FKey Key; // 0x0
        bool bPressed; // 0x18
    }; // Size: 0x19
    Params_SimulateInputKey params{};
    params.Key = (FKey)Key;
    params.bPressed = (bool)bPressed;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ServerSay(FString Msg) {
    static auto func = (UFunction*)(find_uobject(2584487808681828809)); // Function /Script/ShooterGame.ShooterPlayerController.ServerSay
    struct Params_ServerSay {
        FString Msg; // 0x0
    }; // Size: 0x10
    Params_ServerSay params{};
    params.Msg = (FString)Msg;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::SetGodMode(bool bEnable) {
    static auto func = (UFunction*)(find_uobject(6046483701224193476)); // Function /Script/ShooterGame.ShooterPlayerController.SetGodMode
    struct Params_SetGodMode {
        bool bEnable; // 0x0
    }; // Size: 0x1
    Params_SetGodMode params{};
    params.bEnable = (bool)bEnable;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ServerSuicide() {
    static auto func = (UFunction*)(find_uobject(755049864808280398)); // Function /Script/ShooterGame.ShooterPlayerController.ServerSuicide
    struct Params_ServerSuicide {
    }; // Size: 0x0
    Params_ServerSuicide params{};
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ClientEndOnlineGame() {
    static auto func = (UFunction*)(find_uobject(8173209962692041314)); // Function /Script/ShooterGame.ShooterPlayerController.ClientEndOnlineGame
    struct Params_ClientEndOnlineGame {
    }; // Size: 0x0
    Params_ClientEndOnlineGame params{};
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ServerCheat(FString Msg) {
    static auto func = (UFunction*)(find_uobject(16314425740907774165)); // Function /Script/ShooterGame.ShooterPlayerController.ServerCheat
    struct Params_ServerCheat {
        FString Msg; // 0x0
    }; // Size: 0x10
    Params_ServerCheat params{};
    params.Msg = (FString)Msg;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::Say(FString Msg) {
    static auto func = (UFunction*)(find_uobject(9894766317585801924)); // Function /Script/ShooterGame.ShooterPlayerController.Say
    struct Params_Say {
        FString Msg; // 0x0
    }; // Size: 0x10
    Params_Say params{};
    params.Msg = (FString)Msg;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ClientStartOnlineGame() {
    static auto func = (UFunction*)(find_uobject(5827783331962955563)); // Function /Script/ShooterGame.ShooterPlayerController.ClientStartOnlineGame
    struct Params_ClientStartOnlineGame {
    }; // Size: 0x0
    Params_ClientStartOnlineGame params{};
    ProcessEvent(func, &params);
}
void AShooterPlayerController::OnLeaderboardReadComplete(bool bWasSuccessful) {
    static auto func = (UFunction*)(find_uobject(6622378052800934052)); // Function /Script/ShooterGame.ShooterPlayerController.OnLeaderboardReadComplete
    struct Params_OnLeaderboardReadComplete {
        bool bWasSuccessful; // 0x0
    }; // Size: 0x1
    Params_OnLeaderboardReadComplete params{};
    params.bWasSuccessful = (bool)bWasSuccessful;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ClientSetSpectatorCamera(FVector CameraLocation, FRotator CameraRotation) {
    static auto func = (UFunction*)(find_uobject(9077936585764664980)); // Function /Script/ShooterGame.ShooterPlayerController.ClientSetSpectatorCamera
    struct Params_ClientSetSpectatorCamera {
        FVector CameraLocation; // 0x0
        FRotator CameraRotation; // 0xc
    }; // Size: 0x18
    Params_ClientSetSpectatorCamera params{};
    params.CameraLocation = (FVector)CameraLocation;
    params.CameraRotation = (FRotator)CameraRotation;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ClientSendRoundEndEvent(bool bIsWinner, int32_t ExpendedTimeInSeconds) {
    static auto func = (UFunction*)(find_uobject(5075611432931124559)); // Function /Script/ShooterGame.ShooterPlayerController.ClientSendRoundEndEvent
    struct Params_ClientSendRoundEndEvent {
        bool bIsWinner; // 0x0
        char pad_1[0x3];
        int32_t ExpendedTimeInSeconds; // 0x4
    }; // Size: 0x8
    Params_ClientSendRoundEndEvent params{};
    params.bIsWinner = (bool)bIsWinner;
    params.ExpendedTimeInSeconds = (int32_t)ExpendedTimeInSeconds;
    ProcessEvent(func, &params);
}
void AShooterPlayerController::ClientGameStarted() {
    static auto func = (UFunction*)(find_uobject(13618132421286240101)); // Function /Script/ShooterGame.ShooterPlayerController.ClientGameStarted
    struct Params_ClientGameStarted {
    }; // Size: 0x0
    Params_ClientGameStarted params{};
    ProcessEvent(func, &params);
}
