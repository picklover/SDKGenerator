#include "ADebugCameraHUD.hpp"
#include "AHUD.hpp"
ADebugCameraHUD* ADebugCameraHUD::StaticClass() {
    static auto res = find_uobject(5850329894920149927); // Class /Script/Engine.DebugCameraHUD
    return (ADebugCameraHUD*)res;
}
