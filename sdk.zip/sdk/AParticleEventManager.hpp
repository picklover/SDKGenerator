#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class AParticleEventManager : public AActor {
public:
    static AParticleEventManager* StaticClass();
}; // Size: 0x220
#pragma pack(pop)
