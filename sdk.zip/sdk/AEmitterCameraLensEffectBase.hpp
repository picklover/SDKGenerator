#pragma once
#include <cstdint>
#include "AEmitter.hpp"
#include "FTransform.hpp"
class UParticleSystem;
class APlayerCameraManager;
class UClass;
#pragma pack(push, 1)
class AEmitterCameraLensEffectBase : public AEmitter {
public:
    UParticleSystem* PS_CameraEffect; // 0x270
    UParticleSystem* PS_CameraEffectNonExtremeContent; // 0x278
    APlayerCameraManager* BaseCamera; // 0x280
    char pad_288[0x8];
    FTransform RelativeTransform; // 0x290
    float BaseFOV; // 0x2c0
    uint8_t bAllowMultipleInstances : 1; // 0x2c4
    uint8_t bResetWhenRetriggered : 1; // 0x2c4
    uint8_t pad_bitfield_2c4_2 : 6;
    char pad_2c5[0x3];
    TArray<UClass*> EmittersToTreatAsSame; // 0x2c8
    float DistFromCamera; // 0x2d8
    char pad_2dc[0x4];
    static AEmitterCameraLensEffectBase* StaticClass();
}; // Size: 0x2e0
#pragma pack(pop)
