#include "ABrush.hpp"
#include "AVolume.hpp"
AVolume* AVolume::StaticClass() {
    static auto res = find_uobject(16969351965854586280); // Class /Script/Engine.Volume
    return (AVolume*)res;
}
