#pragma once
#include <cstdint>
#include "AGameMode.hpp"
class UClass;
class AShooterAIController;
class AShooterPickup;
#pragma pack(push, 1)
class AShooterGameMode : public AGameMode {
public:
    UClass* BotPawnClass; // 0x308
    int32_t WarmupTime; // 0x310
    int32_t RoundTime; // 0x314
    int32_t TimeBetweenMatches; // 0x318
    int32_t KillScore; // 0x31c
    int32_t DeathScore; // 0x320
    float DamageSelfScale; // 0x324
    int32_t MaxBots; // 0x328
    char pad_32c[0x4];
    TArray<AShooterAIController*> BotControllers; // 0x330
    UClass* PlatformPlayerControllerClass; // 0x340
    char pad_348[0x10];
    TArray<AShooterPickup*> LevelPickups; // 0x358
    static AShooterGameMode* StaticClass();
    void SetAllowBots(bool bInAllowBots, int32_t InMaxBots);
    void FinishMatch();
}; // Size: 0x368
#pragma pack(pop)
