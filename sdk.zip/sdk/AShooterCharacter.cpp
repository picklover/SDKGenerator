#include "ACharacter.hpp"
#include "AShooterCharacter.hpp"
#include "AShooterWeapon.hpp"
#include "FRotator.hpp"
#include "FTakeHitInfo.hpp"
#include "UAnimMontage.hpp"
#include "UAudioComponent.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
#include "UMaterialInstanceDynamic.hpp"
#include "UParticleSystem.hpp"
#include "USkeletalMeshComponent.hpp"
#include "USoundCue.hpp"
void AShooterCharacter::OnRep_LastTakeHitInfo() {
    static auto func = (UFunction*)(find_uobject(8799472680547646470)); // Function /Script/ShooterGame.ShooterCharacter.OnRep_LastTakeHitInfo
    struct Params_OnRep_LastTakeHitInfo {
    }; // Size: 0x0
    Params_OnRep_LastTakeHitInfo params{};
    ProcessEvent(func, &params);
}
float AShooterCharacter::GetRunningSpeedModifier() {
    static auto func = (UFunction*)(find_uobject(15775911487228662722)); // Function /Script/ShooterGame.ShooterCharacter.GetRunningSpeedModifier
    struct Params_GetRunningSpeedModifier {
        float ReturnValue; // 0x0
    }; // Size: 0x4
    Params_GetRunningSpeedModifier params{};
    ProcessEvent(func, &params);
    return (float)params.ReturnValue;
}
AShooterCharacter* AShooterCharacter::StaticClass() {
    static auto res = find_uobject(7594155484934602041); // Class /Script/ShooterGame.ShooterCharacter
    return (AShooterCharacter*)res;
}
void AShooterCharacter::ServerSetTargeting(bool bNewTargeting) {
    static auto func = (UFunction*)(find_uobject(557518634478968051)); // Function /Script/ShooterGame.ShooterCharacter.ServerSetTargeting
    struct Params_ServerSetTargeting {
        bool bNewTargeting; // 0x0
    }; // Size: 0x1
    Params_ServerSetTargeting params{};
    params.bNewTargeting = (bool)bNewTargeting;
    ProcessEvent(func, &params);
}
void AShooterCharacter::ServerEquipWeapon(AShooterWeapon* NewWeapon) {
    static auto func = (UFunction*)(find_uobject(18428463279568587148)); // Function /Script/ShooterGame.ShooterCharacter.ServerEquipWeapon
    struct Params_ServerEquipWeapon {
        AShooterWeapon* NewWeapon; // 0x0
    }; // Size: 0x8
    Params_ServerEquipWeapon params{};
    params.NewWeapon = (AShooterWeapon*)NewWeapon;
    ProcessEvent(func, &params);
}
void AShooterCharacter::ServerSetRunning(bool bNewRunning, bool bToggle) {
    static auto func = (UFunction*)(find_uobject(12645130829537175491)); // Function /Script/ShooterGame.ShooterCharacter.ServerSetRunning
    struct Params_ServerSetRunning {
        bool bNewRunning; // 0x0
        bool bToggle; // 0x1
    }; // Size: 0x2
    Params_ServerSetRunning params{};
    params.bNewRunning = (bool)bNewRunning;
    params.bToggle = (bool)bToggle;
    ProcessEvent(func, &params);
}
bool AShooterCharacter::IsRunning() {
    static auto func = (UFunction*)(find_uobject(6004825399981648202)); // Function /Script/ShooterGame.ShooterCharacter.IsRunning
    struct Params_IsRunning {
        bool ReturnValue; // 0x0
    }; // Size: 0x1
    Params_IsRunning params{};
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
void AShooterCharacter::OnRep_CurrentWeapon(AShooterWeapon* LastWeapon) {
    static auto func = (UFunction*)(find_uobject(10316020378136364927)); // Function /Script/ShooterGame.ShooterCharacter.OnRep_CurrentWeapon
    struct Params_OnRep_CurrentWeapon {
        AShooterWeapon* LastWeapon; // 0x0
    }; // Size: 0x8
    Params_OnRep_CurrentWeapon params{};
    params.LastWeapon = (AShooterWeapon*)LastWeapon;
    ProcessEvent(func, &params);
}
float AShooterCharacter::GetTargetingSpeedModifier() {
    static auto func = (UFunction*)(find_uobject(8192807625500999542)); // Function /Script/ShooterGame.ShooterCharacter.GetTargetingSpeedModifier
    struct Params_GetTargetingSpeedModifier {
        float ReturnValue; // 0x0
    }; // Size: 0x4
    Params_GetTargetingSpeedModifier params{};
    ProcessEvent(func, &params);
    return (float)params.ReturnValue;
}
bool AShooterCharacter::IsTargeting() {
    static auto func = (UFunction*)(find_uobject(4115363170771571906)); // Function /Script/ShooterGame.ShooterCharacter.IsTargeting
    struct Params_IsTargeting {
        bool ReturnValue; // 0x0
    }; // Size: 0x1
    Params_IsTargeting params{};
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
AShooterWeapon* AShooterCharacter::GetWeapon() {
    static auto func = (UFunction*)(find_uobject(11934946152157939901)); // Function /Script/ShooterGame.ShooterCharacter.GetWeapon
    struct Params_GetWeapon {
        AShooterWeapon* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_GetWeapon params{};
    ProcessEvent(func, &params);
    return (AShooterWeapon*)params.ReturnValue;
}
bool AShooterCharacter::IsFirstPerson() {
    static auto func = (UFunction*)(find_uobject(36762098249716354)); // Function /Script/ShooterGame.ShooterCharacter.IsFirstPerson
    struct Params_IsFirstPerson {
        bool ReturnValue; // 0x0
    }; // Size: 0x1
    Params_IsFirstPerson params{};
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
bool AShooterCharacter::IsFiring() {
    static auto func = (UFunction*)(find_uobject(2896233402318826864)); // Function /Script/ShooterGame.ShooterCharacter.IsFiring
    struct Params_IsFiring {
        bool ReturnValue; // 0x0
    }; // Size: 0x1
    Params_IsFiring params{};
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
FRotator AShooterCharacter::GetAimOffsets() {
    static auto func = (UFunction*)(find_uobject(16055542999519839026)); // Function /Script/ShooterGame.ShooterCharacter.GetAimOffsets
    struct Params_GetAimOffsets {
        FRotator ReturnValue; // 0x0
    }; // Size: 0xc
    Params_GetAimOffsets params{};
    ProcessEvent(func, &params);
    return (FRotator)params.ReturnValue;
}
