#include "AAIController.hpp"
#include "AShooterAIController.hpp"
#include "AShooterCharacter.hpp"
#include "UBehaviorTreeComponent.hpp"
#include "UBlackboardComponent.hpp"
#include "UFunction.hpp"
AShooterAIController* AShooterAIController::StaticClass() {
    static auto res = find_uobject(3886992494809130092); // Class /Script/ShooterGame.ShooterAIController
    return (AShooterAIController*)res;
}
void AShooterAIController::ShootEnemy() {
    static auto func = (UFunction*)(find_uobject(6789335066545872009)); // Function /Script/ShooterGame.ShooterAIController.ShootEnemy
    struct Params_ShootEnemy {
    }; // Size: 0x0
    Params_ShootEnemy params{};
    ProcessEvent(func, &params);
}
void AShooterAIController::FindClosestEnemy() {
    static auto func = (UFunction*)(find_uobject(11346536825979707878)); // Function /Script/ShooterGame.ShooterAIController.FindClosestEnemy
    struct Params_FindClosestEnemy {
    }; // Size: 0x0
    Params_FindClosestEnemy params{};
    ProcessEvent(func, &params);
}
bool AShooterAIController::FindClosestEnemyWithLOS(AShooterCharacter* ExcludeEnemy) {
    static auto func = (UFunction*)(find_uobject(5774005092940092484)); // Function /Script/ShooterGame.ShooterAIController.FindClosestEnemyWithLOS
    struct Params_FindClosestEnemyWithLOS {
        AShooterCharacter* ExcludeEnemy; // 0x0
        bool ReturnValue; // 0x8
    }; // Size: 0x9
    Params_FindClosestEnemyWithLOS params{};
    params.ExcludeEnemy = (AShooterCharacter*)ExcludeEnemy;
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
