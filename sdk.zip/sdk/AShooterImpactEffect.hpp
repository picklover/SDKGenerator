#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FDecalData.hpp"
#include "FHitResult.hpp"
class UParticleSystem;
class USoundCue;
#pragma pack(push, 1)
class AShooterImpactEffect : public AActor {
public:
    UParticleSystem* DefaultFX; // 0x220
    UParticleSystem* ConcreteFX; // 0x228
    UParticleSystem* DirtFX; // 0x230
    UParticleSystem* WaterFX; // 0x238
    UParticleSystem* MetalFX; // 0x240
    UParticleSystem* WoodFX; // 0x248
    UParticleSystem* GlassFX; // 0x250
    UParticleSystem* GrassFX; // 0x258
    UParticleSystem* FleshFX; // 0x260
    USoundCue* DefaultSound; // 0x268
    USoundCue* ConcreteSound; // 0x270
    USoundCue* DirtSound; // 0x278
    USoundCue* WaterSound; // 0x280
    USoundCue* MetalSound; // 0x288
    USoundCue* WoodSound; // 0x290
    USoundCue* GlassSound; // 0x298
    USoundCue* GrassSound; // 0x2a0
    USoundCue* FleshSound; // 0x2a8
    FDecalData DefaultDecal; // 0x2b0
    FHitResult SurfaceHit; // 0x2c0
    static AShooterImpactEffect* StaticClass();
}; // Size: 0x348
#pragma pack(pop)
