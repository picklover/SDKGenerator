#pragma once
#include <cstdint>
#include "AVolume.hpp"
#include "FAudioVolumeSubmixOverrideSettings.hpp"
#include "FAudioVolumeSubmixSendSettings.hpp"
#include "FInteriorSettings.hpp"
#include "FReverbSettings.hpp"
#pragma pack(push, 1)
class AAudioVolume : public AVolume {
public:
    float Priority; // 0x258
    uint8_t bEnabled : 1; // 0x25c
    uint8_t pad_bitfield_25c_1 : 7;
    char pad_25d[0x3];
    FReverbSettings Settings; // 0x260
    FInteriorSettings AmbientZoneSettings; // 0x280
    char pad_2a4[0x4];
    TArray<FAudioVolumeSubmixSendSettings> SubmixSendSettings; // 0x2a8
    TArray<FAudioVolumeSubmixOverrideSettings> SubmixOverrideSettings; // 0x2b8
    static AAudioVolume* StaticClass();
    void SetSubmixSendSettings(TArray<FAudioVolumeSubmixSendSettings>& NewSubmixSendSettings);
    void SetSubmixOverrideSettings(TArray<FAudioVolumeSubmixOverrideSettings>& NewSubmixOverrideSettings);
    void SetReverbSettings(FReverbSettings& NewReverbSettings);
    void SetPriority(float NewPriority);
    void SetInteriorSettings(FInteriorSettings& NewInteriorSettings);
    void SetEnabled(bool bNewEnabled);
    void OnRep_bEnabled();
}; // Size: 0x2c8
#pragma pack(pop)
