#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FVector.hpp"
class UReplicationGraph;
class UNetReplicationGraphConnection;
class UClass;
#pragma pack(push, 1)
class AReplicationGraphDebugActor : public AActor {
public:
    UReplicationGraph* ReplicationGraph; // 0x220
    UNetReplicationGraphConnection* ConnectionManager; // 0x228
    static AReplicationGraphDebugActor* StaticClass();
    void ServerStopDebugging();
    void ServerStartDebugging();
    void ServerSetPeriodFrameForClass(UClass* Class, int32_t PeriodFrame);
    void ServerSetCullDistanceForClass(UClass* Class, float CullDistance);
    void ServerSetConditionalActorBreakpoint(AActor* Actor);
    void ServerPrintCullDistances();
    void ServerPrintAllActorInfo(FString Str);
    void ServerCellInfo();
    void ClientCellInfo(FVector CellLocation, FVector CellExtent, TArray<AActor*>& Actors);
}; // Size: 0x230
#pragma pack(pop)
