#pragma once
#include <cstdint>
#include "AVolume.hpp"
#pragma pack(push, 1)
class APhysicsVolume : public AVolume {
public:
    float TerminalVelocity; // 0x258
    int32_t Priority; // 0x25c
    float FluidFriction; // 0x260
    uint8_t bWaterVolume : 1; // 0x264
    uint8_t bPhysicsOnContact : 1; // 0x264
    uint8_t pad_bitfield_264_2 : 6;
    char pad_265[0x3];
    static APhysicsVolume* StaticClass();
}; // Size: 0x268
#pragma pack(pop)
