#include "ADefaultPhysicsVolume.hpp"
#include "APhysicsVolume.hpp"
ADefaultPhysicsVolume* ADefaultPhysicsVolume::StaticClass() {
    static auto res = find_uobject(13633160368053410882); // Class /Script/Engine.DefaultPhysicsVolume
    return (ADefaultPhysicsVolume*)res;
}
