#include "ATriggerBase.hpp"
#include "ATriggerSphere.hpp"
ATriggerSphere* ATriggerSphere::StaticClass() {
    static auto res = find_uobject(13876529082848451051); // Class /Script/Engine.TriggerSphere
    return (ATriggerSphere*)res;
}
