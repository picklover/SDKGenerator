#pragma once
#include <cstdint>
#include "AActor.hpp"
class UStaticMeshComponent;
class USceneComponent;
#pragma pack(push, 1)
class ASceneCapture : public AActor {
public:
    UStaticMeshComponent* MeshComp; // 0x220
    USceneComponent* SceneComponent; // 0x228
    static ASceneCapture* StaticClass();
}; // Size: 0x230
#pragma pack(pop)
