#include "AARActor.hpp"
#include "AActor.hpp"
#include "FGuid.hpp"
#include "UARComponent.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
AARActor* AARActor::StaticClass() {
    static auto res = find_uobject(2609982198289555778); // Class /Script/AugmentedReality.ARActor
    return (AARActor*)res;
}
UARComponent* AARActor::AddARComponent(UClass* InComponentClass, FGuid& NativeID) {
    static auto func = (UFunction*)(find_uobject(15504134623349281161)); // Function /Script/AugmentedReality.ARActor.AddARComponent
    struct Params_AddARComponent {
        UClass* InComponentClass; // 0x0
        FGuid NativeID; // 0x8
        UARComponent* ReturnValue; // 0x18
    }; // Size: 0x20
    Params_AddARComponent params{};
    params.InComponentClass = (UClass*)InComponentClass;
    params.NativeID = (FGuid)NativeID;
    ProcessEvent(func, &params);
    NativeID = params.NativeID;
    return (UARComponent*)params.ReturnValue;
}
