#pragma once
#include <cstdint>
#include "AVolume.hpp"
#include "FCullDistanceSizePair.hpp"
#pragma pack(push, 1)
class ACullDistanceVolume : public AVolume {
public:
    TArray<FCullDistanceSizePair> CullDistances; // 0x258
    uint8_t bEnabled : 1; // 0x268
    uint8_t pad_bitfield_268_1 : 7;
    char pad_269[0x7];
    static ACullDistanceVolume* StaticClass();
}; // Size: 0x270
#pragma pack(pop)
