#include "AActor.hpp"
#include "AParticleEventManager.hpp"
AParticleEventManager* AParticleEventManager::StaticClass() {
    static auto res = find_uobject(6644090523236243919); // Class /Script/Engine.ParticleEventManager
    return (AParticleEventManager*)res;
}
