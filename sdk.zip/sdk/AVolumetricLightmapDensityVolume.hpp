#pragma once
#include <cstdint>
#include "AVolume.hpp"
#include "FInt32Interval.hpp"
#pragma pack(push, 1)
class AVolumetricLightmapDensityVolume : public AVolume {
public:
    FInt32Interval AllowedMipLevelRange; // 0x258
    static AVolumetricLightmapDensityVolume* StaticClass();
}; // Size: 0x260
#pragma pack(pop)
