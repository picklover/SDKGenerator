#include "APlayerCameraManager.hpp"
#include "AShooterPlayerCameraManager.hpp"
AShooterPlayerCameraManager* AShooterPlayerCameraManager::StaticClass() {
    static auto res = find_uobject(17647063106106989383); // Class /Script/ShooterGame.ShooterPlayerCameraManager
    return (AShooterPlayerCameraManager*)res;
}
