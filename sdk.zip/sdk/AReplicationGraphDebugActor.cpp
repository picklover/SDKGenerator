#include "AActor.hpp"
#include "AReplicationGraphDebugActor.hpp"
#include "FVector.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
#include "UNetReplicationGraphConnection.hpp"
#include "UReplicationGraph.hpp"
void AReplicationGraphDebugActor::ServerCellInfo() {
    static auto func = (UFunction*)(find_uobject(12490554581275150019)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerCellInfo
    struct Params_ServerCellInfo {
    }; // Size: 0x0
    Params_ServerCellInfo params{};
    ProcessEvent(func, &params);
}
AReplicationGraphDebugActor* AReplicationGraphDebugActor::StaticClass() {
    static auto res = find_uobject(17334371481266321256); // Class /Script/ReplicationGraph.ReplicationGraphDebugActor
    return (AReplicationGraphDebugActor*)res;
}
void AReplicationGraphDebugActor::ServerStopDebugging() {
    static auto func = (UFunction*)(find_uobject(9179327318994901537)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerStopDebugging
    struct Params_ServerStopDebugging {
    }; // Size: 0x0
    Params_ServerStopDebugging params{};
    ProcessEvent(func, &params);
}
void AReplicationGraphDebugActor::ServerStartDebugging() {
    static auto func = (UFunction*)(find_uobject(7734986749076593287)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerStartDebugging
    struct Params_ServerStartDebugging {
    }; // Size: 0x0
    Params_ServerStartDebugging params{};
    ProcessEvent(func, &params);
}
void AReplicationGraphDebugActor::ServerPrintCullDistances() {
    static auto func = (UFunction*)(find_uobject(5802685463086922806)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerPrintCullDistances
    struct Params_ServerPrintCullDistances {
    }; // Size: 0x0
    Params_ServerPrintCullDistances params{};
    ProcessEvent(func, &params);
}
void AReplicationGraphDebugActor::ServerSetPeriodFrameForClass(UClass* Class, int32_t PeriodFrame) {
    static auto func = (UFunction*)(find_uobject(14481247077827862912)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerSetPeriodFrameForClass
    struct Params_ServerSetPeriodFrameForClass {
        UClass* Class; // 0x0
        int32_t PeriodFrame; // 0x8
    }; // Size: 0xc
    Params_ServerSetPeriodFrameForClass params{};
    params.Class = (UClass*)Class;
    params.PeriodFrame = (int32_t)PeriodFrame;
    ProcessEvent(func, &params);
}
void AReplicationGraphDebugActor::ServerPrintAllActorInfo(FString Str) {
    static auto func = (UFunction*)(find_uobject(6918236638858488590)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerPrintAllActorInfo
    struct Params_ServerPrintAllActorInfo {
        FString Str; // 0x0
    }; // Size: 0x10
    Params_ServerPrintAllActorInfo params{};
    params.Str = (FString)Str;
    ProcessEvent(func, &params);
}
void AReplicationGraphDebugActor::ServerSetCullDistanceForClass(UClass* Class, float CullDistance) {
    static auto func = (UFunction*)(find_uobject(14595901496965045551)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerSetCullDistanceForClass
    struct Params_ServerSetCullDistanceForClass {
        UClass* Class; // 0x0
        float CullDistance; // 0x8
    }; // Size: 0xc
    Params_ServerSetCullDistanceForClass params{};
    params.Class = (UClass*)Class;
    params.CullDistance = (float)CullDistance;
    ProcessEvent(func, &params);
}
void AReplicationGraphDebugActor::ServerSetConditionalActorBreakpoint(AActor* Actor) {
    static auto func = (UFunction*)(find_uobject(15344173931609445291)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ServerSetConditionalActorBreakpoint
    struct Params_ServerSetConditionalActorBreakpoint {
        AActor* Actor; // 0x0
    }; // Size: 0x8
    Params_ServerSetConditionalActorBreakpoint params{};
    params.Actor = (AActor*)Actor;
    ProcessEvent(func, &params);
}
void AReplicationGraphDebugActor::ClientCellInfo(FVector CellLocation, FVector CellExtent, TArray<AActor*>& Actors) {
    static auto func = (UFunction*)(find_uobject(15864391539689676711)); // Function /Script/ReplicationGraph.ReplicationGraphDebugActor.ClientCellInfo
    struct Params_ClientCellInfo {
        FVector CellLocation; // 0x0
        FVector CellExtent; // 0xc
        TArray<AActor*> Actors; // 0x18
    }; // Size: 0x28
    Params_ClientCellInfo params{};
    params.CellLocation = (FVector)CellLocation;
    params.CellExtent = (FVector)CellExtent;
    params.Actors = (TArray<AActor*>)Actors;
    ProcessEvent(func, &params);
    Actors = params.Actors;
}
