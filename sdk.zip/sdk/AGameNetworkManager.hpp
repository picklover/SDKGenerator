#pragma once
#include <cstdint>
#include "AInfo.hpp"
#pragma pack(push, 1)
class AGameNetworkManager : public AInfo {
public:
    float BadPacketLossThreshold; // 0x220
    float SeverePacketLossThreshold; // 0x224
    int32_t BadPingThreshold; // 0x228
    int32_t SeverePingThreshold; // 0x22c
    int32_t AdjustedNetSpeed; // 0x230
    float LastNetSpeedUpdateTime; // 0x234
    int32_t TotalNetBandwidth; // 0x238
    int32_t MinDynamicBandwidth; // 0x23c
    int32_t MaxDynamicBandwidth; // 0x240
    uint8_t bIsStandbyCheckingEnabled : 1; // 0x244
    uint8_t bHasStandbyCheatTriggered : 1; // 0x244
    uint8_t pad_bitfield_244_2 : 6;
    char pad_245[0x3];
    float StandbyRxCheatTime; // 0x248
    float StandbyTxCheatTime; // 0x24c
    float PercentMissingForRxStandby; // 0x250
    float PercentMissingForTxStandby; // 0x254
    float PercentForBadPing; // 0x258
    float JoinInProgressStandbyWaitTime; // 0x25c
    float MoveRepSize; // 0x260
    float MAXPOSITIONERRORSQUARED; // 0x264
    float MAXNEARZEROVELOCITYSQUARED; // 0x268
    float CLIENTADJUSTUPDATECOST; // 0x26c
    float MAXCLIENTUPDATEINTERVAL; // 0x270
    float MaxClientForcedUpdateDuration; // 0x274
    float ServerForcedUpdateHitchThreshold; // 0x278
    float ServerForcedUpdateHitchCooldown; // 0x27c
    float MaxMoveDeltaTime; // 0x280
    float MaxClientSmoothingDeltaTime; // 0x284
    float ClientNetSendMoveDeltaTime; // 0x288
    float ClientNetSendMoveDeltaTimeThrottled; // 0x28c
    float ClientNetSendMoveDeltaTimeStationary; // 0x290
    int32_t ClientNetSendMoveThrottleAtNetSpeed; // 0x294
    int32_t ClientNetSendMoveThrottleOverPlayerCount; // 0x298
    bool ClientAuthorativePosition; // 0x29c
    char pad_29d[0x3];
    float ClientErrorUpdateRateLimit; // 0x2a0
    float ClientNetCamUpdateDeltaTime; // 0x2a4
    float ClientNetCamUpdatePositionLimit; // 0x2a8
    bool bMovementTimeDiscrepancyDetection; // 0x2ac
    bool bMovementTimeDiscrepancyResolution; // 0x2ad
    char pad_2ae[0x2];
    float MovementTimeDiscrepancyMaxTimeMargin; // 0x2b0
    float MovementTimeDiscrepancyMinTimeMargin; // 0x2b4
    float MovementTimeDiscrepancyResolutionRate; // 0x2b8
    float MovementTimeDiscrepancyDriftAllowance; // 0x2bc
    bool bMovementTimeDiscrepancyForceCorrectionsDuringResolution; // 0x2c0
    bool bUseDistanceBasedRelevancy; // 0x2c1
    char pad_2c2[0xe];
    static AGameNetworkManager* StaticClass();
}; // Size: 0x2d0
#pragma pack(pop)
