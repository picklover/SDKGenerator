#pragma once
#include <cstdint>
#include "AShooterWeapon_Instant.hpp"
#pragma pack(push, 1)
class AWeapGun_C : public AShooterWeapon_Instant {
public:
    static AWeapGun_C* StaticClass();
}; // Size: 0x4f8
#pragma pack(pop)
