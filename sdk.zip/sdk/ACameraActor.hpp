#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "EAutoReceiveInput\Type.hpp"
#include "FPostProcessSettings.hpp"
class UCameraComponent;
class USceneComponent;
#pragma pack(push, 1)
class ACameraActor : public AActor {
public:
    EAutoReceiveInput::Type AutoActivateForPlayer; // 0x220
    char pad_221[0x7];
    UCameraComponent* CameraComponent; // 0x228
    USceneComponent* SceneComponent; // 0x230
    char pad_238[0x8];
    uint8_t bConstrainAspectRatio : 1; // 0x240
    uint8_t pad_bitfield_240_1 : 7;
    char pad_241[0x3];
    float AspectRatio; // 0x244
    float FOVAngle; // 0x248
    float PostProcessBlendWeight; // 0x24c
    FPostProcessSettings PostProcessSettings; // 0x250
    static ACameraActor* StaticClass();
    int32_t GetAutoActivatePlayerIndex();
}; // Size: 0x7b0
#pragma pack(pop)
