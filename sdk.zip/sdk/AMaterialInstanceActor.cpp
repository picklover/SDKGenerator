#include "AActor.hpp"
#include "AMaterialInstanceActor.hpp"
AMaterialInstanceActor* AMaterialInstanceActor::StaticClass() {
    static auto res = find_uobject(8976931802450046889); // Class /Script/Engine.MaterialInstanceActor
    return (AMaterialInstanceActor*)res;
}
