#include "AActor.hpp"
#include "ANavSystemConfigOverride.hpp"
#include "ENavSystemOverridePolicy.hpp"
#include "UNavigationSystemConfig.hpp"
ANavSystemConfigOverride* ANavSystemConfigOverride::StaticClass() {
    static auto res = find_uobject(15365938847197323269); // Class /Script/NavigationSystem.NavSystemConfigOverride
    return (ANavSystemConfigOverride*)res;
}
