#pragma once
#include <cstdint>
#include "ASceneCapture.hpp"
class USceneCaptureComponentCube;
#pragma pack(push, 1)
class ASceneCaptureCube : public ASceneCapture {
public:
    USceneCaptureComponentCube* CaptureComponentCube; // 0x230
    static ASceneCaptureCube* StaticClass();
    void OnInterpToggle(bool bEnable);
}; // Size: 0x238
#pragma pack(pop)
