#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class AInfo : public AActor {
public:
    static AInfo* StaticClass();
}; // Size: 0x220
#pragma pack(pop)
