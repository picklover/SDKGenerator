#pragma once
#include <cstdint>
#include "AActor.hpp"
class UNiagaraBaselineController;
class UTextRenderComponent;
#pragma pack(push, 1)
class ANiagaraPerfBaselineActor : public AActor {
public:
    UNiagaraBaselineController* Controller; // 0x220
    UTextRenderComponent* Label; // 0x228
    static ANiagaraPerfBaselineActor* StaticClass();
}; // Size: 0x230
#pragma pack(pop)
