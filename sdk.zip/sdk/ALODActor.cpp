#include "AActor.hpp"
#include "ALODActor.hpp"
#include "UHLODProxy.hpp"
#include "UStaticMeshComponent.hpp"
ALODActor* ALODActor::StaticClass() {
    static auto res = find_uobject(8811476639165761674); // Class /Script/Engine.LODActor
    return (ALODActor*)res;
}
