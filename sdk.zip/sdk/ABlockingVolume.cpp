#include "ABlockingVolume.hpp"
#include "AVolume.hpp"
ABlockingVolume* ABlockingVolume::StaticClass() {
    static auto res = find_uobject(13517719845115265711); // Class /Script/Engine.BlockingVolume
    return (ABlockingVolume*)res;
}
