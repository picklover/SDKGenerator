#include "AActor.hpp"
#include "APaperGroupedSpriteActor.hpp"
#include "UPaperGroupedSpriteComponent.hpp"
APaperGroupedSpriteActor* APaperGroupedSpriteActor::StaticClass() {
    static auto res = find_uobject(15549097670988303570); // Class /Script/Paper2D.PaperGroupedSpriteActor
    return (APaperGroupedSpriteActor*)res;
}
