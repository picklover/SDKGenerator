#include "AShooterWeapon.hpp"
#include "AShooterWeapon_Projectile.hpp"
#include "FProjectileWeaponData.hpp"
#include "FVector.hpp"
#include "FVector_NetQuantizeNormal.hpp"
#include "UFunction.hpp"
AShooterWeapon_Projectile* AShooterWeapon_Projectile::StaticClass() {
    static auto res = find_uobject(2083399920745759888); // Class /Script/ShooterGame.ShooterWeapon_Projectile
    return (AShooterWeapon_Projectile*)res;
}
void AShooterWeapon_Projectile::ServerFireProjectile(FVector Origin, FVector_NetQuantizeNormal ShootDir) {
    static auto func = (UFunction*)(find_uobject(12449890131131930752)); // Function /Script/ShooterGame.ShooterWeapon_Projectile.ServerFireProjectile
    struct Params_ServerFireProjectile {
        FVector Origin; // 0x0
        FVector_NetQuantizeNormal ShootDir; // 0xc
    }; // Size: 0x18
    Params_ServerFireProjectile params{};
    params.Origin = (FVector)Origin;
    params.ShootDir = (FVector_NetQuantizeNormal)ShootDir;
    ProcessEvent(func, &params);
}
