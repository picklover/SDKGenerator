#include "AActor.hpp"
#include "AVectorFieldVolume.hpp"
#include "UVectorFieldComponent.hpp"
AVectorFieldVolume* AVectorFieldVolume::StaticClass() {
    static auto res = find_uobject(5483847416804609865); // Class /Script/Engine.VectorFieldVolume
    return (AVectorFieldVolume*)res;
}
