#include "AOnlineBeaconHostObject.hpp"
#include "ASpectatorBeaconHost.hpp"
#include "USpectatorBeaconState.hpp"
ASpectatorBeaconHost* ASpectatorBeaconHost::StaticClass() {
    static auto res = find_uobject(15458048699127122680); // Class /Script/OnlineSubsystemUtils.SpectatorBeaconHost
    return (ASpectatorBeaconHost*)res;
}
