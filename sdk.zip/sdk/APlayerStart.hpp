#pragma once
#include <cstdint>
#include "ANavigationObjectBase.hpp"
#pragma pack(push, 1)
class APlayerStart : public ANavigationObjectBase {
public:
    FName PlayerStartTag; // 0x248
    static APlayerStart* StaticClass();
}; // Size: 0x250
#pragma pack(pop)
