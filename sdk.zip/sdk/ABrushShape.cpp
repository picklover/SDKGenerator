#include "ABrush.hpp"
#include "ABrushShape.hpp"
ABrushShape* ABrushShape::StaticClass() {
    static auto res = find_uobject(5211756350762787891); // Class /Script/Engine.BrushShape
    return (ABrushShape*)res;
}
