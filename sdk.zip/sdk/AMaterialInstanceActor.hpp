#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class AMaterialInstanceActor : public AActor {
public:
    TArray<AActor*> TargetActors; // 0x220
    static AMaterialInstanceActor* StaticClass();
}; // Size: 0x230
#pragma pack(pop)
