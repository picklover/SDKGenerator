#pragma once
#include <cstdint>
#include "AActor.hpp"
class UPaperSpriteComponent;
#pragma pack(push, 1)
class APaperSpriteActor : public AActor {
public:
    UPaperSpriteComponent* RenderComponent; // 0x220
    static APaperSpriteActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
