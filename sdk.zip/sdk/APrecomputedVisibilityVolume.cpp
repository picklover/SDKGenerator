#include "APrecomputedVisibilityVolume.hpp"
#include "AVolume.hpp"
APrecomputedVisibilityVolume* APrecomputedVisibilityVolume::StaticClass() {
    static auto res = find_uobject(5383744390007598314); // Class /Script/Engine.PrecomputedVisibilityVolume
    return (APrecomputedVisibilityVolume*)res;
}
