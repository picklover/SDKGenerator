#include "ANavMeshBoundsVolume.hpp"
#include "AVolume.hpp"
#include "FNavAgentSelector.hpp"
ANavMeshBoundsVolume* ANavMeshBoundsVolume::StaticClass() {
    static auto res = find_uobject(11850738300546698276); // Class /Script/NavigationSystem.NavMeshBoundsVolume
    return (ANavMeshBoundsVolume*)res;
}
