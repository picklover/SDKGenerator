#pragma once
#include <cstdint>
#include "AShooterGameMode.hpp"
#pragma pack(push, 1)
class AShooterGame_TeamDeathMatch : public AShooterGameMode {
public:
    char pad_368[0x8];
    static AShooterGame_TeamDeathMatch* StaticClass();
}; // Size: 0x370
#pragma pack(pop)
