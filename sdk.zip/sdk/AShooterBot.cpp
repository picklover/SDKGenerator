#include "AShooterBot.hpp"
#include "AShooterCharacter.hpp"
#include "UBehaviorTree.hpp"
AShooterBot* AShooterBot::StaticClass() {
    static auto res = find_uobject(11307559263962733215); // Class /Script/ShooterGame.ShooterBot
    return (AShooterBot*)res;
}
