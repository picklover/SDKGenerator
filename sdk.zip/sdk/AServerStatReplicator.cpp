#include "AInfo.hpp"
#include "AServerStatReplicator.hpp"
AServerStatReplicator* AServerStatReplicator::StaticClass() {
    static auto res = find_uobject(3029039384038412606); // Class /Script/Engine.ServerStatReplicator
    return (AServerStatReplicator*)res;
}
