#pragma once
#include <cstdint>
#include "AVolume.hpp"
#pragma pack(push, 1)
class ALightmassCharacterIndirectDetailVolume : public AVolume {
public:
    static ALightmassCharacterIndirectDetailVolume* StaticClass();
}; // Size: 0x258
#pragma pack(pop)
