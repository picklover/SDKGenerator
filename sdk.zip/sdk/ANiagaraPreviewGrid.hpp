#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "ENiagaraPreviewGridResetMode.hpp"
class UNiagaraSystem;
class UNiagaraPreviewAxis;
class UClass;
class UChildActorComponent;
class UNiagaraComponent;
#pragma pack(push, 1)
class ANiagaraPreviewGrid : public AActor {
public:
    UNiagaraSystem* System; // 0x220
    ENiagaraPreviewGridResetMode ResetMode; // 0x228
    char pad_229[0x7];
    UNiagaraPreviewAxis* PreviewAxisX; // 0x230
    UNiagaraPreviewAxis* PreviewAxisY; // 0x238
    UClass* PreviewClass; // 0x240
    float SpacingX; // 0x248
    float SpacingY; // 0x24c
    int32_t NumX; // 0x250
    int32_t NumY; // 0x254
    TArray<UChildActorComponent*> PreviewComponents; // 0x258
    char pad_268[0x8];
    static ANiagaraPreviewGrid* StaticClass();
    void SetPaused(bool bPaused);
    void GetPreviews(TArray<UNiagaraComponent*>& OutPreviews);
    void DeactivatePreviews();
    void ActivatePreviews(bool bReset);
}; // Size: 0x270
#pragma pack(pop)
