#include "AAtmosphericFog.hpp"
#include "AInfo.hpp"
#include "UAtmosphericFogComponent.hpp"
AAtmosphericFog* AAtmosphericFog::StaticClass() {
    static auto res = find_uobject(4277120499582238545); // Class /Script/Engine.AtmosphericFog
    return (AAtmosphericFog*)res;
}
