#pragma once
#include <cstdint>
#include "AInfo.hpp"
class UClass;
class AGameModeBase;
class APlayerState;
class AController;
#pragma pack(push, 1)
class AGameStateBase : public AInfo {
public:
    UClass* GameModeClass; // 0x220
    AGameModeBase* AuthorityGameMode; // 0x228
    UClass* SpectatorClass; // 0x230
    TArray<APlayerState*> PlayerArray; // 0x238
    bool bReplicatedHasBegunPlay; // 0x248
    char pad_249[0x3];
    float ReplicatedWorldTimeSeconds; // 0x24c
    float ServerWorldTimeSecondsDelta; // 0x250
    float ServerWorldTimeSecondsUpdateFrequency; // 0x254
    char pad_258[0x18];
    static AGameStateBase* StaticClass();
    void OnRep_SpectatorClass();
    void OnRep_ReplicatedWorldTimeSeconds();
    void OnRep_ReplicatedHasBegunPlay();
    void OnRep_GameModeClass();
    bool HasMatchStarted();
    bool HasMatchEnded();
    bool HasBegunPlay();
    float GetServerWorldTimeSeconds();
    float GetPlayerStartTime(AController* Controller);
    float GetPlayerRespawnDelay(AController* Controller);
}; // Size: 0x270
#pragma pack(pop)
