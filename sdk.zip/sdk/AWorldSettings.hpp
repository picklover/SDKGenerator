#pragma once
#include <cstdint>
#include "AInfo.hpp"
#include "EVisibilityAggressiveness.hpp"
#include "FBroadphaseSettings.hpp"
#include "FInteriorSettings.hpp"
#include "FNetViewer.hpp"
#include "FReverbSettings.hpp"
#include "FVector.hpp"
class UNavigationSystemConfig;
class UClass;
class UAssetUserData;
class USoundMix;
class APlayerState;
class UBookmarkBase;
#pragma pack(push, 1)
class AWorldSettings : public AInfo {
public:
    char pad_220[0x8];
    int32_t VisibilityCellSize; // 0x228
    EVisibilityAggressiveness VisibilityAggressiveness; // 0x22c
    uint8_t bPrecomputeVisibility : 1; // 0x22d
    uint8_t bPlaceCellsOnlyAlongCameraTracks : 1; // 0x22d
    uint8_t bEnableWorldBoundsChecks : 1; // 0x22d
    uint8_t bEnableNavigationSystem : 1; // 0x22d
    uint8_t bEnableAISystem : 1; // 0x22d
    uint8_t bEnableWorldComposition : 1; // 0x22d
    uint8_t bUseClientSideLevelStreamingVolumes : 1; // 0x22d
    uint8_t bEnableWorldOriginRebasing : 1; // 0x22d
    uint8_t bWorldGravitySet : 1; // 0x22e
    uint8_t bGlobalGravitySet : 1; // 0x22e
    uint8_t bMinimizeBSPSections : 1; // 0x22e
    uint8_t bForceNoPrecomputedLighting : 1; // 0x22e
    uint8_t bHighPriorityLoading : 1; // 0x22e
    uint8_t bHighPriorityLoadingLocal : 1; // 0x22e
    uint8_t bOverrideDefaultBroadphaseSettings : 1; // 0x22e
    uint8_t pad_bitfield_22e_7 : 1;
    char pad_22f[0x1];
    UNavigationSystemConfig* NavigationSystemConfig; // 0x230
    UNavigationSystemConfig* NavigationSystemConfigOverride; // 0x238
    float WorldToMeters; // 0x240
    float KillZ; // 0x244
    UClass* KillZDamageType; // 0x248
    float WorldGravityZ; // 0x250
    float GlobalGravityZ; // 0x254
    UClass* DefaultPhysicsVolumeClass; // 0x258
    UClass* PhysicsCollisionHandlerClass; // 0x260
    UClass* DefaultGameMode; // 0x268
    UClass* GameNetworkManagerClass; // 0x270
    int32_t PackedLightAndShadowMapTextureSize; // 0x278
    FVector DefaultColorScale; // 0x27c
    float DefaultMaxDistanceFieldOcclusionDistance; // 0x288
    float GlobalDistanceFieldViewDistance; // 0x28c
    float DynamicIndirectShadowsSelfShadowingIntensity; // 0x290
    char pad_294[0x4];
    FReverbSettings DefaultReverbSettings; // 0x298
    FInteriorSettings DefaultAmbientZoneSettings; // 0x2b8
    char pad_2dc[0x4];
    USoundMix* DefaultBaseSoundMix; // 0x2e0
    float TimeDilation; // 0x2e8
    float MatineeTimeDilation; // 0x2ec
    float DemoPlayTimeDilation; // 0x2f0
    float MinGlobalTimeDilation; // 0x2f4
    float MaxGlobalTimeDilation; // 0x2f8
    float MinUndilatedFrameTime; // 0x2fc
    float MaxUndilatedFrameTime; // 0x300
    FBroadphaseSettings BroadphaseSettings; // 0x304
    char pad_344[0x4];
    APlayerState* Pauser; // 0x348
    TArray<FNetViewer> ReplicationViewers; // 0x350
    TArray<UAssetUserData*> AssetUserData; // 0x360
    APlayerState* PauserPlayerState; // 0x370
    int32_t MaxNumberOfBookmarks; // 0x378
    char pad_37c[0x4];
    UClass* DefaultBookmarkClass; // 0x380
    TArray<UBookmarkBase*> BookmarkArray; // 0x388
    UClass* LastBookmarkClass; // 0x398
    static AWorldSettings* StaticClass();
    void OnRep_WorldGravityZ();
}; // Size: 0x3a0
#pragma pack(pop)
