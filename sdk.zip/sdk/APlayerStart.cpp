#include "ANavigationObjectBase.hpp"
#include "APlayerStart.hpp"
APlayerStart* APlayerStart::StaticClass() {
    static auto res = find_uobject(1428753885720268213); // Class /Script/Engine.PlayerStart
    return (APlayerStart*)res;
}
