#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "EComponentMobility\Type.hpp"
#include "EDatasmithAreaLightActorShape.hpp"
#include "EDatasmithAreaLightActorType.hpp"
#include "ELightUnits.hpp"
#include "FLinearColor.hpp"
#include "FRotator.hpp"
#include "FVector2D.hpp"
class UTextureLightProfile;
#pragma pack(push, 1)
class ADatasmithAreaLightActor : public AActor {
public:
    EComponentMobility::Type Mobility; // 0x220
    EDatasmithAreaLightActorType LightType; // 0x221
    EDatasmithAreaLightActorShape LightShape; // 0x222
    char pad_223[0x1];
    FVector2D Dimensions; // 0x224
    float Intensity; // 0x22c
    ELightUnits IntensityUnits; // 0x230
    char pad_231[0x3];
    FLinearColor Color; // 0x234
    float Temperature; // 0x244
    UTextureLightProfile* IESTexture; // 0x248
    bool bUseIESBrightness; // 0x250
    char pad_251[0x3];
    float IESBrightnessScale; // 0x254
    FRotator Rotation; // 0x258
    float SourceRadius; // 0x264
    float SourceLength; // 0x268
    float AttenuationRadius; // 0x26c
    float SpotlightInnerAngle; // 0x270
    float SpotlightOuterAngle; // 0x274
    static ADatasmithAreaLightActor* StaticClass();
}; // Size: 0x278
#pragma pack(pop)
