#pragma once
#include <cstdint>
#include "AOnlineBeaconHostObject.hpp"
#pragma pack(push, 1)
class ATestBeaconHost : public AOnlineBeaconHostObject {
public:
    static ATestBeaconHost* StaticClass();
}; // Size: 0x248
#pragma pack(pop)
