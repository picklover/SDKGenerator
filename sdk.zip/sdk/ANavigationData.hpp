#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "ERuntimeGenerationType.hpp"
#include "FNavDataConfig.hpp"
#include "FSupportedAreaData.hpp"
class UPrimitiveComponent;
#pragma pack(push, 1)
class ANavigationData : public AActor {
public:
    char pad_220[0x8];
    UPrimitiveComponent* RenderingComp; // 0x228
    FNavDataConfig NavDataConfig; // 0x230
    uint8_t bEnableDrawing : 1; // 0x2a8
    uint8_t bForceRebuildOnLoad : 1; // 0x2a8
    uint8_t bAutoDestroyWhenNoNavigation : 1; // 0x2a8
    uint8_t bCanBeMainNavData : 1; // 0x2a8
    uint8_t bCanSpawnOnRebuild : 1; // 0x2a8
    uint8_t bRebuildAtRuntime : 1; // 0x2a8
    uint8_t pad_bitfield_2a8_6 : 2;
    char pad_2a9[0x3];
    ERuntimeGenerationType RuntimeGeneration; // 0x2ac
    char pad_2ad[0x3];
    float ObservedPathsTickInterval; // 0x2b0
    uint32_t DataVersion; // 0x2b4
    char pad_2b8[0x108];
    TArray<FSupportedAreaData> SupportedAreas; // 0x3c0
    char pad_3d0[0x58];
    static ANavigationData* StaticClass();
}; // Size: 0x428
#pragma pack(pop)
