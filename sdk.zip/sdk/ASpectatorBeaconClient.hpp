#pragma once
#include <cstdint>
#include "AOnlineBeaconClient.hpp"
#include "ESpectatorClientRequestType.hpp"
#include "ESpectatorReservationResult\Type.hpp"
#include "FSpectatorReservation.hpp"
struct FUniqueNetIdRepl;
#pragma pack(push, 1)
class ASpectatorBeaconClient : public AOnlineBeaconClient {
public:
    char pad_2b0[0x30];
    FString DestSessionId; // 0x2e0
    FSpectatorReservation PendingReservation; // 0x2f0
    ESpectatorClientRequestType RequestType; // 0x368
    bool bPendingReservationSent; // 0x369
    bool bCancelReservation; // 0x36a
    char pad_36b[0x2d];
    static ASpectatorBeaconClient* StaticClass();
    void ServerReservationRequest(FString SessionId, FSpectatorReservation& Reservation);
    void ServerCancelReservationRequest(FUniqueNetIdRepl& Spectator);
    void ClientSendReservationUpdates(int32_t NumRemainingReservations);
    void ClientSendReservationFull();
    void ClientReservationResponse(ESpectatorReservationResult::Type ReservationResponse);
    void ClientCancelReservationResponse(ESpectatorReservationResult::Type ReservationResponse);
}; // Size: 0x398
#pragma pack(pop)
