#include "AGameSession.hpp"
#include "AInfo.hpp"
AGameSession* AGameSession::StaticClass() {
    static auto res = find_uobject(6244819948593833912); // Class /Script/Engine.GameSession
    return (AGameSession*)res;
}
