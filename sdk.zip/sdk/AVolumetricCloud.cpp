#include "AInfo.hpp"
#include "AVolumetricCloud.hpp"
#include "UVolumetricCloudComponent.hpp"
AVolumetricCloud* AVolumetricCloud::StaticClass() {
    static auto res = find_uobject(11383152699224790419); // Class /Script/Engine.VolumetricCloud
    return (AVolumetricCloud*)res;
}
