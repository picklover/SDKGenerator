#pragma once
#include <cstdint>
#include "AShooterProjectile.hpp"
#include "FPointerToUberGraphFrame.hpp"
class UAudioComponent;
class AController;
class AActor;
class UDamageType;
#pragma pack(push, 1)
class AProjRocket_C : public AShooterProjectile {
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x270
    UAudioComponent* Audio; // 0x278
    static AProjRocket_C* StaticClass();
    void OnTakeAnyDamage_Event(AActor* DamagedActor, float Damage, UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser);
    void ExecuteUbergraph_ProjRocket(int32_t EntryPoint, AActor* K2Node_CustomEvent_DamagedActor, float K2Node_CustomEvent_Damage, UDamageType* K2Node_CustomEvent_DamageType, AController* K2Node_CustomEvent_InstigatedBy, AActor* K2Node_CustomEvent_DamageCauser);
}; // Size: 0x280
#pragma pack(pop)
