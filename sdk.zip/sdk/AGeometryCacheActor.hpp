#pragma once
#include <cstdint>
#include "AActor.hpp"
class UGeometryCacheComponent;
#pragma pack(push, 1)
class AGeometryCacheActor : public AActor {
public:
    UGeometryCacheComponent* GeometryCacheComponent; // 0x220
    static AGeometryCacheActor* StaticClass();
    UGeometryCacheComponent* GetGeometryCacheComponent();
}; // Size: 0x228
#pragma pack(pop)
