#pragma once
#include <cstdint>
#include "APlayerCameraManager.hpp"
#pragma pack(push, 1)
class AShooterPlayerCameraManager : public APlayerCameraManager {
public:
    char pad_2810[0x10];
    static AShooterPlayerCameraManager* StaticClass();
}; // Size: 0x2820
#pragma pack(pop)
