#include "AActor.hpp"
#include "ATextRenderActor.hpp"
#include "UTextRenderComponent.hpp"
ATextRenderActor* ATextRenderActor::StaticClass() {
    static auto res = find_uobject(11208273419705098914); // Class /Script/Engine.TextRenderActor
    return (ATextRenderActor*)res;
}
