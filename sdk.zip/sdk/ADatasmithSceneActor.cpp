#include "AActor.hpp"
#include "ADatasmithSceneActor.hpp"
#include "UDatasmithScene.hpp"
ADatasmithSceneActor* ADatasmithSceneActor::StaticClass() {
    static auto res = find_uobject(1591788230176497462); // Class /Script/DatasmithContent.DatasmithSceneActor
    return (ADatasmithSceneActor*)res;
}
