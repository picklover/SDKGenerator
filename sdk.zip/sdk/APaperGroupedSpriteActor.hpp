#pragma once
#include <cstdint>
#include "AActor.hpp"
class UPaperGroupedSpriteComponent;
#pragma pack(push, 1)
class APaperGroupedSpriteActor : public AActor {
public:
    UPaperGroupedSpriteComponent* RenderComponent; // 0x220
    static APaperGroupedSpriteActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
