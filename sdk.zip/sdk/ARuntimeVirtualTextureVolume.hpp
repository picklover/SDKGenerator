#pragma once
#include <cstdint>
#include "AActor.hpp"
class URuntimeVirtualTextureComponent;
#pragma pack(push, 1)
class ARuntimeVirtualTextureVolume : public AActor {
public:
    URuntimeVirtualTextureComponent* VirtualTextureComponent; // 0x220
    static ARuntimeVirtualTextureVolume* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
