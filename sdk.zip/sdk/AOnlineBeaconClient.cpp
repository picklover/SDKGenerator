#include "AOnlineBeacon.hpp"
#include "AOnlineBeaconClient.hpp"
#include "AOnlineBeaconHostObject.hpp"
#include "EBeaconConnectionState.hpp"
#include "UFunction.hpp"
#include "UNetConnection.hpp"
AOnlineBeaconClient* AOnlineBeaconClient::StaticClass() {
    static auto res = find_uobject(11415074629554773325); // Class /Script/OnlineSubsystemUtils.OnlineBeaconClient
    return (AOnlineBeaconClient*)res;
}
void AOnlineBeaconClient::ClientOnConnected() {
    static auto func = (UFunction*)(find_uobject(16145629345912380556)); // Function /Script/OnlineSubsystemUtils.OnlineBeaconClient.ClientOnConnected
    struct Params_ClientOnConnected {
    }; // Size: 0x0
    Params_ClientOnConnected params{};
    ProcessEvent(func, &params);
}
