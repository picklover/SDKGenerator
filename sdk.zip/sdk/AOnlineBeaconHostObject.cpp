#include "AActor.hpp"
#include "AOnlineBeaconClient.hpp"
#include "AOnlineBeaconHostObject.hpp"
#include "UClass.hpp"
AOnlineBeaconHostObject* AOnlineBeaconHostObject::StaticClass() {
    static auto res = find_uobject(4657204710941374415); // Class /Script/OnlineSubsystemUtils.OnlineBeaconHostObject
    return (AOnlineBeaconHostObject*)res;
}
