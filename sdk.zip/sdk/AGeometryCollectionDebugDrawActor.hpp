#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "EGeometryCollectionDebugDrawActorHideGeometry.hpp"
#include "FColor.hpp"
#include "FGeometryCollectionDebugDrawActorSelectedRigidBody.hpp"
#include "FGeometryCollectionDebugDrawWarningMessage.hpp"
class UBillboardComponent;
#pragma pack(push, 1)
class AGeometryCollectionDebugDrawActor : public AActor {
public:
    FGeometryCollectionDebugDrawWarningMessage WarningMessage; // 0x220
    char pad_221[0x7];
    FGeometryCollectionDebugDrawActorSelectedRigidBody SelectedRigidBody; // 0x228
    bool bDebugDrawWholeCollection; // 0x240
    bool bDebugDrawHierarchy; // 0x241
    bool bDebugDrawClustering; // 0x242
    EGeometryCollectionDebugDrawActorHideGeometry HideGeometry; // 0x243
    bool bShowRigidBodyId; // 0x244
    bool bShowRigidBodyCollision; // 0x245
    bool bCollisionAtOrigin; // 0x246
    bool bShowRigidBodyTransform; // 0x247
    bool bShowRigidBodyInertia; // 0x248
    bool bShowRigidBodyVelocity; // 0x249
    bool bShowRigidBodyForce; // 0x24a
    bool bShowRigidBodyInfos; // 0x24b
    bool bShowTransformIndex; // 0x24c
    bool bShowTransform; // 0x24d
    bool bShowParent; // 0x24e
    bool bShowLevel; // 0x24f
    bool bShowConnectivityEdges; // 0x250
    bool bShowGeometryIndex; // 0x251
    bool bShowGeometryTransform; // 0x252
    bool bShowBoundingBox; // 0x253
    bool bShowFaces; // 0x254
    bool bShowFaceIndices; // 0x255
    bool bShowFaceNormals; // 0x256
    bool bShowSingleFace; // 0x257
    int32_t SingleFaceIndex; // 0x258
    bool bShowVertices; // 0x25c
    bool bShowVertexIndices; // 0x25d
    bool bShowVertexNormals; // 0x25e
    bool bUseActiveVisualization; // 0x25f
    float PointThickness; // 0x260
    float LineThickness; // 0x264
    bool bTextShadow; // 0x268
    char pad_269[0x3];
    float TextScale; // 0x26c
    float NormalScale; // 0x270
    float AxisScale; // 0x274
    float ArrowScale; // 0x278
    FColor RigidBodyIdColor; // 0x27c
    float RigidBodyTransformScale; // 0x280
    FColor RigidBodyCollisionColor; // 0x284
    FColor RigidBodyInertiaColor; // 0x288
    FColor RigidBodyVelocityColor; // 0x28c
    FColor RigidBodyForceColor; // 0x290
    FColor RigidBodyInfoColor; // 0x294
    FColor TransformIndexColor; // 0x298
    float TransformScale; // 0x29c
    FColor LevelColor; // 0x2a0
    FColor ParentColor; // 0x2a4
    float ConnectivityEdgeThickness; // 0x2a8
    FColor GeometryIndexColor; // 0x2ac
    float GeometryTransformScale; // 0x2b0
    FColor BoundingBoxColor; // 0x2b4
    FColor FaceColor; // 0x2b8
    FColor FaceIndexColor; // 0x2bc
    FColor FaceNormalColor; // 0x2c0
    FColor SingleFaceColor; // 0x2c4
    FColor VertexColor; // 0x2c8
    FColor VertexIndexColor; // 0x2cc
    FColor VertexNormalColor; // 0x2d0
    char pad_2d4[0x4];
    UBillboardComponent* SpriteComponent; // 0x2d8
    char pad_2e0[0x28];
    static AGeometryCollectionDebugDrawActor* StaticClass();
}; // Size: 0x308
#pragma pack(pop)
