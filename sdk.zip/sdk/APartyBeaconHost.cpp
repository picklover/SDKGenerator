#include "AOnlineBeaconHostObject.hpp"
#include "APartyBeaconHost.hpp"
#include "UPartyBeaconState.hpp"
APartyBeaconHost* APartyBeaconHost::StaticClass() {
    static auto res = find_uobject(7113447123076112221); // Class /Script/OnlineSubsystemUtils.PartyBeaconHost
    return (APartyBeaconHost*)res;
}
