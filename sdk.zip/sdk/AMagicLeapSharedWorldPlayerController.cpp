#include "AMagicLeapSharedWorldPlayerController.hpp"
#include "APlayerController.hpp"
#include "FMagicLeapSharedWorldAlignmentTransforms.hpp"
#include "FMagicLeapSharedWorldLocalData.hpp"
#include "UFunction.hpp"
void AMagicLeapSharedWorldPlayerController::ClientMarkReadyForSendingLocalData() {
    static auto func = (UFunction*)(find_uobject(14075881599953302358)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ClientMarkReadyForSendingLocalData
    struct Params_ClientMarkReadyForSendingLocalData {
    }; // Size: 0x0
    Params_ClientMarkReadyForSendingLocalData params{};
    ProcessEvent(func, &params);
}
AMagicLeapSharedWorldPlayerController* AMagicLeapSharedWorldPlayerController::StaticClass() {
    static auto res = find_uobject(9908242615252694285); // Class /Script/MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController
    return (AMagicLeapSharedWorldPlayerController*)res;
}
void AMagicLeapSharedWorldPlayerController::ServerSetLocalWorldData(FMagicLeapSharedWorldLocalData& LocalWorldReplicationData) {
    static auto func = (UFunction*)(find_uobject(13418348556973427725)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetLocalWorldData
    struct Params_ServerSetLocalWorldData {
        FMagicLeapSharedWorldLocalData LocalWorldReplicationData; // 0x0
    }; // Size: 0x10
    Params_ServerSetLocalWorldData params{};
    params.LocalWorldReplicationData = (FMagicLeapSharedWorldLocalData)LocalWorldReplicationData;
    ProcessEvent(func, &params);
    LocalWorldReplicationData = params.LocalWorldReplicationData;
}
bool AMagicLeapSharedWorldPlayerController::CanSendLocalDataToServer() {
    static auto func = (UFunction*)(find_uobject(11813736844961388470)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.CanSendLocalDataToServer
    struct Params_CanSendLocalDataToServer {
        bool ReturnValue; // 0x0
    }; // Size: 0x1
    Params_CanSendLocalDataToServer params{};
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
void AMagicLeapSharedWorldPlayerController::ServerSetAlignmentTransforms(FMagicLeapSharedWorldAlignmentTransforms& InAlignmentTransforms) {
    static auto func = (UFunction*)(find_uobject(2153839994877103844)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetAlignmentTransforms
    struct Params_ServerSetAlignmentTransforms {
        FMagicLeapSharedWorldAlignmentTransforms InAlignmentTransforms; // 0x0
    }; // Size: 0x10
    Params_ServerSetAlignmentTransforms params{};
    params.InAlignmentTransforms = (FMagicLeapSharedWorldAlignmentTransforms)InAlignmentTransforms;
    ProcessEvent(func, &params);
    InAlignmentTransforms = params.InAlignmentTransforms;
}
bool AMagicLeapSharedWorldPlayerController::IsChosenOne() {
    static auto func = (UFunction*)(find_uobject(342201107799742259)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.IsChosenOne
    struct Params_IsChosenOne {
        bool ReturnValue; // 0x0
    }; // Size: 0x1
    Params_IsChosenOne params{};
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
void AMagicLeapSharedWorldPlayerController::ClientSetChosenOne(bool bChosenOne) {
    static auto func = (UFunction*)(find_uobject(17504205110567540410)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ClientSetChosenOne
    struct Params_ClientSetChosenOne {
        bool bChosenOne; // 0x0
    }; // Size: 0x1
    Params_ClientSetChosenOne params{};
    params.bChosenOne = (bool)bChosenOne;
    ProcessEvent(func, &params);
}
