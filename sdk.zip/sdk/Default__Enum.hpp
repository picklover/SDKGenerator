#pragma once
#include <cstdint>
#pragma pack(push, 1)
enum Default__Enum {
};
#pragma pack(pop)
