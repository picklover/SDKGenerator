#pragma once
#include <cstdint>
#include "ACharacter.hpp"
#include "FRotator.hpp"
#include "FTakeHitInfo.hpp"
class USkeletalMeshComponent;
class USoundCue;
class UClass;
class AShooterWeapon;
class UMaterialInstanceDynamic;
class UAnimMontage;
class UParticleSystem;
class UAudioComponent;
#pragma pack(push, 1)
class AShooterCharacter : public ACharacter {
public:
    FName WeaponAttachPoint; // 0x4c0
    TArray<UClass*> DefaultInventoryClasses; // 0x4c8
    TArray<AShooterWeapon*> Inventory; // 0x4d8
    AShooterWeapon* CurrentWeapon; // 0x4e8
    FTakeHitInfo LastTakeHitInfo; // 0x4f0
    char pad_618[0x4];
    float TargetingSpeedModifier; // 0x61c
    uint8_t bIsTargeting : 1; // 0x620
    uint8_t pad_bitfield_620_1 : 7;
    char pad_621[0x3];
    float RunningSpeedModifier; // 0x624
    uint8_t bWantsToRun : 1; // 0x628
    uint8_t pad_bitfield_628_1 : 7;
    char pad_629[0xf];
    TArray<UMaterialInstanceDynamic*> MeshMIDs; // 0x638
    UAnimMontage* DeathAnim; // 0x648
    USoundCue* DeathSound; // 0x650
    UParticleSystem* RespawnFX; // 0x658
    USoundCue* RespawnSound; // 0x660
    USoundCue* LowHealthSound; // 0x668
    USoundCue* RunLoopSound; // 0x670
    USoundCue* RunStopSound; // 0x678
    USoundCue* TargetingSound; // 0x680
    UAudioComponent* RunLoopAC; // 0x688
    UAudioComponent* LowHealthWarningPlayer; // 0x690
    uint8_t bIsDying : 1; // 0x698
    uint8_t pad_bitfield_698_1 : 7;
    char pad_699[0x3];
    float Health; // 0x69c
    static AShooterCharacter* StaticClass();
    void ServerSetTargeting(bool bNewTargeting);
    void ServerSetRunning(bool bNewRunning, bool bToggle);
    void ServerEquipWeapon(AShooterWeapon* NewWeapon);
    void OnRep_LastTakeHitInfo();
    void OnRep_CurrentWeapon(AShooterWeapon* LastWeapon);
    bool IsTargeting();
    bool IsRunning();
    bool IsFirstPerson();
    bool IsFiring();
    AShooterWeapon* GetWeapon();
    float GetTargetingSpeedModifier();
    float GetRunningSpeedModifier();
    FRotator GetAimOffsets();
}; // Size: 0x6a0
#pragma pack(pop)
