#include "AGameNetworkManager.hpp"
#include "AInfo.hpp"
AGameNetworkManager* AGameNetworkManager::StaticClass() {
    static auto res = find_uobject(8372786046294400745); // Class /Script/Engine.GameNetworkManager
    return (AGameNetworkManager*)res;
}
