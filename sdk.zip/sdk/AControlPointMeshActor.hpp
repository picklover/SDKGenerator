#pragma once
#include <cstdint>
#include "AActor.hpp"
class UControlPointMeshComponent;
#pragma pack(push, 1)
class AControlPointMeshActor : public AActor {
public:
    UControlPointMeshComponent* ControlPointMeshComponent; // 0x220
    static AControlPointMeshActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
