#pragma once
#include <cstdint>
#include "ASceneCapture.hpp"
class UPlanarReflectionComponent;
#pragma pack(push, 1)
class APlanarReflection : public ASceneCapture {
public:
    UPlanarReflectionComponent* PlanarReflectionComponent; // 0x230
    bool bShowPreviewPlane; // 0x238
    char pad_239[0x7];
    static APlanarReflection* StaticClass();
    void OnInterpToggle(bool bEnable);
}; // Size: 0x240
#pragma pack(pop)
