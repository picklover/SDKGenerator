#pragma once
#include <cstdint>
#include "AActor.hpp"
class UProjectileMovementComponent;
class USphereComponent;
class UClass;
class UParticleSystemComponent;
struct FHitResult;
#pragma pack(push, 1)
class AShooterProjectile : public AActor {
public:
    UProjectileMovementComponent* MovementComp; // 0x220
    USphereComponent* CollisionComp; // 0x228
    UParticleSystemComponent* ParticleComp; // 0x230
    UClass* ExplosionTemplate; // 0x238
    char pad_240[0x28];
    bool bExploded; // 0x268
    char pad_269[0x7];
    static AShooterProjectile* StaticClass();
    void OnRep_Exploded();
    void OnImpact(FHitResult& HitResult);
}; // Size: 0x270
#pragma pack(pop)
