#pragma once
#include <cstdint>
#include "ARigidBodyBase.hpp"
class UPhysicsConstraintComponent;
class AActor;
#pragma pack(push, 1)
class APhysicsConstraintActor : public ARigidBodyBase {
public:
    UPhysicsConstraintComponent* ConstraintComp; // 0x220
    AActor* ConstraintActor1; // 0x228
    AActor* ConstraintActor2; // 0x230
    uint8_t bDisableCollision : 1; // 0x238
    uint8_t pad_bitfield_238_1 : 7;
    char pad_239[0x7];
    static APhysicsConstraintActor* StaticClass();
}; // Size: 0x240
#pragma pack(pop)
