#pragma once
#include <cstdint>
#include "AShooterPickup.hpp"
#pragma pack(push, 1)
class AShooterPickup_Health : public AShooterPickup {
public:
    int32_t Health; // 0x260
    char pad_264[0x4];
    static AShooterPickup_Health* StaticClass();
}; // Size: 0x268
#pragma pack(pop)
