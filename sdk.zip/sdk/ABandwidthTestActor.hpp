#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FBandwidthTestGenerator.hpp"
#pragma pack(push, 1)
class ABandwidthTestActor : public AActor {
public:
    FBandwidthTestGenerator BandwidthGenerator; // 0x220
    static ABandwidthTestActor* StaticClass();
}; // Size: 0x240
#pragma pack(pop)
