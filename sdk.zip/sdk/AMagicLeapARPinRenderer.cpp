#include "AActor.hpp"
#include "AMagicLeapARPinRenderer.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
AMagicLeapARPinRenderer* AMagicLeapARPinRenderer::StaticClass() {
    static auto res = find_uobject(1170275604421356605); // Class /Script/MagicLeapARPin.MagicLeapARPinRenderer
    return (AMagicLeapARPinRenderer*)res;
}
void AMagicLeapARPinRenderer::SetVisibilityOverride(bool InVisibilityOverride) {
    static auto func = (UFunction*)(find_uobject(13098367122161924289)); // Function /Script/MagicLeapARPin.MagicLeapARPinRenderer.SetVisibilityOverride
    struct Params_SetVisibilityOverride {
        bool InVisibilityOverride; // 0x0
    }; // Size: 0x1
    Params_SetVisibilityOverride params{};
    params.InVisibilityOverride = (bool)InVisibilityOverride;
    ProcessEvent(func, &params);
}
