#pragma once
#include <cstdint>
#include "AGizmoActor.hpp"
class UPrimitiveComponent;
#pragma pack(push, 1)
class ATransformGizmoActor : public AGizmoActor {
public:
    UPrimitiveComponent* TranslateX; // 0x220
    UPrimitiveComponent* TranslateY; // 0x228
    UPrimitiveComponent* TranslateZ; // 0x230
    UPrimitiveComponent* TranslateYZ; // 0x238
    UPrimitiveComponent* TranslateXZ; // 0x240
    UPrimitiveComponent* TranslateXY; // 0x248
    UPrimitiveComponent* RotateX; // 0x250
    UPrimitiveComponent* RotateY; // 0x258
    UPrimitiveComponent* RotateZ; // 0x260
    UPrimitiveComponent* UniformScale; // 0x268
    UPrimitiveComponent* AxisScaleX; // 0x270
    UPrimitiveComponent* AxisScaleY; // 0x278
    UPrimitiveComponent* AxisScaleZ; // 0x280
    UPrimitiveComponent* PlaneScaleYZ; // 0x288
    UPrimitiveComponent* PlaneScaleXZ; // 0x290
    UPrimitiveComponent* PlaneScaleXY; // 0x298
    static ATransformGizmoActor* StaticClass();
}; // Size: 0x2a0
#pragma pack(pop)
