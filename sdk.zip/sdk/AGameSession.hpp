#pragma once
#include <cstdint>
#include "AInfo.hpp"
#pragma pack(push, 1)
class AGameSession : public AInfo {
public:
    int32_t MaxSpectators; // 0x220
    int32_t MaxPlayers; // 0x224
    int32_t MaxPartySize; // 0x228
    uint8_t MaxSplitscreensPerConnection; // 0x22c
    bool bRequiresPushToTalk; // 0x22d
    char pad_22e[0x2];
    FName SessionName; // 0x230
    static AGameSession* StaticClass();
}; // Size: 0x238
#pragma pack(pop)
