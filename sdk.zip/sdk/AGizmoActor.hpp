#pragma once
#include <cstdint>
#include "AInternalToolFrameworkActor.hpp"
#pragma pack(push, 1)
class AGizmoActor : public AInternalToolFrameworkActor {
public:
    static AGizmoActor* StaticClass();
}; // Size: 0x220
#pragma pack(pop)
