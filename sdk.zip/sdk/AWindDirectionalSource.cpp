#include "AInfo.hpp"
#include "AWindDirectionalSource.hpp"
#include "UWindDirectionalSourceComponent.hpp"
AWindDirectionalSource* AWindDirectionalSource::StaticClass() {
    static auto res = find_uobject(12674833129819252189); // Class /Script/Engine.WindDirectionalSource
    return (AWindDirectionalSource*)res;
}
