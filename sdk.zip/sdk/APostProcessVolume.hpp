#pragma once
#include <cstdint>
#include "AVolume.hpp"
#include "FPostProcessSettings.hpp"
#pragma pack(push, 1)
class APostProcessVolume : public AVolume {
public:
    char pad_258[0x8];
    FPostProcessSettings Settings; // 0x260
    float Priority; // 0x7c0
    float BlendRadius; // 0x7c4
    float BlendWeight; // 0x7c8
    uint8_t bEnabled : 1; // 0x7cc
    uint8_t bUnbound : 1; // 0x7cc
    uint8_t pad_bitfield_7cc_2 : 6;
    char pad_7cd[0x3];
    static APostProcessVolume* StaticClass();
    void AddOrUpdateBlendable();
}; // Size: 0x7d0
#pragma pack(pop)
