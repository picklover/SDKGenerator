#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FCanvasIcon.hpp"
#include "FWeaponAnim.hpp"
#include "FWeaponData.hpp"
class AShooterCharacter;
class UAudioComponent;
class USkeletalMeshComponent;
class USoundCue;
class UParticleSystem;
class UForceFeedbackEffect;
class UParticleSystemComponent;
class UClass;
#pragma pack(push, 1)
class AShooterWeapon : public AActor {
public:
    FCanvasIcon PrimaryIcon; // 0x220
    FCanvasIcon SecondaryIcon; // 0x238
    FCanvasIcon PrimaryClipIcon; // 0x250
    FCanvasIcon SecondaryClipIcon; // 0x268
    float AmmoIconsCount; // 0x280
    int32_t PrimaryClipIconOffset; // 0x284
    int32_t SecondaryClipIconOffset; // 0x288
    char pad_28c[0x4];
    FCanvasIcon Crosshair[5]; // 0x290
    FCanvasIcon AimingCrosshair[5]; // 0x308
    bool UseLaserDot; // 0x380
    bool UseCustomCrosshair; // 0x381
    bool UseCustomAimingCrosshair; // 0x382
    bool bHideCrosshairWhileNotAiming; // 0x383
    float TimerIntervalAdjustment; // 0x384
    bool bAllowAutomaticWeaponCatchup; // 0x388
    char pad_389[0x7];
    AShooterCharacter* MyPawn; // 0x390
    FWeaponData WeaponConfig; // 0x398
    USkeletalMeshComponent* Mesh1P; // 0x3b0
    USkeletalMeshComponent* Mesh3P; // 0x3b8
    UAudioComponent* FireAC; // 0x3c0
    FName MuzzleAttachPoint; // 0x3c8
    UParticleSystem* MuzzleFX; // 0x3d0
    UParticleSystemComponent* MuzzlePSC; // 0x3d8
    UParticleSystemComponent* MuzzlePSCSecondary; // 0x3e0
    UClass* FireCameraShake; // 0x3e8
    UForceFeedbackEffect* FireForceFeedback; // 0x3f0
    USoundCue* FireSound; // 0x3f8
    USoundCue* FireLoopSound; // 0x400
    USoundCue* FireFinishSound; // 0x408
    USoundCue* OutOfAmmoSound; // 0x410
    USoundCue* ReloadSound; // 0x418
    FWeaponAnim ReloadAnim; // 0x420
    USoundCue* EquipSound; // 0x430
    FWeaponAnim EquipAnim; // 0x438
    FWeaponAnim FireAnim; // 0x448
    uint8_t bLoopedMuzzleFX : 1; // 0x458
    uint8_t bLoopedFireSound : 1; // 0x458
    uint8_t bLoopedFireAnim : 1; // 0x458
    uint8_t pad_bitfield_458_3 : 3;
    uint8_t bPendingReload : 1; // 0x458
    uint8_t pad_bitfield_458_7 : 1;
    char pad_459[0x17];
    int32_t CurrentAmmo; // 0x470
    int32_t CurrentAmmoInClip; // 0x474
    int32_t BurstCounter; // 0x478
    char pad_47c[0x24];
    static AShooterWeapon* StaticClass();
    void ServerStopReload();
    void ServerStopFire();
    void ServerStartReload();
    void ServerStartFire();
    void ServerHandleFiring();
    void OnRep_Reload();
    void OnRep_MyPawn();
    void OnRep_BurstCounter();
    AShooterCharacter* GetPawnOwner();
    void ClientStartReload();
}; // Size: 0x4a0
#pragma pack(pop)
