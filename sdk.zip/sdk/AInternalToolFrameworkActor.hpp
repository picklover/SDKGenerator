#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class AInternalToolFrameworkActor : public AActor {
public:
    static AInternalToolFrameworkActor* StaticClass();
}; // Size: 0x220
#pragma pack(pop)
