#include "ANavigationData.hpp"
#include "ANavigationGraph.hpp"
ANavigationGraph* ANavigationGraph::StaticClass() {
    static auto res = find_uobject(3665241374930278869); // Class /Script/NavigationSystem.NavigationGraph
    return (ANavigationGraph*)res;
}
