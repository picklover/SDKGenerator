#pragma once
#include <cstdint>
#include "APhysicsVolume.hpp"
class UClass;
class AController;
#pragma pack(push, 1)
class APainCausingVolume : public APhysicsVolume {
public:
    uint8_t bPainCausing : 1; // 0x268
    uint8_t pad_bitfield_268_1 : 7;
    char pad_269[0x3];
    float DamagePerSec; // 0x26c
    UClass* DamageType; // 0x270
    float PainInterval; // 0x278
    uint8_t bEntryPain : 1; // 0x27c
    uint8_t BACKUP_bPainCausing : 1; // 0x27c
    uint8_t pad_bitfield_27c_2 : 6;
    char pad_27d[0x3];
    AController* DamageInstigator; // 0x280
    char pad_288[0x8];
    static APainCausingVolume* StaticClass();
}; // Size: 0x290
#pragma pack(pop)
