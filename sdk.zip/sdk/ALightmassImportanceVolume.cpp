#include "ALightmassImportanceVolume.hpp"
#include "AVolume.hpp"
ALightmassImportanceVolume* ALightmassImportanceVolume::StaticClass() {
    static auto res = find_uobject(3300521243892957170); // Class /Script/Engine.LightmassImportanceVolume
    return (ALightmassImportanceVolume*)res;
}
