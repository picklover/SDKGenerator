#include "APlayerStart.hpp"
#include "AShooterTeamStart.hpp"
AShooterTeamStart* AShooterTeamStart::StaticClass() {
    static auto res = find_uobject(2791977606295802509); // Class /Script/ShooterGame.ShooterTeamStart
    return (AShooterTeamStart*)res;
}
