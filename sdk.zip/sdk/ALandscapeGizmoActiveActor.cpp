#include "ALandscapeGizmoActiveActor.hpp"
#include "ALandscapeGizmoActor.hpp"
ALandscapeGizmoActiveActor* ALandscapeGizmoActiveActor::StaticClass() {
    static auto res = find_uobject(9618097763172664469); // Class /Script/Landscape.LandscapeGizmoActiveActor
    return (ALandscapeGizmoActiveActor*)res;
}
