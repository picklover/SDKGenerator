#pragma once
#include <cstdint>
#include "AInfo.hpp"
class UExponentialHeightFogComponent;
#pragma pack(push, 1)
class AExponentialHeightFog : public AInfo {
public:
    UExponentialHeightFogComponent* Component; // 0x220
    uint8_t bEnabled : 1; // 0x228
    uint8_t pad_bitfield_228_1 : 7;
    char pad_229[0x7];
    static AExponentialHeightFog* StaticClass();
    void OnRep_bEnabled();
}; // Size: 0x230
#pragma pack(pop)
