#include "AActor.hpp"
#include "ACameraShakeSourceActor.hpp"
#include "UCameraShakeSourceComponent.hpp"
ACameraShakeSourceActor* ACameraShakeSourceActor::StaticClass() {
    static auto res = find_uobject(7010817522326554985); // Class /Script/Engine.CameraShakeSourceActor
    return (ACameraShakeSourceActor*)res;
}
