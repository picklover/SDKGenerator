#pragma once
#include <cstdint>
#include "ACharacter.hpp"
#pragma pack(push, 1)
class AArchVisCharacter : public ACharacter {
public:
    char pad_4c0[0x8];
    FString LookUpAtRateAxisName; // 0x4c8
    FString TurnAxisName; // 0x4d8
    FString TurnAtRateAxisName; // 0x4e8
    FString MoveForwardAxisName; // 0x4f8
    FString MoveRightAxisName; // 0x508
    float MouseSensitivityScale_Pitch; // 0x518
    float MouseSensitivityScale_Yaw; // 0x51c
    static AArchVisCharacter* StaticClass();
}; // Size: 0x520
#pragma pack(pop)
