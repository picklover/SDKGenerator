#pragma once
#include <cstdint>
#include "ANavigationData.hpp"
#include "ERecastPartitioning\Type.hpp"
#include "FBox.hpp"
#include "FVector.hpp"
class UClass;
#pragma pack(push, 1)
class ARecastNavMesh : public ANavigationData {
public:
    uint8_t bDrawTriangleEdges : 1; // 0x428
    uint8_t bDrawPolyEdges : 1; // 0x428
    uint8_t bDrawFilledPolys : 1; // 0x428
    uint8_t bDrawNavMeshEdges : 1; // 0x428
    uint8_t bDrawTileBounds : 1; // 0x428
    uint8_t bDrawPathCollidingGeometry : 1; // 0x428
    uint8_t bDrawTileLabels : 1; // 0x428
    uint8_t bDrawPolygonLabels : 1; // 0x428
    uint8_t bDrawDefaultPolygonCost : 1; // 0x429
    uint8_t bDrawPolygonFlags : 1; // 0x429
    uint8_t bDrawLabelsOnPathNodes : 1; // 0x429
    uint8_t bDrawNavLinks : 1; // 0x429
    uint8_t bDrawFailedNavLinks : 1; // 0x429
    uint8_t bDrawClusters : 1; // 0x429
    uint8_t bDrawOctree : 1; // 0x429
    uint8_t bDrawOctreeDetails : 1; // 0x429
    uint8_t bDrawMarkedForbiddenPolys : 1; // 0x42a
    uint8_t bDistinctlyDrawTilesBeingBuilt : 1; // 0x42a
    uint8_t pad_bitfield_42a_2 : 6;
    char pad_42b[0x1];
    float DrawOffset; // 0x42c
    uint8_t bFixedTilePoolSize : 1; // 0x430
    uint8_t pad_bitfield_430_1 : 7;
    char pad_431[0x3];
    int32_t TilePoolSize; // 0x434
    float TileSizeUU; // 0x438
    float CellSize; // 0x43c
    float CellHeight; // 0x440
    float AgentRadius; // 0x444
    float AgentHeight; // 0x448
    float AgentMaxSlope; // 0x44c
    float AgentMaxStepHeight; // 0x450
    float MinRegionArea; // 0x454
    float MergeRegionSize; // 0x458
    float MaxSimplificationError; // 0x45c
    int32_t MaxSimultaneousTileGenerationJobsCount; // 0x460
    int32_t TileNumberHardLimit; // 0x464
    int32_t PolyRefTileBits; // 0x468
    int32_t PolyRefNavPolyBits; // 0x46c
    int32_t PolyRefSaltBits; // 0x470
    FVector NavMeshOriginOffset; // 0x474
    float DefaultDrawDistance; // 0x480
    float DefaultMaxSearchNodes; // 0x484
    float DefaultMaxHierarchicalSearchNodes; // 0x488
    ERecastPartitioning::Type RegionPartitioning; // 0x48c
    ERecastPartitioning::Type LayerPartitioning; // 0x48d
    char pad_48e[0x2];
    int32_t RegionChunkSplits; // 0x490
    int32_t LayerChunkSplits; // 0x494
    uint8_t bSortNavigationAreasByCost : 1; // 0x498
    uint8_t bPerformVoxelFiltering : 1; // 0x498
    uint8_t bMarkLowHeightAreas : 1; // 0x498
    uint8_t bUseExtraTopCellWhenMarkingAreas : 1; // 0x498
    uint8_t bFilterLowSpanSequences : 1; // 0x498
    uint8_t bFilterLowSpanFromTileCache : 1; // 0x498
    uint8_t bDoFullyAsyncNavDataGathering : 1; // 0x498
    uint8_t bUseBetterOffsetsFromCorners : 1; // 0x498
    uint8_t bStoreEmptyTileLayers : 1; // 0x499
    uint8_t bUseVirtualFilters : 1; // 0x499
    uint8_t bAllowNavLinkAsPathEnd : 1; // 0x499
    uint8_t bUseVoxelCache : 1; // 0x499
    uint8_t pad_bitfield_499_4 : 4;
    char pad_49a[0x2];
    float TileSetUpdateInterval; // 0x49c
    float HeuristicScale; // 0x4a0
    float VerticalDeviationFromGroundCompensation; // 0x4a4
    char pad_4a8[0x30];
    static ARecastNavMesh* StaticClass();
    bool K2_ReplaceAreaInTileBounds(FBox Bounds, UClass* OldArea, UClass* NewArea, bool ReplaceLinks);
}; // Size: 0x4d8
#pragma pack(pop)
