#pragma once
#include <cstdint>
#include "AActor.hpp"
class UStaticMeshComponent;
class UHLODProxy;
#pragma pack(push, 1)
class ALODActor : public AActor {
public:
    UStaticMeshComponent* StaticMeshComponent; // 0x220
    char pad_228[0x50];
    UHLODProxy* Proxy; // 0x278
    FName Key; // 0x280
    float LODDrawDistance; // 0x288
    int32_t LODLevel; // 0x28c
    TArray<AActor*> SubActors; // 0x290
    uint8_t CachedNumHLODLevels; // 0x2a0
    char pad_2a1[0x7];
    static ALODActor* StaticClass();
}; // Size: 0x2a8
#pragma pack(pop)
