#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class ANavigationGraphNode : public AActor {
public:
    static ANavigationGraphNode* StaticClass();
}; // Size: 0x220
#pragma pack(pop)
