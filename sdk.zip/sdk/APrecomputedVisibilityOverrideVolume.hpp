#pragma once
#include <cstdint>
#include "AVolume.hpp"
class AActor;
#pragma pack(push, 1)
class APrecomputedVisibilityOverrideVolume : public AVolume {
public:
    TArray<AActor*> OverrideVisibleActors; // 0x258
    TArray<AActor*> OverrideInvisibleActors; // 0x268
    TArray<FName> OverrideInvisibleLevels; // 0x278
    static APrecomputedVisibilityOverrideVolume* StaticClass();
}; // Size: 0x288
#pragma pack(pop)
