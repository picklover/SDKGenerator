#include "AShooterSpectatorPawn.hpp"
#include "ASpectatorPawn.hpp"
AShooterSpectatorPawn* AShooterSpectatorPawn::StaticClass() {
    static auto res = find_uobject(6146583601746213221); // Class /Script/ShooterGame.ShooterSpectatorPawn
    return (AShooterSpectatorPawn*)res;
}
