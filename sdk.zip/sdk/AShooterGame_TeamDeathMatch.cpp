#include "AShooterGameMode.hpp"
#include "AShooterGame_TeamDeathMatch.hpp"
AShooterGame_TeamDeathMatch* AShooterGame_TeamDeathMatch::StaticClass() {
    static auto res = find_uobject(9368942764647515203); // Class /Script/ShooterGame.ShooterGame_TeamDeathMatch
    return (AShooterGame_TeamDeathMatch*)res;
}
