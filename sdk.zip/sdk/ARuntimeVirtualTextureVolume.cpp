#include "AActor.hpp"
#include "ARuntimeVirtualTextureVolume.hpp"
#include "URuntimeVirtualTextureComponent.hpp"
ARuntimeVirtualTextureVolume* ARuntimeVirtualTextureVolume::StaticClass() {
    static auto res = find_uobject(6804624526910239838); // Class /Script/Engine.RuntimeVirtualTextureVolume
    return (ARuntimeVirtualTextureVolume*)res;
}
