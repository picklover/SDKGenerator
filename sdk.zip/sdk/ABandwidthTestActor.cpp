#include "AActor.hpp"
#include "ABandwidthTestActor.hpp"
#include "FBandwidthTestGenerator.hpp"
ABandwidthTestActor* ABandwidthTestActor::StaticClass() {
    static auto res = find_uobject(3469928430826251752); // Class /Script/Engine.BandwidthTestActor
    return (ABandwidthTestActor*)res;
}
