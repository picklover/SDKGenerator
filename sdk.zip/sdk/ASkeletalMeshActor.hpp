#pragma once
#include <cstdint>
#include "AActor.hpp"
class USkeletalMeshComponent;
class USkeletalMesh;
class UPhysicsAsset;
class UMaterialInterface;
#pragma pack(push, 1)
class ASkeletalMeshActor : public AActor {
public:
    char pad_220[0x8];
    uint8_t bShouldDoAnimNotifies : 1; // 0x228
    uint8_t bWakeOnLevelStart : 1; // 0x228
    uint8_t pad_bitfield_228_2 : 6;
    char pad_229[0x7];
    USkeletalMeshComponent* SkeletalMeshComponent; // 0x230
    USkeletalMesh* ReplicatedMesh; // 0x238
    UPhysicsAsset* ReplicatedPhysAsset; // 0x240
    UMaterialInterface* ReplicatedMaterial0; // 0x248
    UMaterialInterface* ReplicatedMaterial1; // 0x250
    char pad_258[0x50];
    static ASkeletalMeshActor* StaticClass();
    void OnRep_ReplicatedPhysAsset();
    void OnRep_ReplicatedMesh();
    void OnRep_ReplicatedMaterial1();
    void OnRep_ReplicatedMaterial0();
}; // Size: 0x2a8
#pragma pack(pop)
