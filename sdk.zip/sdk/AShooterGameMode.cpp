#include "AGameMode.hpp"
#include "AShooterAIController.hpp"
#include "AShooterGameMode.hpp"
#include "AShooterPickup.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
AShooterGameMode* AShooterGameMode::StaticClass() {
    static auto res = find_uobject(6805221490452728679); // Class /Script/ShooterGame.ShooterGameMode
    return (AShooterGameMode*)res;
}
void AShooterGameMode::SetAllowBots(bool bInAllowBots, int32_t InMaxBots) {
    static auto func = (UFunction*)(find_uobject(11102307697448109026)); // Function /Script/ShooterGame.ShooterGameMode.SetAllowBots
    struct Params_SetAllowBots {
        bool bInAllowBots; // 0x0
        char pad_1[0x3];
        int32_t InMaxBots; // 0x4
    }; // Size: 0x8
    Params_SetAllowBots params{};
    params.bInAllowBots = (bool)bInAllowBots;
    params.InMaxBots = (int32_t)InMaxBots;
    ProcessEvent(func, &params);
}
void AShooterGameMode::FinishMatch() {
    static auto func = (UFunction*)(find_uobject(11724868633041615039)); // Function /Script/ShooterGame.ShooterGameMode.FinishMatch
    struct Params_FinishMatch {
    }; // Size: 0x0
    Params_FinishMatch params{};
    ProcessEvent(func, &params);
}
