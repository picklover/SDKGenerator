#include "AArchVisCharacter.hpp"
#include "ACharacter.hpp"
AArchVisCharacter* AArchVisCharacter::StaticClass() {
    static auto res = find_uobject(7939681829406209950); // Class /Script/ArchVisCharacter.ArchVisCharacter
    return (AArchVisCharacter*)res;
}
