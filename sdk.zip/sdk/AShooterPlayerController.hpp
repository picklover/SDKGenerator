#pragma once
#include <cstdint>
#include "APlayerController.hpp"
#include "FKey.hpp"
#include "FRotator.hpp"
#include "FVector.hpp"
#pragma pack(push, 1)
class AShooterPlayerController : public APlayerController {
public:
    uint8_t bInfiniteAmmo : 1; // 0x570
    uint8_t bInfiniteClip : 1; // 0x570
    uint8_t bHealthRegen : 1; // 0x570
    uint8_t bGodMode : 1; // 0x570
    uint8_t pad_bitfield_570_4 : 4;
    char pad_571[0x68];
    bool bAnalogFireTrigger; // 0x5d9
    char pad_5da[0x2];
    float FireTriggerThreshold; // 0x5dc
    char pad_5e0[0x8];
    static AShooterPlayerController* StaticClass();
    void Suicide();
    void SimulateInputKey(FKey Key, bool bPressed);
    void SetGodMode(bool bEnable);
    void ServerSuicide();
    void ServerSay(FString Msg);
    void ServerCheat(FString Msg);
    void Say(FString Msg);
    void OnLeaderboardReadComplete(bool bWasSuccessful);
    void ClientStartOnlineGame();
    void ClientSetSpectatorCamera(FVector CameraLocation, FRotator CameraRotation);
    void ClientSendRoundEndEvent(bool bIsWinner, int32_t ExpendedTimeInSeconds);
    void ClientGameStarted();
    void ClientEndOnlineGame();
}; // Size: 0x5e8
#pragma pack(pop)
