#include "ANavModifierVolume.hpp"
#include "AVolume.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
ANavModifierVolume* ANavModifierVolume::StaticClass() {
    static auto res = find_uobject(2853986414580660893); // Class /Script/NavigationSystem.NavModifierVolume
    return (ANavModifierVolume*)res;
}
void ANavModifierVolume::SetAreaClass(UClass* NewAreaClass) {
    static auto func = (UFunction*)(find_uobject(11262779611841127388)); // Function /Script/NavigationSystem.NavModifierVolume.SetAreaClass
    struct Params_SetAreaClass {
        UClass* NewAreaClass; // 0x0
    }; // Size: 0x8
    Params_SetAreaClass params{};
    params.NewAreaClass = (UClass*)NewAreaClass;
    ProcessEvent(func, &params);
}
