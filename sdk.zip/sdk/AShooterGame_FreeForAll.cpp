#include "AShooterGameMode.hpp"
#include "AShooterGame_FreeForAll.hpp"
#include "AShooterPlayerState.hpp"
AShooterGame_FreeForAll* AShooterGame_FreeForAll::StaticClass() {
    static auto res = find_uobject(17637668242535803521); // Class /Script/ShooterGame.ShooterGame_FreeForAll
    return (AShooterGame_FreeForAll*)res;
}
