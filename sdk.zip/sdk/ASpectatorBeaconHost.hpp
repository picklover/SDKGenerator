#pragma once
#include <cstdint>
#include "AOnlineBeaconHostObject.hpp"
class USpectatorBeaconState;
#pragma pack(push, 1)
class ASpectatorBeaconHost : public AOnlineBeaconHostObject {
public:
    USpectatorBeaconState* State; // 0x248
    char pad_250[0x60];
    bool bLogoutOnSessionTimeout; // 0x2b0
    char pad_2b1[0x3];
    float SessionTimeoutSecs; // 0x2b4
    float TravelSessionTimeoutSecs; // 0x2b8
    char pad_2bc[0x4];
    static ASpectatorBeaconHost* StaticClass();
}; // Size: 0x2c0
#pragma pack(pop)
