#include "AActor.hpp"
#include "ANote.hpp"
ANote* ANote::StaticClass() {
    static auto res = find_uobject(11320726539041052498); // Class /Script/Engine.Note
    return (ANote*)res;
}
