#pragma once
#include <cstdint>
#include "AInfo.hpp"
class USkyLightComponent;
#pragma pack(push, 1)
class ASkyLight : public AInfo {
public:
    USkyLightComponent* LightComponent; // 0x220
    uint8_t bEnabled : 1; // 0x228
    uint8_t pad_bitfield_228_1 : 7;
    char pad_229[0x7];
    static ASkyLight* StaticClass();
    void OnRep_bEnabled();
}; // Size: 0x230
#pragma pack(pop)
