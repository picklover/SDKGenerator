#pragma once
#include <cstdint>
#include "AVolume.hpp"
#include "EStreamingVolumeUsage.hpp"
#pragma pack(push, 1)
class ALevelStreamingVolume : public AVolume {
public:
    TArray<FName> StreamingLevelNames; // 0x258
    uint8_t bEditorPreVisOnly : 1; // 0x268
    uint8_t bDisabled : 1; // 0x268
    uint8_t pad_bitfield_268_2 : 6;
    char pad_269[0x3];
    EStreamingVolumeUsage StreamingUsage; // 0x26c
    char pad_26d[0x3];
    static ALevelStreamingVolume* StaticClass();
}; // Size: 0x270
#pragma pack(pop)
