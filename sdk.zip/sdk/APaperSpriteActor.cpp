#include "AActor.hpp"
#include "APaperSpriteActor.hpp"
#include "UPaperSpriteComponent.hpp"
APaperSpriteActor* APaperSpriteActor::StaticClass() {
    static auto res = find_uobject(15966390132213956768); // Class /Script/Paper2D.PaperSpriteActor
    return (APaperSpriteActor*)res;
}
