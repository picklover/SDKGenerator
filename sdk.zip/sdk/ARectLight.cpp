#include "ALight.hpp"
#include "ARectLight.hpp"
#include "URectLightComponent.hpp"
ARectLight* ARectLight::StaticClass() {
    static auto res = find_uobject(12904054027283383144); // Class /Script/Engine.RectLight
    return (ARectLight*)res;
}
