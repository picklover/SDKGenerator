#include "AActor.hpp"
#include "APaperTerrainActor.hpp"
#include "UPaperTerrainComponent.hpp"
#include "UPaperTerrainSplineComponent.hpp"
#include "USceneComponent.hpp"
APaperTerrainActor* APaperTerrainActor::StaticClass() {
    static auto res = find_uobject(370397509944110288); // Class /Script/Paper2D.PaperTerrainActor
    return (APaperTerrainActor*)res;
}
