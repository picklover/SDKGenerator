#pragma once
#include <cstdint>
#include "AAROriginActor.hpp"
class UMRMeshComponent;
class UMaterialInterface;
#pragma pack(push, 1)
class ALuminAROrigin : public AAROriginActor {
public:
    UMRMeshComponent* MRMeshComponent; // 0x220
    UMaterialInterface* PlaneSurfaceMaterial; // 0x228
    UMaterialInterface* WireframeMaterial; // 0x230
    char pad_238[0xa8];
    static ALuminAROrigin* StaticClass();
}; // Size: 0x2e0
#pragma pack(pop)
