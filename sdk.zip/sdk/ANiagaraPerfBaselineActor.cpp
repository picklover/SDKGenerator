#include "AActor.hpp"
#include "ANiagaraPerfBaselineActor.hpp"
#include "UNiagaraBaselineController.hpp"
#include "UTextRenderComponent.hpp"
ANiagaraPerfBaselineActor* ANiagaraPerfBaselineActor::StaticClass() {
    static auto res = find_uobject(9372860676427569325); // Class /Script/Niagara.NiagaraPerfBaselineActor
    return (ANiagaraPerfBaselineActor*)res;
}
