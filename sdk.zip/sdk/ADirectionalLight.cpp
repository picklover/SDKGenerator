#include "ADirectionalLight.hpp"
#include "ALight.hpp"
ADirectionalLight* ADirectionalLight::StaticClass() {
    static auto res = find_uobject(1135145415643592986); // Class /Script/Engine.DirectionalLight
    return (ADirectionalLight*)res;
}
