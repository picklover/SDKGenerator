#include "AActor.hpp"
#include "ALandscapeGizmoActor.hpp"
ALandscapeGizmoActor* ALandscapeGizmoActor::StaticClass() {
    static auto res = find_uobject(17935669798550542747); // Class /Script/Landscape.LandscapeGizmoActor
    return (ALandscapeGizmoActor*)res;
}
