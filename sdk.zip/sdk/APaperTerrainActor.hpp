#pragma once
#include <cstdint>
#include "AActor.hpp"
class USceneComponent;
class UPaperTerrainSplineComponent;
class UPaperTerrainComponent;
#pragma pack(push, 1)
class APaperTerrainActor : public AActor {
public:
    USceneComponent* DummyRoot; // 0x220
    UPaperTerrainSplineComponent* SplineComponent; // 0x228
    UPaperTerrainComponent* RenderComponent; // 0x230
    static APaperTerrainActor* StaticClass();
}; // Size: 0x238
#pragma pack(pop)
