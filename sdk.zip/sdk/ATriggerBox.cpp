#include "ATriggerBase.hpp"
#include "ATriggerBox.hpp"
ATriggerBox* ATriggerBox::StaticClass() {
    static auto res = find_uobject(7654159436167538299); // Class /Script/Engine.TriggerBox
    return (ATriggerBox*)res;
}
