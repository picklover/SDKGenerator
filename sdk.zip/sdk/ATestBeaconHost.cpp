#include "AOnlineBeaconHostObject.hpp"
#include "ATestBeaconHost.hpp"
ATestBeaconHost* ATestBeaconHost::StaticClass() {
    static auto res = find_uobject(16008684723514803715); // Class /Script/OnlineSubsystemUtils.TestBeaconHost
    return (ATestBeaconHost*)res;
}
