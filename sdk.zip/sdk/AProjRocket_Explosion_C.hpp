#pragma once
#include <cstdint>
#include "AShooterExplosionEffect.hpp"
#pragma pack(push, 1)
class AProjRocket_Explosion_C : public AShooterExplosionEffect {
public:
    static AProjRocket_Explosion_C* StaticClass();
}; // Size: 0x2e0
#pragma pack(pop)
