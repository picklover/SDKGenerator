#pragma once
#include <cstdint>
#include "APlayerController.hpp"
#include "FHitResult.hpp"
class UDrawFrustumComponent;
class AActor;
class UPrimitiveComponent;
class UPlayer;
struct FVector;
#pragma pack(push, 1)
class ADebugCameraController : public APlayerController {
public:
    uint8_t bShowSelectedInfo : 1; // 0x570
    uint8_t bIsFrozenRendering : 1; // 0x570
    uint8_t bIsOrbitingSelectedActor : 1; // 0x570
    uint8_t bOrbitPivotUseCenter : 1; // 0x570
    uint8_t bEnableBufferVisualization : 1; // 0x570
    uint8_t bEnableBufferVisualizationFullMode : 1; // 0x570
    uint8_t bIsBufferVisualizationInputSetup : 1; // 0x570
    uint8_t bLastDisplayEnabled : 1; // 0x570
    char pad_571[0x7];
    UDrawFrustumComponent* DrawFrustum; // 0x578
    AActor* SelectedActor; // 0x580
    UPrimitiveComponent* SelectedComponent; // 0x588
    FHitResult SelectedHitPoint; // 0x590
    APlayerController* OriginalControllerRef; // 0x618
    UPlayer* OriginalPlayer; // 0x620
    float SpeedScale; // 0x628
    float InitialMaxSpeed; // 0x62c
    float InitialAccel; // 0x630
    float InitialDecel; // 0x634
    char pad_638[0x38];
    static ADebugCameraController* StaticClass();
    void ToggleDisplay();
    void ShowDebugSelectedInfo();
    void SetPawnMovementSpeedScale(float NewSpeedScale);
    void ReceiveOnDeactivate(APlayerController* RestoredPC);
    void ReceiveOnActorSelected(AActor* NewSelectedActor, FVector& SelectHitLocation, FVector& SelectHitNormal, FHitResult& Hit);
    void ReceiveOnActivate(APlayerController* OriginalPC);
    AActor* GetSelectedActor();
}; // Size: 0x670
#pragma pack(pop)
