#pragma once
#include <cstdint>
#include "AActor.hpp"
class ALevelSequenceActor;
class UMediaComponent;
#pragma pack(push, 1)
class ALevelSequenceMediaController : public AActor {
public:
    char pad_220[0x8];
    ALevelSequenceActor* Sequence; // 0x228
    UMediaComponent* MediaComponent; // 0x230
    float ServerStartTimeSeconds; // 0x238
    char pad_23c[0xc];
    static ALevelSequenceMediaController* StaticClass();
    void SynchronizeToServer(float DesyncThresholdSeconds);
    void Play();
    void OnRep_ServerStartTimeSeconds();
    ALevelSequenceActor* GetSequence();
    UMediaComponent* GetMediaComponent();
}; // Size: 0x248
#pragma pack(pop)
