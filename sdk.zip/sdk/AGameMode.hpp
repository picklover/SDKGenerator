#pragma once
#include <cstdint>
#include "AGameModeBase.hpp"
class UClass;
class APlayerState;
#pragma pack(push, 1)
class AGameMode : public AGameModeBase {
public:
    FName MatchState; // 0x2c0
    uint8_t bDelayedStart : 1; // 0x2c8
    uint8_t pad_bitfield_2c8_1 : 7;
    char pad_2c9[0x3];
    int32_t NumSpectators; // 0x2cc
    int32_t NumPlayers; // 0x2d0
    int32_t NumBots; // 0x2d4
    float MinRespawnDelay; // 0x2d8
    int32_t NumTravellingPlayers; // 0x2dc
    UClass* EngineMessageClass; // 0x2e0
    TArray<APlayerState*> InactivePlayerArray; // 0x2e8
    float InactivePlayerStateLifeSpan; // 0x2f8
    int32_t MaxInactivePlayers; // 0x2fc
    bool bHandleDedicatedServerReplays; // 0x300
    char pad_301[0x7];
    static AGameMode* StaticClass();
    void StartMatch();
    void SetBandwidthLimit(float AsyncIOBandwidthLimit);
    void Say(FString Msg);
    void RestartGame();
    bool ReadyToStartMatch();
    bool ReadyToEndMatch();
    void K2_OnSetMatchState(FName NewState);
    bool IsMatchInProgress();
    FName GetMatchState();
    void EndMatch();
    void AbortMatch();
}; // Size: 0x308
#pragma pack(pop)
