#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FDecalData.hpp"
#include "FHitResult.hpp"
class UParticleSystem;
class UPointLightComponent;
class USoundCue;
#pragma pack(push, 1)
class AShooterExplosionEffect : public AActor {
public:
    UParticleSystem* ExplosionFX; // 0x220
    UPointLightComponent* ExplosionLight; // 0x228
    float ExplosionLightFadeOut; // 0x230
    char pad_234[0x4];
    USoundCue* ExplosionSound; // 0x238
    FDecalData Decal; // 0x240
    FHitResult SurfaceHit; // 0x250
    char pad_2d8[0x8];
    static AShooterExplosionEffect* StaticClass();
}; // Size: 0x2e0
#pragma pack(pop)
