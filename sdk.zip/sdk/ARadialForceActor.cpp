#include "ARadialForceActor.hpp"
#include "ARigidBodyBase.hpp"
#include "UFunction.hpp"
#include "URadialForceComponent.hpp"
void ARadialForceActor::EnableForce() {
    static auto func = (UFunction*)(find_uobject(14184334845527776539)); // Function /Script/Engine.RadialForceActor.EnableForce
    struct Params_EnableForce {
    }; // Size: 0x0
    Params_EnableForce params{};
    ProcessEvent(func, &params);
}
ARadialForceActor* ARadialForceActor::StaticClass() {
    static auto res = find_uobject(7183528116607620549); // Class /Script/Engine.RadialForceActor
    return (ARadialForceActor*)res;
}
void ARadialForceActor::ToggleForce() {
    static auto func = (UFunction*)(find_uobject(9406485554258093406)); // Function /Script/Engine.RadialForceActor.ToggleForce
    struct Params_ToggleForce {
    }; // Size: 0x0
    Params_ToggleForce params{};
    ProcessEvent(func, &params);
}
void ARadialForceActor::DisableForce() {
    static auto func = (UFunction*)(find_uobject(4979009364053428400)); // Function /Script/Engine.RadialForceActor.DisableForce
    struct Params_DisableForce {
    }; // Size: 0x0
    Params_DisableForce params{};
    ProcessEvent(func, &params);
}
void ARadialForceActor::FireImpulse() {
    static auto func = (UFunction*)(find_uobject(16753325394652393002)); // Function /Script/Engine.RadialForceActor.FireImpulse
    struct Params_FireImpulse {
    }; // Size: 0x0
    Params_FireImpulse params{};
    ProcessEvent(func, &params);
}
