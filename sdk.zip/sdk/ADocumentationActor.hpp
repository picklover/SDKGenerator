#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class ADocumentationActor : public AActor {
public:
    char pad_220[0x8];
    static ADocumentationActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
