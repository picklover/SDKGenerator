#include "AARSharedWorldGameState.hpp"
#include "AGameState.hpp"
#include "UFunction.hpp"
AARSharedWorldGameState* AARSharedWorldGameState::StaticClass() {
    static auto res = find_uobject(4575697769126428607); // Class /Script/AugmentedReality.ARSharedWorldGameState
    return (AARSharedWorldGameState*)res;
}
void AARSharedWorldGameState::K2_OnARWorldMapIsReady() {
    static auto func = (UFunction*)(find_uobject(6462303145409586888)); // Function /Script/AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady
    struct Params_K2_OnARWorldMapIsReady {
    }; // Size: 0x0
    Params_K2_OnARWorldMapIsReady params{};
    ProcessEvent(func, &params);
}
