#include "AGizmoActor.hpp"
#include "ATransformGizmoActor.hpp"
#include "UPrimitiveComponent.hpp"
ATransformGizmoActor* ATransformGizmoActor::StaticClass() {
    static auto res = find_uobject(12401034113119196842); // Class /Script/InteractiveToolsFramework.TransformGizmoActor
    return (ATransformGizmoActor*)res;
}
