#include "AActor.hpp"
#include "APaperFlipbookActor.hpp"
#include "UPaperFlipbookComponent.hpp"
APaperFlipbookActor* APaperFlipbookActor::StaticClass() {
    static auto res = find_uobject(13475191051012545125); // Class /Script/Paper2D.PaperFlipbookActor
    return (APaperFlipbookActor*)res;
}
