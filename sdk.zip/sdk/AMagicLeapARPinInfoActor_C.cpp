#include "AMagicLeapARPinInfoActorBase.hpp"
#include "AMagicLeapARPinInfoActor_C.hpp"
#include "APlayerCameraManager.hpp"
#include "FHitResult.hpp"
#include "FPointerToUberGraphFrame.hpp"
#include "FRotator.hpp"
#include "FVector.hpp"
#include "UFunction.hpp"
#include "UMaterialInstanceDynamic.hpp"
#include "USceneComponent.hpp"
#include "USphereComponent.hpp"
#include "UStaticMeshComponent.hpp"
#include "UTextRenderComponent.hpp"
AMagicLeapARPinInfoActor_C* AMagicLeapARPinInfoActor_C::StaticClass() {
    static auto res = find_uobject(17638668400015627693); // BlueprintGeneratedClass /MagicLeapPassableWorld/MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C
    return (AMagicLeapARPinInfoActor_C*)res;
}
void AMagicLeapARPinInfoActor_C::UserConstructionScript(UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue, UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_1, UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2) {
    static auto func = (UFunction*)(find_uobject(7814402327022466954)); // Function /MagicLeapPassableWorld/MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C.UserConstructionScript
    struct Params_UserConstructionScript {
        UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue; // 0x0
        UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_1; // 0x8
        UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2; // 0x10
    }; // Size: 0x18
    Params_UserConstructionScript params{};
    params.CallFunc_CreateDynamicMaterialInstance_ReturnValue = (UMaterialInstanceDynamic*)CallFunc_CreateDynamicMaterialInstance_ReturnValue;
    params.CallFunc_CreateDynamicMaterialInstance_ReturnValue_1 = (UMaterialInstanceDynamic*)CallFunc_CreateDynamicMaterialInstance_ReturnValue_1;
    params.CallFunc_CreateDynamicMaterialInstance_ReturnValue_2 = (UMaterialInstanceDynamic*)CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;
    ProcessEvent(func, &params);
}
void AMagicLeapARPinInfoActor_C::UpdatePinState() {
    static auto func = (UFunction*)(find_uobject(11180059348235066194)); // Function /MagicLeapPassableWorld/MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C.UpdatePinState
    struct Params_UpdatePinState {
    }; // Size: 0x0
    Params_UpdatePinState params{};
    ProcessEvent(func, &params);
}
void AMagicLeapARPinInfoActor_C::OnUpdateARPinState0() {
    static auto func = (UFunction*)(find_uobject(14214275161913430680)); // Function /MagicLeapPassableWorld/MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C.OnUpdateARPinState
    struct Params_OnUpdateARPinState {
    }; // Size: 0x0
    Params_OnUpdateARPinState params{};
    ProcessEvent(func, &params);
}
void AMagicLeapARPinInfoActor_C::ReceiveTick(float DeltaSeconds) {
    static auto func = (UFunction*)(find_uobject(8198775386065775461)); // Function /MagicLeapPassableWorld/MagicLeapARPinInfoActor.MagicLeapARPinInfoActor_C.ReceiveTick
    struct Params_ReceiveTick {
        float DeltaSeconds; // 0x0
    }; // Size: 0x4
    Params_ReceiveTick params{};
    params.DeltaSeconds = (float)DeltaSeconds;
    ProcessEvent(func, &params);
}
void AMagicLeapARPinInfoActor_C::ExecuteUbergraph_MagicLeapARPinInfoActor(int32_t EntryPoint, APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue, FVector CallFunc_GetCameraLocation_ReturnValue, FRotator CallFunc_K2_GetComponentRotation_ReturnValue, FVector CallFunc_K2_GetComponentLocation_ReturnValue, FRotator CallFunc_FindLookAtRotation_ReturnValue, FVector CallFunc_GetARPinPositionAndOrientation_Position, FRotator CallFunc_GetARPinPositionAndOrientation_Orientation, bool CallFunc_GetARPinPositionAndOrientation_PinFoundInEnvironment, bool CallFunc_GetARPinPositionAndOrientation_ReturnValue, FHitResult CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult, FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult, float K2Node_Event_DeltaSeconds, FRotator CallFunc_RInterpTo_ReturnValue, FString CallFunc_ARPinIdToString_ReturnValue, float CallFunc_BreakRotator_Roll, float CallFunc_BreakRotator_Pitch, float CallFunc_BreakRotator_Yaw) {}
