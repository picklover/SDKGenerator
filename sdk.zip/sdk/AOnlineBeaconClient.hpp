#pragma once
#include <cstdint>
#include "AOnlineBeacon.hpp"
#include "EBeaconConnectionState.hpp"
class AOnlineBeaconHostObject;
class UNetConnection;
#pragma pack(push, 1)
class AOnlineBeaconClient : public AOnlineBeacon {
public:
    AOnlineBeaconHostObject* BeaconOwner; // 0x250
    UNetConnection* BeaconConnection; // 0x258
    EBeaconConnectionState ConnectionState; // 0x260
    char pad_261[0x4f];
    static AOnlineBeaconClient* StaticClass();
    void ClientOnConnected();
}; // Size: 0x2b0
#pragma pack(pop)
