#include "AActor.hpp"
#include "APaperTileMapActor.hpp"
#include "UPaperTileMapComponent.hpp"
APaperTileMapActor* APaperTileMapActor::StaticClass() {
    static auto res = find_uobject(6146167581757532793); // Class /Script/Paper2D.PaperTileMapActor
    return (APaperTileMapActor*)res;
}
