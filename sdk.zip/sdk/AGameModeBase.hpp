#pragma once
#include <cstdint>
#include "AInfo.hpp"
class UClass;
struct FTransform;
class APlayerController;
class APawn;
class AGameSession;
class AGameStateBase;
class AServerStatReplicator;
class AController;
class AActor;
class APlayerState;
#pragma pack(push, 1)
class AGameModeBase : public AInfo {
public:
    FString OptionsString; // 0x220
    UClass* GameSessionClass; // 0x230
    UClass* GameStateClass; // 0x238
    UClass* PlayerControllerClass; // 0x240
    UClass* PlayerStateClass; // 0x248
    UClass* HUDClass; // 0x250
    UClass* DefaultPawnClass; // 0x258
    UClass* SpectatorClass; // 0x260
    UClass* ReplaySpectatorPlayerControllerClass; // 0x268
    UClass* ServerStatReplicatorClass; // 0x270
    AGameSession* GameSession; // 0x278
    AGameStateBase* GameState; // 0x280
    AServerStatReplicator* ServerStatReplicator; // 0x288
    char pad_290[0x18];
    uint8_t bUseSeamlessTravel : 1; // 0x2a8
    uint8_t bStartPlayersAsSpectators : 1; // 0x2a8
    uint8_t bPauseable : 1; // 0x2a8
    uint8_t pad_bitfield_2a8_3 : 5;
    char pad_2a9[0x17];
    static AGameModeBase* StaticClass();
    void StartPlay();
    APawn* SpawnDefaultPawnFor(AController* NewPlayer, AActor* StartSpot);
    APawn* SpawnDefaultPawnAtTransform(AController* NewPlayer, FTransform& SpawnTransform);
    bool ShouldReset(AActor* ActorToReset);
    void ReturnToMainMenuHost();
    void RestartPlayerAtTransform(AController* NewPlayer, FTransform& SpawnTransform);
    void RestartPlayerAtPlayerStart(AController* NewPlayer, AActor* StartSpot);
    void RestartPlayer(AController* NewPlayer);
    void ResetLevel();
    bool PlayerCanRestart(APlayerController* Player);
    bool MustSpectate(APlayerController* NewPlayerController);
    void K2_PostLogin(APlayerController* NewPlayer);
    void K2_OnSwapPlayerControllers(APlayerController* OldPC, APlayerController* NewPC);
    void K2_OnRestartPlayer(AController* NewPlayer);
    void K2_OnLogout(AController* ExitingController);
    void K2_OnChangeName(AController* Other, FString NewName, bool bNameChange);
    AActor* K2_FindPlayerStart(AController* Player, FString IncomingName);
    void InitStartSpot(AActor* StartSpot, AController* NewPlayer);
    void InitializeHUDForPlayer(APlayerController* NewPlayer);
    bool HasMatchStarted();
    bool HasMatchEnded();
    void HandleStartingNewPlayer(APlayerController* NewPlayer);
    int32_t GetNumSpectators();
    int32_t GetNumPlayers();
    UClass* GetDefaultPawnClassForController(AController* InController);
    AActor* FindPlayerStart(AController* Player, FString IncomingName);
    AActor* ChoosePlayerStart(AController* Player);
    void ChangeName(AController* Controller, FString NewName, bool bNameChange);
    bool CanSpectate(APlayerController* Viewer, APlayerState* ViewTarget);
}; // Size: 0x2c0
#pragma pack(pop)
