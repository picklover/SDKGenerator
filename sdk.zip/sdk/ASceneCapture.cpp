#include "AActor.hpp"
#include "ASceneCapture.hpp"
#include "USceneComponent.hpp"
#include "UStaticMeshComponent.hpp"
ASceneCapture* ASceneCapture::StaticClass() {
    static auto res = find_uobject(5771826274595789988); // Class /Script/Engine.SceneCapture
    return (ASceneCapture*)res;
}
