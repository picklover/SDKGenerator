#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class ALandscapeGizmoActor : public AActor {
public:
    static ALandscapeGizmoActor* StaticClass();
}; // Size: 0x220
#pragma pack(pop)
