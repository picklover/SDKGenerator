#pragma once
#include <cstdint>
#include "AInfo.hpp"
#include "FUniqueNetIdRepl.hpp"
class UClass;
class APawn;
#pragma pack(push, 1)
class APlayerState : public AInfo {
public:
    float Score; // 0x220
    int32_t PlayerId; // 0x224
    uint8_t Ping; // 0x228
    char pad_229[0x1];
    uint8_t bShouldUpdateReplicatedPing : 1; // 0x22a
    uint8_t bIsSpectator : 1; // 0x22a
    uint8_t bOnlySpectator : 1; // 0x22a
    uint8_t bIsABot : 1; // 0x22a
    uint8_t pad_bitfield_22a_4 : 1;
    uint8_t bIsInactive : 1; // 0x22a
    uint8_t bFromPreviousLevel : 1; // 0x22a
    uint8_t pad_bitfield_22a_7 : 1;
    char pad_22b[0x1];
    int32_t StartTime; // 0x22c
    UClass* EngineMessageClass; // 0x230
    char pad_238[0x8];
    FString SavedNetworkAddress; // 0x240
    FUniqueNetIdRepl UniqueId; // 0x250
    char pad_278[0x8];
    APawn* PawnPrivate; // 0x280
    char pad_288[0x78];
    FString PlayerNamePrivate; // 0x300
    char pad_310[0x10];
    static APlayerState* StaticClass();
    void ReceiveOverrideWith(APlayerState* OldPlayerState);
    void ReceiveCopyProperties(APlayerState* NewPlayerState);
    void OnRep_UniqueId();
    void OnRep_Score();
    void OnRep_PlayerName();
    void OnRep_PlayerId();
    void OnRep_bIsInactive();
    bool IsOnlyASpectator();
    FString GetPlayerName();
}; // Size: 0x320
#pragma pack(pop)
