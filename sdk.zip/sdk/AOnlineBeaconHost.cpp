#include "AOnlineBeacon.hpp"
#include "AOnlineBeaconClient.hpp"
#include "AOnlineBeaconHost.hpp"
AOnlineBeaconHost* AOnlineBeaconHost::StaticClass() {
    static auto res = find_uobject(13018005825302359768); // Class /Script/OnlineSubsystemUtils.OnlineBeaconHost
    return (AOnlineBeaconHost*)res;
}
