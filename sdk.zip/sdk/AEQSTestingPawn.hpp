#pragma once
#include <cstdint>
#include "ACharacter.hpp"
#include "EEnvQueryHightlightMode.hpp"
#include "EEnvQueryRunMode\Type.hpp"
#include "FAIDynamicParam.hpp"
#include "FEnvNamedValue.hpp"
#include "FNavAgentProperties.hpp"
class UEnvQuery;
#pragma pack(push, 1)
class AEQSTestingPawn : public ACharacter {
public:
    UEnvQuery* QueryTemplate; // 0x4c0
    TArray<FEnvNamedValue> QueryParams; // 0x4c8
    TArray<FAIDynamicParam> QueryConfig; // 0x4d8
    float TimeLimitPerStep; // 0x4e8
    int32_t StepToDebugDraw; // 0x4ec
    EEnvQueryHightlightMode HighlightMode; // 0x4f0
    char pad_4f1[0x3];
    uint8_t bDrawLabels : 1; // 0x4f4
    uint8_t bDrawFailedItems : 1; // 0x4f4
    uint8_t bReRunQueryOnlyOnFinishedMove : 1; // 0x4f4
    uint8_t bShouldBeVisibleInGame : 1; // 0x4f4
    uint8_t bTickDuringGame : 1; // 0x4f4
    uint8_t pad_bitfield_4f4_5 : 3;
    char pad_4f5[0x3];
    EEnvQueryRunMode::Type QueryingMode; // 0x4f8
    char pad_4f9[0x7];
    FNavAgentProperties NavAgentProperties; // 0x500
    char pad_530[0x20];
    static AEQSTestingPawn* StaticClass();
}; // Size: 0x550
#pragma pack(pop)
