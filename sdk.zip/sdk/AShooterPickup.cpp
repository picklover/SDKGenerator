#include "AActor.hpp"
#include "AShooterCharacter.hpp"
#include "AShooterPickup.hpp"
#include "UFunction.hpp"
#include "UParticleSystem.hpp"
#include "UParticleSystemComponent.hpp"
#include "USoundCue.hpp"
AShooterPickup* AShooterPickup::StaticClass() {
    static auto res = find_uobject(11386093662067351098); // Class /Script/ShooterGame.ShooterPickup
    return (AShooterPickup*)res;
}
void AShooterPickup::OnRespawnEvent() {
    static auto func = (UFunction*)(find_uobject(2705956044629162819)); // Function /Script/ShooterGame.ShooterPickup.OnRespawnEvent
    struct Params_OnRespawnEvent {
    }; // Size: 0x0
    Params_OnRespawnEvent params{};
    ProcessEvent(func, &params);
}
void AShooterPickup::OnRep_IsActive() {
    static auto func = (UFunction*)(find_uobject(12163977944680914065)); // Function /Script/ShooterGame.ShooterPickup.OnRep_IsActive
    struct Params_OnRep_IsActive {
    }; // Size: 0x0
    Params_OnRep_IsActive params{};
    ProcessEvent(func, &params);
}
void AShooterPickup::OnPickedUpEvent() {
    static auto func = (UFunction*)(find_uobject(12097708574870539278)); // Function /Script/ShooterGame.ShooterPickup.OnPickedUpEvent
    struct Params_OnPickedUpEvent {
    }; // Size: 0x0
    Params_OnPickedUpEvent params{};
    ProcessEvent(func, &params);
}
