#include "ALandscape.hpp"
#include "ALandscapeProxy.hpp"
ALandscape* ALandscape::StaticClass() {
    static auto res = find_uobject(2838929753749514348); // Class /Script/Landscape.Landscape
    return (ALandscape*)res;
}
