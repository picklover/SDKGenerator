#pragma once
#include <cstdint>
#include "AController.hpp"
#include "EPathFollowingRequestResult\Type.hpp"
#include "EPathFollowingStatus\Type.hpp"
#include "FGameplayResourceSet.hpp"
#include "FVector.hpp"
class UBlackboardData;
class UBrainComponent;
class UPathFollowingComponent;
class UBlackboardComponent;
class UPawnActionsComponent;
class UAIPerceptionComponent;
class UGameplayTasksComponent;
class AActor;
class UClass;
class UBehaviorTree;
#pragma pack(push, 1)
class AAIController : public AController {
public:
    char pad_298[0x38];
    uint8_t bStartAILogicOnPossess : 1; // 0x2d0
    uint8_t bStopAILogicOnUnposses : 1; // 0x2d0
    uint8_t bLOSflag : 1; // 0x2d0
    uint8_t bSkipExtraLOSChecks : 1; // 0x2d0
    uint8_t bAllowStrafe : 1; // 0x2d0
    uint8_t bWantsPlayerState : 1; // 0x2d0
    uint8_t bSetControlRotationFromPawnOrientation : 1; // 0x2d0
    uint8_t pad_bitfield_2d0_7 : 1;
    char pad_2d1[0x7];
    UPathFollowingComponent* PathFollowingComponent; // 0x2d8
    UBrainComponent* BrainComponent; // 0x2e0
    UAIPerceptionComponent* PerceptionComponent; // 0x2e8
    UPawnActionsComponent* ActionsComp; // 0x2f0
    UBlackboardComponent* Blackboard; // 0x2f8
    UGameplayTasksComponent* CachedGameplayTasksComponent; // 0x300
    UClass* DefaultNavigationFilterClass; // 0x308
    char pad_310[0x18];
    static AAIController* StaticClass();
    bool UseBlackboard(UBlackboardData* BlackboardAsset, UBlackboardComponent*& BlackboardComponent);
    void UnclaimTaskResource(UClass* ResourceClass);
    void SetPathFollowingComponent(UPathFollowingComponent* NewPFComponent);
    void SetMoveBlockDetection(bool bEnable);
    bool RunBehaviorTree(UBehaviorTree* BTAsset);
    void OnUsingBlackBoard(UBlackboardComponent* BlackboardComp, UBlackboardData* BlackboardAsset);
    void OnGameplayTaskResourcesClaimed(FGameplayResourceSet NewlyClaimed, FGameplayResourceSet FreshlyReleased);
    EPathFollowingRequestResult::Type MoveToLocation(FVector& Dest, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bProjectDestinationToNavigation, bool bCanStrafe, UClass* FilterClass, bool bAllowPartialPath);
    EPathFollowingRequestResult::Type MoveToActor(AActor* Goal, float AcceptanceRadius, bool bStopOnOverlap, bool bUsePathfinding, bool bCanStrafe, UClass* FilterClass, bool bAllowPartialPath);
    void K2_SetFocus(AActor* NewFocus);
    void K2_SetFocalPoint(FVector FP);
    void K2_ClearFocus();
    bool HasPartialPath();
    UPathFollowingComponent* GetPathFollowingComponent();
    EPathFollowingStatus::Type GetMoveStatus();
    FVector GetImmediateMoveDestination();
    AActor* GetFocusActor();
    FVector GetFocalPointOnActor(AActor* Actor);
    FVector GetFocalPoint();
    UAIPerceptionComponent* GetAIPerceptionComponent();
    void ClaimTaskResource(UClass* ResourceClass);
}; // Size: 0x328
#pragma pack(pop)
