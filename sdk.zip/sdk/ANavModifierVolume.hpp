#pragma once
#include <cstdint>
#include "AVolume.hpp"
class UClass;
#pragma pack(push, 1)
class ANavModifierVolume : public AVolume {
public:
    char pad_258[0x8];
    UClass* AreaClass; // 0x260
    bool bMaskFillCollisionUnderneathForNavmesh; // 0x268
    char pad_269[0x7];
    static ANavModifierVolume* StaticClass();
    void SetAreaClass(UClass* NewAreaClass);
}; // Size: 0x270
#pragma pack(pop)
