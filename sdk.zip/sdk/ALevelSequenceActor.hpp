#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FLevelSequenceCameraSettings.hpp"
#include "FMovieSceneObjectBindingID.hpp"
#include "FMovieSceneSequencePlaybackSettings.hpp"
#include "FSoftObjectPath.hpp"
class ULevelSequencePlayer;
class UMovieSceneBindingOverrides;
class ULevelSequenceBurnInOptions;
class ULevelSequenceBurnIn;
class UObject;
class ULevelSequence;
#pragma pack(push, 1)
class ALevelSequenceActor : public AActor {
public:
    char pad_220[0x18];
    FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x238
    char pad_24c[0x4];
    ULevelSequencePlayer* SequencePlayer; // 0x250
    FSoftObjectPath LevelSequence; // 0x258
    FLevelSequenceCameraSettings CameraSettings; // 0x270
    char pad_272[0x6];
    ULevelSequenceBurnInOptions* BurnInOptions; // 0x278
    UMovieSceneBindingOverrides* BindingOverrides; // 0x280
    uint8_t bAutoPlay : 1; // 0x288
    uint8_t bOverrideInstanceData : 1; // 0x288
    uint8_t bReplicatePlayback : 1; // 0x288
    uint8_t pad_bitfield_288_3 : 5;
    char pad_289[0x7];
    UObject* DefaultInstanceData; // 0x290
    ULevelSequenceBurnIn* BurnInInstance; // 0x298
    bool bShowBurnin; // 0x2a0
    char pad_2a1[0x7];
    static ALevelSequenceActor* StaticClass();
    void ShowBurnin();
    void SetSequence(ULevelSequence* InSequence);
    void SetReplicatePlayback(bool ReplicatePlayback);
    void SetBindingByTag(FName BindingTag, TArray<AActor*>& Actors, bool bAllowBindingsFromAsset);
    void SetBinding(FMovieSceneObjectBindingID Binding, TArray<AActor*>& Actors, bool bAllowBindingsFromAsset);
    void ResetBindings();
    void ResetBinding(FMovieSceneObjectBindingID Binding);
    void RemoveBindingByTag(FName Tag, AActor* Actor);
    void RemoveBinding(FMovieSceneObjectBindingID Binding, AActor* Actor);
    void OnLevelSequenceLoaded__DelegateSignature();
    ULevelSequence* LoadSequence();
    void HideBurnin();
    ULevelSequencePlayer* GetSequencePlayer();
    ULevelSequence* GetSequence();
    TArray<FMovieSceneObjectBindingID> FindNamedBindings(FName Tag);
    FMovieSceneObjectBindingID FindNamedBinding(FName Tag);
    void AddBindingByTag(FName BindingTag, AActor* Actor, bool bAllowBindingsFromAsset);
    void AddBinding(FMovieSceneObjectBindingID Binding, AActor* Actor, bool bAllowBindingsFromAsset);
}; // Size: 0x2a8
#pragma pack(pop)
