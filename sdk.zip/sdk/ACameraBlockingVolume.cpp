#include "ACameraBlockingVolume.hpp"
#include "AVolume.hpp"
ACameraBlockingVolume* ACameraBlockingVolume::StaticClass() {
    static auto res = find_uobject(14772776165715755376); // Class /Script/Engine.CameraBlockingVolume
    return (ACameraBlockingVolume*)res;
}
