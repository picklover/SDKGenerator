#pragma once
#include <cstdint>
#include "AInfo.hpp"
class UVolumetricCloudComponent;
#pragma pack(push, 1)
class AVolumetricCloud : public AInfo {
public:
    UVolumetricCloudComponent* VolumetricCloudComponent; // 0x220
    static AVolumetricCloud* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
