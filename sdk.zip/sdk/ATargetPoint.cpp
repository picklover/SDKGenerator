#include "AActor.hpp"
#include "ATargetPoint.hpp"
ATargetPoint* ATargetPoint::StaticClass() {
    static auto res = find_uobject(18207595291280549951); // Class /Script/Engine.TargetPoint
    return (ATargetPoint*)res;
}
