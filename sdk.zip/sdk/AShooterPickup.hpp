#pragma once
#include <cstdint>
#include "AActor.hpp"
class UParticleSystemComponent;
class UParticleSystem;
class USoundCue;
class AShooterCharacter;
#pragma pack(push, 1)
class AShooterPickup : public AActor {
public:
    UParticleSystemComponent* PickupPSC; // 0x220
    UParticleSystem* ActiveFX; // 0x228
    UParticleSystem* RespawningFX; // 0x230
    USoundCue* PickupSound; // 0x238
    USoundCue* RespawnSound; // 0x240
    float RespawnTime; // 0x248
    uint8_t bIsActive : 1; // 0x24c
    uint8_t pad_bitfield_24c_1 : 7;
    char pad_24d[0x3];
    AShooterCharacter* PickedUpBy; // 0x250
    char pad_258[0x8];
    static AShooterPickup* StaticClass();
    void OnRespawnEvent();
    void OnRep_IsActive();
    void OnPickedUpEvent();
}; // Size: 0x260
#pragma pack(pop)
