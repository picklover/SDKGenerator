#pragma once
#include <cstdint>
#include "ATriggerBase.hpp"
#pragma pack(push, 1)
class ATriggerBox : public ATriggerBase {
public:
    static ATriggerBox* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
