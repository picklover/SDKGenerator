#include "AActor.hpp"
#include "ANiagaraActor.hpp"
#include "UFunction.hpp"
#include "UNiagaraComponent.hpp"
void ANiagaraActor::SetDestroyOnSystemFinish(bool bShouldDestroyOnSystemFinish) {
    static auto func = (UFunction*)(find_uobject(17674328493461413486)); // Function /Script/Niagara.NiagaraActor.SetDestroyOnSystemFinish
    struct Params_SetDestroyOnSystemFinish {
        bool bShouldDestroyOnSystemFinish; // 0x0
    }; // Size: 0x1
    Params_SetDestroyOnSystemFinish params{};
    params.bShouldDestroyOnSystemFinish = (bool)bShouldDestroyOnSystemFinish;
    ProcessEvent(func, &params);
}
ANiagaraActor* ANiagaraActor::StaticClass() {
    static auto res = find_uobject(12302210876856599217); // Class /Script/Niagara.NiagaraActor
    return (ANiagaraActor*)res;
}
void ANiagaraActor::OnNiagaraSystemFinished(UNiagaraComponent* FinishedComponent) {
    static auto func = (UFunction*)(find_uobject(18421059008243130892)); // Function /Script/Niagara.NiagaraActor.OnNiagaraSystemFinished
    struct Params_OnNiagaraSystemFinished {
        UNiagaraComponent* FinishedComponent; // 0x0
    }; // Size: 0x8
    Params_OnNiagaraSystemFinished params{};
    params.FinishedComponent = (UNiagaraComponent*)FinishedComponent;
    ProcessEvent(func, &params);
}
