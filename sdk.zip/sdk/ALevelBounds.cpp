#include "AActor.hpp"
#include "ALevelBounds.hpp"
#include "UBoxComponent.hpp"
ALevelBounds* ALevelBounds::StaticClass() {
    static auto res = find_uobject(10923216728756896437); // Class /Script/Engine.LevelBounds
    return (ALevelBounds*)res;
}
