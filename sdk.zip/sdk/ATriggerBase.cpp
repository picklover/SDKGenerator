#include "AActor.hpp"
#include "ATriggerBase.hpp"
#include "UShapeComponent.hpp"
ATriggerBase* ATriggerBase::StaticClass() {
    static auto res = find_uobject(4964695625837297987); // Class /Script/Engine.TriggerBase
    return (ATriggerBase*)res;
}
