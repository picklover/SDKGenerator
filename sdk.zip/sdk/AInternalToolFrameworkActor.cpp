#include "AActor.hpp"
#include "AInternalToolFrameworkActor.hpp"
AInternalToolFrameworkActor* AInternalToolFrameworkActor::StaticClass() {
    static auto res = find_uobject(12080913708674552285); // Class /Script/InteractiveToolsFramework.InternalToolFrameworkActor
    return (AInternalToolFrameworkActor*)res;
}
