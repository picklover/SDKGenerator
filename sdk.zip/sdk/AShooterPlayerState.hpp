#pragma once
#include <cstdint>
#include "APlayerState.hpp"
class UDamageType;
#pragma pack(push, 1)
class AShooterPlayerState : public APlayerState {
public:
    int32_t TeamNumber; // 0x320
    int32_t NumKills; // 0x324
    int32_t NumDeaths; // 0x328
    int32_t NumBulletsFired; // 0x32c
    int32_t NumRocketsFired; // 0x330
    uint8_t bQuitter : 1; // 0x334
    uint8_t pad_bitfield_334_1 : 7;
    char pad_335[0x3];
    FString MatchID; // 0x338
    static AShooterPlayerState* StaticClass();
    void OnRep_TeamColor();
    void InformAboutKill(AShooterPlayerState* KillerPlayerState, UDamageType* KillerDamageType, AShooterPlayerState* KilledPlayerState);
    void BroadcastDeath(AShooterPlayerState* KillerPlayerState, UDamageType* KillerDamageType, AShooterPlayerState* KilledPlayerState);
}; // Size: 0x348
#pragma pack(pop)
