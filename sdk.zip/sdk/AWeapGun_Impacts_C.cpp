#include "AShooterImpactEffect.hpp"
#include "AWeapGun_Impacts_C.hpp"
#include "USceneComponent.hpp"
AWeapGun_Impacts_C* AWeapGun_Impacts_C::StaticClass() {
    static auto res = find_uobject(9483897179602850664); // BlueprintGeneratedClass /Game/Blueprints/Weapons/WeapGun_Impacts.WeapGun_Impacts_C
    return (AWeapGun_Impacts_C*)res;
}
