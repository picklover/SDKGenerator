#include "APlayerPawn_C.hpp"
#include "AShooterCharacter.hpp"
APlayerPawn_C* APlayerPawn_C::StaticClass() {
    static auto res = find_uobject(4627421181674356584); // BlueprintGeneratedClass /Game/Blueprints/Pawns/PlayerPawn.PlayerPawn_C
    return (APlayerPawn_C*)res;
}
