#include "ACharacter.hpp"
#include "APaperCharacter.hpp"
#include "UPaperFlipbookComponent.hpp"
APaperCharacter* APaperCharacter::StaticClass() {
    static auto res = find_uobject(16092632479622439901); // Class /Script/Paper2D.PaperCharacter
    return (APaperCharacter*)res;
}
