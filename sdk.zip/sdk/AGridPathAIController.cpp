#include "AAIController.hpp"
#include "AGridPathAIController.hpp"
AGridPathAIController* AGridPathAIController::StaticClass() {
    static auto res = find_uobject(13202935374758156939); // Class /Script/AIModule.GridPathAIController
    return (AGridPathAIController*)res;
}
