#include "AActor.hpp"
#include "ADatasmithImportedSequencesActor.hpp"
#include "UFunction.hpp"
#include "ULevelSequence.hpp"
void ADatasmithImportedSequencesActor::PlayLevelSequence(ULevelSequence* SequenceToPlay) {
    static auto func = (UFunction*)(find_uobject(17224808395289262449)); // Function /Script/DatasmithContent.DatasmithImportedSequencesActor.PlayLevelSequence
    struct Params_PlayLevelSequence {
        ULevelSequence* SequenceToPlay; // 0x0
    }; // Size: 0x8
    Params_PlayLevelSequence params{};
    params.SequenceToPlay = (ULevelSequence*)SequenceToPlay;
    ProcessEvent(func, &params);
}
ADatasmithImportedSequencesActor* ADatasmithImportedSequencesActor::StaticClass() {
    static auto res = find_uobject(5979932664147143624); // Class /Script/DatasmithContent.DatasmithImportedSequencesActor
    return (ADatasmithImportedSequencesActor*)res;
}
