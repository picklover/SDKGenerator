#include "AGameState.hpp"
#include "AMagicLeapSharedWorldGameState.hpp"
#include "FMagicLeapSharedWorldAlignmentTransforms.hpp"
#include "FMagicLeapSharedWorldSharedData.hpp"
#include "FTransform.hpp"
#include "UFunction.hpp"
void AMagicLeapSharedWorldGameState::MagicLeapSharedWorldEvent__DelegateSignature() {
    static auto func = (UFunction*)(find_uobject(2729846558479621371)); // DelegateFunction /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameState.MagicLeapSharedWorldEvent__DelegateSignature
    struct Params_MagicLeapSharedWorldEvent__DelegateSignature {
    }; // Size: 0x0
    Params_MagicLeapSharedWorldEvent__DelegateSignature params{};
    ProcessEvent(func, &params);
}
void AMagicLeapSharedWorldGameState::OnReplicate_AlignmentTransforms() {
    static auto func = (UFunction*)(find_uobject(10364290092797594824)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameState.OnReplicate_AlignmentTransforms
    struct Params_OnReplicate_AlignmentTransforms {
    }; // Size: 0x0
    Params_OnReplicate_AlignmentTransforms params{};
    ProcessEvent(func, &params);
}
AMagicLeapSharedWorldGameState* AMagicLeapSharedWorldGameState::StaticClass() {
    static auto res = find_uobject(10313949652039693811); // Class /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameState
    return (AMagicLeapSharedWorldGameState*)res;
}
void AMagicLeapSharedWorldGameState::OnReplicate_SharedWorldData() {
    static auto func = (UFunction*)(find_uobject(762268530891408643)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameState.OnReplicate_SharedWorldData
    struct Params_OnReplicate_SharedWorldData {
    }; // Size: 0x0
    Params_OnReplicate_SharedWorldData params{};
    ProcessEvent(func, &params);
}
FTransform AMagicLeapSharedWorldGameState::CalculateXRCameraRootTransform() {
    static auto func = (UFunction*)(find_uobject(12078597340722213610)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameState.CalculateXRCameraRootTransform
    struct Params_CalculateXRCameraRootTransform {
        FTransform ReturnValue; // 0x0
    }; // Size: 0x30
    Params_CalculateXRCameraRootTransform params{};
    ProcessEvent(func, &params);
    return (FTransform)params.ReturnValue;
}
