#pragma once
#include <cstdint>
#include "AActor.hpp"
class UClass;
class AOnlineBeaconClient;
#pragma pack(push, 1)
class AOnlineBeaconHostObject : public AActor {
public:
    FString BeaconTypeName; // 0x220
    UClass* ClientBeaconActorClass; // 0x230
    TArray<AOnlineBeaconClient*> ClientActors; // 0x238
    static AOnlineBeaconHostObject* StaticClass();
}; // Size: 0x248
#pragma pack(pop)
