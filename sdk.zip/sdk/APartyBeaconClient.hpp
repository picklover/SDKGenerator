#pragma once
#include <cstdint>
#include "AOnlineBeaconClient.hpp"
#include "EClientRequestType.hpp"
#include "EPartyReservationResult\Type.hpp"
#include "FPartyReservation.hpp"
struct FUniqueNetIdRepl;
#pragma pack(push, 1)
class APartyBeaconClient : public AOnlineBeaconClient {
public:
    char pad_2b0[0x30];
    FString DestSessionId; // 0x2e0
    FPartyReservation PendingReservation; // 0x2f0
    EClientRequestType RequestType; // 0x340
    bool bPendingReservationSent; // 0x341
    bool bCancelReservation; // 0x342
    char pad_343[0x2d];
    static APartyBeaconClient* StaticClass();
    void ServerUpdateReservationRequest(FString SessionId, FPartyReservation& ReservationUpdate);
    void ServerReservationRequest(FString SessionId, FPartyReservation& Reservation);
    void ServerRemoveMemberFromReservationRequest(FString SessionId, FPartyReservation& ReservationUpdate);
    void ServerCancelReservationRequest(FUniqueNetIdRepl& PartyLeader);
    void ServerAddOrUpdateReservationRequest(FString SessionId, FPartyReservation& Reservation);
    void ClientSendReservationUpdates(int32_t NumRemainingReservations);
    void ClientSendReservationFull();
    void ClientReservationResponse(EPartyReservationResult::Type ReservationResponse);
    void ClientCancelReservationResponse(EPartyReservationResult::Type ReservationResponse);
}; // Size: 0x370
#pragma pack(pop)
