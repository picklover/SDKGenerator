#include "APhysicsThruster.hpp"
#include "ARigidBodyBase.hpp"
#include "UPhysicsThrusterComponent.hpp"
APhysicsThruster* APhysicsThruster::StaticClass() {
    static auto res = find_uobject(3344369087030785998); // Class /Script/Engine.PhysicsThruster
    return (APhysicsThruster*)res;
}
