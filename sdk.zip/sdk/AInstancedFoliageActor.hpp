#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class AInstancedFoliageActor : public AActor {
public:
    char pad_220[0x50];
    static AInstancedFoliageActor* StaticClass();
}; // Size: 0x270
#pragma pack(pop)
