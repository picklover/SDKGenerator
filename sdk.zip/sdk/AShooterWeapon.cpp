#include "AActor.hpp"
#include "AShooterCharacter.hpp"
#include "AShooterWeapon.hpp"
#include "FCanvasIcon.hpp"
#include "FWeaponAnim.hpp"
#include "FWeaponData.hpp"
#include "UAudioComponent.hpp"
#include "UClass.hpp"
#include "UForceFeedbackEffect.hpp"
#include "UFunction.hpp"
#include "UParticleSystem.hpp"
#include "UParticleSystemComponent.hpp"
#include "USkeletalMeshComponent.hpp"
#include "USoundCue.hpp"
AShooterWeapon* AShooterWeapon::StaticClass() {
    static auto res = find_uobject(9096740664177507550); // Class /Script/ShooterGame.ShooterWeapon
    return (AShooterWeapon*)res;
}
void AShooterWeapon::OnRep_Reload() {
    static auto func = (UFunction*)(find_uobject(2603764447309770242)); // Function /Script/ShooterGame.ShooterWeapon.OnRep_Reload
    struct Params_OnRep_Reload {
    }; // Size: 0x0
    Params_OnRep_Reload params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon::ServerStopReload() {
    static auto func = (UFunction*)(find_uobject(2353243170525099956)); // Function /Script/ShooterGame.ShooterWeapon.ServerStopReload
    struct Params_ServerStopReload {
    }; // Size: 0x0
    Params_ServerStopReload params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon::ServerStartReload() {
    static auto func = (UFunction*)(find_uobject(5656656011930454686)); // Function /Script/ShooterGame.ShooterWeapon.ServerStartReload
    struct Params_ServerStartReload {
    }; // Size: 0x0
    Params_ServerStartReload params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon::ServerStopFire() {
    static auto func = (UFunction*)(find_uobject(13608275478866694353)); // Function /Script/ShooterGame.ShooterWeapon.ServerStopFire
    struct Params_ServerStopFire {
    }; // Size: 0x0
    Params_ServerStopFire params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon::ServerStartFire() {
    static auto func = (UFunction*)(find_uobject(16098766493935526147)); // Function /Script/ShooterGame.ShooterWeapon.ServerStartFire
    struct Params_ServerStartFire {
    }; // Size: 0x0
    Params_ServerStartFire params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon::ServerHandleFiring() {
    static auto func = (UFunction*)(find_uobject(3825618789366076992)); // Function /Script/ShooterGame.ShooterWeapon.ServerHandleFiring
    struct Params_ServerHandleFiring {
    }; // Size: 0x0
    Params_ServerHandleFiring params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon::OnRep_MyPawn() {
    static auto func = (UFunction*)(find_uobject(9745357610621460727)); // Function /Script/ShooterGame.ShooterWeapon.OnRep_MyPawn
    struct Params_OnRep_MyPawn {
    }; // Size: 0x0
    Params_OnRep_MyPawn params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon::OnRep_BurstCounter() {
    static auto func = (UFunction*)(find_uobject(3999524575221011169)); // Function /Script/ShooterGame.ShooterWeapon.OnRep_BurstCounter
    struct Params_OnRep_BurstCounter {
    }; // Size: 0x0
    Params_OnRep_BurstCounter params{};
    ProcessEvent(func, &params);
}
AShooterCharacter* AShooterWeapon::GetPawnOwner() {
    static auto func = (UFunction*)(find_uobject(16958659496431008955)); // Function /Script/ShooterGame.ShooterWeapon.GetPawnOwner
    struct Params_GetPawnOwner {
        AShooterCharacter* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_GetPawnOwner params{};
    ProcessEvent(func, &params);
    return (AShooterCharacter*)params.ReturnValue;
}
void AShooterWeapon::ClientStartReload() {
    static auto func = (UFunction*)(find_uobject(14087741373779416434)); // Function /Script/ShooterGame.ShooterWeapon.ClientStartReload
    struct Params_ClientStartReload {
    }; // Size: 0x0
    Params_ClientStartReload params{};
    ProcessEvent(func, &params);
}
