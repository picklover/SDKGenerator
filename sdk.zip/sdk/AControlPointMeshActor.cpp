#include "AActor.hpp"
#include "AControlPointMeshActor.hpp"
#include "UControlPointMeshComponent.hpp"
AControlPointMeshActor* AControlPointMeshActor::StaticClass() {
    static auto res = find_uobject(6240897191200444292); // Class /Script/Landscape.ControlPointMeshActor
    return (AControlPointMeshActor*)res;
}
