#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FRotator.hpp"
#include "FVector.hpp"
class APlayerController;
class APlayerState;
class APawn;
class USceneComponent;
class ACharacter;
class UDamageType;
#pragma pack(push, 1)
class AController : public AActor {
public:
    char pad_220[0x8];
    APlayerState* PlayerState; // 0x228
    char pad_230[0x18];
    FName StateName; // 0x248
    APawn* Pawn; // 0x250
    char pad_258[0x8];
    ACharacter* Character; // 0x260
    USceneComponent* TransformComponent; // 0x268
    char pad_270[0x18];
    FRotator ControlRotation; // 0x288
    uint8_t bAttachToPawn : 1; // 0x294
    uint8_t pad_bitfield_294_1 : 7;
    char pad_295[0x3];
    static AController* StaticClass();
    void UnPossess();
    void StopMovement();
    void SetInitialLocationAndRotation(FVector& NewLocation, FRotator& NewRotation);
    void SetIgnoreMoveInput(bool bNewMoveInput);
    void SetIgnoreLookInput(bool bNewLookInput);
    void SetControlRotation(FRotator& NewRotation);
    void ResetIgnoreMoveInput();
    void ResetIgnoreLookInput();
    void ResetIgnoreInputFlags();
    void ReceiveUnPossess(APawn* UnpossessedPawn);
    void ReceivePossess(APawn* PossessedPawn);
    void ReceiveInstigatedAnyDamage(float Damage, UDamageType* DamageType, AActor* DamagedActor, AActor* DamageCauser);
    void Possess(APawn* InPawn);
    void OnRep_PlayerState();
    void OnRep_Pawn();
    bool LineOfSightTo(AActor* Other, FVector ViewPoint, bool bAlternateChecks);
    APawn* K2_GetPawn();
    bool IsPlayerController();
    bool IsMoveInputIgnored();
    bool IsLookInputIgnored();
    bool IsLocalPlayerController();
    bool IsLocalController();
    AActor* GetViewTarget();
    FRotator GetDesiredRotation();
    FRotator GetControlRotation();
    void ClientSetRotation(FRotator NewRotation, bool bResetCamera);
    void ClientSetLocation(FVector NewLocation, FRotator NewRotation);
    APlayerController* CastToPlayerController();
}; // Size: 0x298
#pragma pack(pop)
