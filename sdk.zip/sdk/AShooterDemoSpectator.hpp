#pragma once
#include <cstdint>
#include "APlayerController.hpp"
#pragma pack(push, 1)
class AShooterDemoSpectator : public APlayerController {
public:
    char pad_570[0x28];
    static AShooterDemoSpectator* StaticClass();
}; // Size: 0x598
#pragma pack(pop)
