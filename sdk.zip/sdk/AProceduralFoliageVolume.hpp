#pragma once
#include <cstdint>
#include "AVolume.hpp"
class UProceduralFoliageComponent;
#pragma pack(push, 1)
class AProceduralFoliageVolume : public AVolume {
public:
    UProceduralFoliageComponent* ProceduralComponent; // 0x258
    static AProceduralFoliageVolume* StaticClass();
}; // Size: 0x260
#pragma pack(pop)
