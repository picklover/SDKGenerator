#pragma once
#include <cstdint>
#include "AShooterImpactEffect.hpp"
class USceneComponent;
#pragma pack(push, 1)
class AWeapGun_Impacts_C : public AShooterImpactEffect {
public:
    USceneComponent* DefaultSceneRoot; // 0x348
    static AWeapGun_Impacts_C* StaticClass();
}; // Size: 0x350
#pragma pack(pop)
