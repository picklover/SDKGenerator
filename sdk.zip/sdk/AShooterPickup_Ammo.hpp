#pragma once
#include <cstdint>
#include "AShooterPickup.hpp"
class UClass;
#pragma pack(push, 1)
class AShooterPickup_Ammo : public AShooterPickup {
public:
    int32_t AmmoClips; // 0x260
    char pad_264[0x4];
    UClass* WeaponType; // 0x268
    static AShooterPickup_Ammo* StaticClass();
}; // Size: 0x270
#pragma pack(pop)
