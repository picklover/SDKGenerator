#pragma once
#include <cstdint>
#include "AGameSession.hpp"
#pragma pack(push, 1)
class AShooterGameSession : public AGameSession {
public:
    char pad_238[0x108];
    static AShooterGameSession* StaticClass();
}; // Size: 0x340
#pragma pack(pop)
