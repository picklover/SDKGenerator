#include "APhysicsVolume.hpp"
#include "AVolume.hpp"
APhysicsVolume* APhysicsVolume::StaticClass() {
    static auto res = find_uobject(11325052244287291177); // Class /Script/Engine.PhysicsVolume
    return (APhysicsVolume*)res;
}
