#pragma once
#include <cstdint>
#include "AShooterCharacter.hpp"
#pragma pack(push, 1)
class APlayerPawn_C : public AShooterCharacter {
public:
    static APlayerPawn_C* StaticClass();
}; // Size: 0x6a0
#pragma pack(pop)
