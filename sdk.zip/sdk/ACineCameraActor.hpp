#pragma once
#include <cstdint>
#include "ACameraActor.hpp"
#include "FCameraLookatTrackingSettings.hpp"
class UCineCameraComponent;
#pragma pack(push, 1)
class ACineCameraActor : public ACameraActor {
public:
    FCameraLookatTrackingSettings LookatTrackingSettings; // 0x7b0
    char pad_800[0x10];
    static ACineCameraActor* StaticClass();
    UCineCameraComponent* GetCineCameraComponent();
}; // Size: 0x810
#pragma pack(pop)
