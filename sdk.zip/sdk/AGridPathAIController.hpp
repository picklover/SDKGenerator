#pragma once
#include <cstdint>
#include "AAIController.hpp"
#pragma pack(push, 1)
class AGridPathAIController : public AAIController {
public:
    static AGridPathAIController* StaticClass();
}; // Size: 0x328
#pragma pack(pop)
