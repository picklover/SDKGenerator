#pragma once
#include <cstdint>
#include "APawn.hpp"
class UPawnMovementComponent;
class USphereComponent;
class UStaticMeshComponent;
#pragma pack(push, 1)
class ADefaultPawn : public APawn {
public:
    float BaseTurnRate; // 0x280
    float BaseLookUpRate; // 0x284
    UPawnMovementComponent* MovementComponent; // 0x288
    USphereComponent* CollisionComponent; // 0x290
    UStaticMeshComponent* MeshComponent; // 0x298
    uint8_t bAddDefaultMovementBindings : 1; // 0x2a0
    uint8_t pad_bitfield_2a0_1 : 7;
    char pad_2a1[0x7];
    static ADefaultPawn* StaticClass();
    void TurnAtRate(float Rate);
    void MoveUp_World(float Val);
    void MoveRight(float Val);
    void MoveForward(float Val);
    void LookUpAtRate(float Rate);
}; // Size: 0x2a8
#pragma pack(pop)
