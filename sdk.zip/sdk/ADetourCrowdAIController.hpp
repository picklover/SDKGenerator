#pragma once
#include <cstdint>
#include "AAIController.hpp"
#pragma pack(push, 1)
class ADetourCrowdAIController : public AAIController {
public:
    static ADetourCrowdAIController* StaticClass();
}; // Size: 0x328
#pragma pack(pop)
