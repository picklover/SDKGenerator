#include "ACullDistanceVolume.hpp"
#include "AVolume.hpp"
#include "FCullDistanceSizePair.hpp"
ACullDistanceVolume* ACullDistanceVolume::StaticClass() {
    static auto res = find_uobject(8136597136538677071); // Class /Script/Engine.CullDistanceVolume
    return (ACullDistanceVolume*)res;
}
