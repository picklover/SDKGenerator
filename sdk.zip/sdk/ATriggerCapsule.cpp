#include "ATriggerBase.hpp"
#include "ATriggerCapsule.hpp"
ATriggerCapsule* ATriggerCapsule::StaticClass() {
    static auto res = find_uobject(11697193204929142041); // Class /Script/Engine.TriggerCapsule
    return (ATriggerCapsule*)res;
}
