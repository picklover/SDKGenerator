#include "AActor.hpp"
#include "ADocumentationActor.hpp"
ADocumentationActor* ADocumentationActor::StaticClass() {
    static auto res = find_uobject(10418357386890673169); // Class /Script/Engine.DocumentationActor
    return (ADocumentationActor*)res;
}
