#include "AProceduralFoliageVolume.hpp"
#include "AVolume.hpp"
#include "UProceduralFoliageComponent.hpp"
AProceduralFoliageVolume* AProceduralFoliageVolume::StaticClass() {
    static auto res = find_uobject(18446001745821922567); // Class /Script/Foliage.ProceduralFoliageVolume
    return (AProceduralFoliageVolume*)res;
}
