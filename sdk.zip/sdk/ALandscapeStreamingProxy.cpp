#include "ALandscapeProxy.hpp"
#include "ALandscapeStreamingProxy.hpp"
ALandscapeStreamingProxy* ALandscapeStreamingProxy::StaticClass() {
    static auto res = find_uobject(12384158248233515604); // Class /Script/Landscape.LandscapeStreamingProxy
    return (ALandscapeStreamingProxy*)res;
}
