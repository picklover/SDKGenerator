#include "AActor.hpp"
#include "ANavigationObjectBase.hpp"
#include "UBillboardComponent.hpp"
#include "UCapsuleComponent.hpp"
ANavigationObjectBase* ANavigationObjectBase::StaticClass() {
    static auto res = find_uobject(5659920842918411606); // Class /Script/Engine.NavigationObjectBase
    return (ANavigationObjectBase*)res;
}
