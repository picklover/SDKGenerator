#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FMovieSceneSequencePlaybackSettings.hpp"
#include "FSoftObjectPath.hpp"
#include "FTemplateSequenceBindingOverrideData.hpp"
class UTemplateSequencePlayer;
class UTemplateSequence;
#pragma pack(push, 1)
class ATemplateSequenceActor : public AActor {
public:
    char pad_220[0x10];
    FMovieSceneSequencePlaybackSettings PlaybackSettings; // 0x230
    char pad_244[0x4];
    UTemplateSequencePlayer* SequencePlayer; // 0x248
    FSoftObjectPath TemplateSequence; // 0x250
    FTemplateSequenceBindingOverrideData BindingOverride; // 0x268
    char pad_274[0x4];
    static ATemplateSequenceActor* StaticClass();
    void SetSequence(UTemplateSequence* InSequence);
    void SetBinding(AActor* Actor, bool bOverridesDefault);
    UTemplateSequence* LoadSequence();
    UTemplateSequencePlayer* GetSequencePlayer();
    UTemplateSequence* GetSequence();
}; // Size: 0x278
#pragma pack(pop)
