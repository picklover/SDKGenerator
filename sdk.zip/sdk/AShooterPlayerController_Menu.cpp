#include "APlayerController.hpp"
#include "AShooterPlayerController_Menu.hpp"
AShooterPlayerController_Menu* AShooterPlayerController_Menu::StaticClass() {
    static auto res = find_uobject(8717877746860129683); // Class /Script/ShooterGame.ShooterPlayerController_Menu
    return (AShooterPlayerController_Menu*)res;
}
