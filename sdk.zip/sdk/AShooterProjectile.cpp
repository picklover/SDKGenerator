#include "AActor.hpp"
#include "AShooterProjectile.hpp"
#include "FHitResult.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
#include "UParticleSystemComponent.hpp"
#include "UProjectileMovementComponent.hpp"
#include "USphereComponent.hpp"
void AShooterProjectile::OnImpact(FHitResult& HitResult) {
    static auto func = (UFunction*)(find_uobject(12156706623073970352)); // Function /Script/ShooterGame.ShooterProjectile.OnImpact
    struct Params_OnImpact {
        FHitResult HitResult; // 0x0
    }; // Size: 0x88
    Params_OnImpact params{};
    params.HitResult = (FHitResult)HitResult;
    ProcessEvent(func, &params);
    HitResult = params.HitResult;
}
AShooterProjectile* AShooterProjectile::StaticClass() {
    static auto res = find_uobject(8583588299646759085); // Class /Script/ShooterGame.ShooterProjectile
    return (AShooterProjectile*)res;
}
void AShooterProjectile::OnRep_Exploded() {
    static auto func = (UFunction*)(find_uobject(6545198591656023365)); // Function /Script/ShooterGame.ShooterProjectile.OnRep_Exploded
    struct Params_OnRep_Exploded {
    }; // Size: 0x0
    Params_OnRep_Exploded params{};
    ProcessEvent(func, &params);
}
