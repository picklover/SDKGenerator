#pragma once
#include <cstdint>
#include "AShooterBot.hpp"
#pragma pack(push, 1)
class ABotPawn_C : public AShooterBot {
public:
    static ABotPawn_C* StaticClass();
}; // Size: 0x6b0
#pragma pack(pop)
