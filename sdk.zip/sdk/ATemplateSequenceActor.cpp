#include "AActor.hpp"
#include "ATemplateSequenceActor.hpp"
#include "FMovieSceneSequencePlaybackSettings.hpp"
#include "FSoftObjectPath.hpp"
#include "FTemplateSequenceBindingOverrideData.hpp"
#include "UFunction.hpp"
#include "UTemplateSequence.hpp"
#include "UTemplateSequencePlayer.hpp"
ATemplateSequenceActor* ATemplateSequenceActor::StaticClass() {
    static auto res = find_uobject(9374791458020728079); // Class /Script/TemplateSequence.TemplateSequenceActor
    return (ATemplateSequenceActor*)res;
}
void ATemplateSequenceActor::SetBinding(AActor* Actor, bool bOverridesDefault) {
    static auto func = (UFunction*)(find_uobject(15671023168910556500)); // Function /Script/TemplateSequence.TemplateSequenceActor.SetBinding
    struct Params_SetBinding {
        AActor* Actor; // 0x0
        bool bOverridesDefault; // 0x8
    }; // Size: 0x9
    Params_SetBinding params{};
    params.Actor = (AActor*)Actor;
    params.bOverridesDefault = (bool)bOverridesDefault;
    ProcessEvent(func, &params);
}
void ATemplateSequenceActor::SetSequence(UTemplateSequence* InSequence) {
    static auto func = (UFunction*)(find_uobject(5411437121843345402)); // Function /Script/TemplateSequence.TemplateSequenceActor.SetSequence
    struct Params_SetSequence {
        UTemplateSequence* InSequence; // 0x0
    }; // Size: 0x8
    Params_SetSequence params{};
    params.InSequence = (UTemplateSequence*)InSequence;
    ProcessEvent(func, &params);
}
UTemplateSequence* ATemplateSequenceActor::LoadSequence() {
    static auto func = (UFunction*)(find_uobject(16786078531829464092)); // Function /Script/TemplateSequence.TemplateSequenceActor.LoadSequence
    struct Params_LoadSequence {
        UTemplateSequence* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_LoadSequence params{};
    ProcessEvent(func, &params);
    return (UTemplateSequence*)params.ReturnValue;
}
UTemplateSequencePlayer* ATemplateSequenceActor::GetSequencePlayer() {
    static auto func = (UFunction*)(find_uobject(181059886890386687)); // Function /Script/TemplateSequence.TemplateSequenceActor.GetSequencePlayer
    struct Params_GetSequencePlayer {
        UTemplateSequencePlayer* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_GetSequencePlayer params{};
    ProcessEvent(func, &params);
    return (UTemplateSequencePlayer*)params.ReturnValue;
}
UTemplateSequence* ATemplateSequenceActor::GetSequence() {
    static auto func = (UFunction*)(find_uobject(1669910033848522134)); // Function /Script/TemplateSequence.TemplateSequenceActor.GetSequence
    struct Params_GetSequence {
        UTemplateSequence* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_GetSequence params{};
    ProcessEvent(func, &params);
    return (UTemplateSequence*)params.ReturnValue;
}
