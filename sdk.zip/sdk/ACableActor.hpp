#pragma once
#include <cstdint>
#include "AActor.hpp"
class UCableComponent;
#pragma pack(push, 1)
class ACableActor : public AActor {
public:
    UCableComponent* CableComponent; // 0x220
    static ACableActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
