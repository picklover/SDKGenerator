#include "AActor.hpp"
#include "ASplineMeshActor.hpp"
#include "USplineMeshComponent.hpp"
ASplineMeshActor* ASplineMeshActor::StaticClass() {
    static auto res = find_uobject(15949480739925661107); // Class /Script/Engine.SplineMeshActor
    return (ASplineMeshActor*)res;
}
