#include "AActor.hpp"
#include "ADecalActor.hpp"
#include "UDecalComponent.hpp"
#include "UFunction.hpp"
#include "UMaterialInstanceDynamic.hpp"
#include "UMaterialInterface.hpp"
UMaterialInterface* ADecalActor::GetDecalMaterial() {
    static auto func = (UFunction*)(find_uobject(11389002324549790236)); // Function /Script/Engine.DecalActor.GetDecalMaterial
    struct Params_GetDecalMaterial {
        UMaterialInterface* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_GetDecalMaterial params{};
    ProcessEvent(func, &params);
    return (UMaterialInterface*)params.ReturnValue;
}
ADecalActor* ADecalActor::StaticClass() {
    static auto res = find_uobject(13917473092324480168); // Class /Script/Engine.DecalActor
    return (ADecalActor*)res;
}
void ADecalActor::SetDecalMaterial(UMaterialInterface* NewDecalMaterial) {
    static auto func = (UFunction*)(find_uobject(7799790485828429152)); // Function /Script/Engine.DecalActor.SetDecalMaterial
    struct Params_SetDecalMaterial {
        UMaterialInterface* NewDecalMaterial; // 0x0
    }; // Size: 0x8
    Params_SetDecalMaterial params{};
    params.NewDecalMaterial = (UMaterialInterface*)NewDecalMaterial;
    ProcessEvent(func, &params);
}
UMaterialInstanceDynamic* ADecalActor::CreateDynamicMaterialInstance() {
    static auto func = (UFunction*)(find_uobject(10159739228148233755)); // Function /Script/Engine.DecalActor.CreateDynamicMaterialInstance
    struct Params_CreateDynamicMaterialInstance {
        UMaterialInstanceDynamic* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_CreateDynamicMaterialInstance params{};
    ProcessEvent(func, &params);
    return (UMaterialInstanceDynamic*)params.ReturnValue;
}
