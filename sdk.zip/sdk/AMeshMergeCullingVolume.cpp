#include "AMeshMergeCullingVolume.hpp"
#include "AVolume.hpp"
AMeshMergeCullingVolume* AMeshMergeCullingVolume::StaticClass() {
    static auto res = find_uobject(1985342244969347477); // Class /Script/Engine.MeshMergeCullingVolume
    return (AMeshMergeCullingVolume*)res;
}
