#include "AShooterPickup.hpp"
#include "AShooterPickup_Ammo.hpp"
#include "UClass.hpp"
AShooterPickup_Ammo* AShooterPickup_Ammo::StaticClass() {
    static auto res = find_uobject(2732351305395703077); // Class /Script/ShooterGame.ShooterPickup_Ammo
    return (AShooterPickup_Ammo*)res;
}
