#include "AGameMode.hpp"
#include "AMagicLeapSharedWorldGameMode.hpp"
#include "AMagicLeapSharedWorldPlayerController.hpp"
#include "FMagicLeapSharedWorldSharedData.hpp"
#include "UFunction.hpp"
AMagicLeapSharedWorldGameMode* AMagicLeapSharedWorldGameMode::StaticClass() {
    static auto res = find_uobject(1486274469453914197); // Class /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameMode
    return (AMagicLeapSharedWorldGameMode*)res;
}
bool AMagicLeapSharedWorldGameMode::SendSharedWorldDataToClients() {
    static auto func = (UFunction*)(find_uobject(4666708884070607515)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.SendSharedWorldDataToClients
    struct Params_SendSharedWorldDataToClients {
        bool ReturnValue; // 0x0
    }; // Size: 0x1
    Params_SendSharedWorldDataToClients params{};
    ProcessEvent(func, &params);
    return (bool)params.ReturnValue;
}
void AMagicLeapSharedWorldGameMode::SelectChosenOne() {
    static auto func = (UFunction*)(find_uobject(13793845936803081147)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.SelectChosenOne
    struct Params_SelectChosenOne {
    }; // Size: 0x0
    Params_SelectChosenOne params{};
    ProcessEvent(func, &params);
}
void AMagicLeapSharedWorldGameMode::MagicLeapOnNewLocalDataFromClients__DelegateSignature() {
    static auto func = (UFunction*)(find_uobject(7843030829222577282)); // DelegateFunction /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.MagicLeapOnNewLocalDataFromClients__DelegateSignature
    struct Params_MagicLeapOnNewLocalDataFromClients__DelegateSignature {
    }; // Size: 0x0
    Params_MagicLeapOnNewLocalDataFromClients__DelegateSignature params{};
    ProcessEvent(func, &params);
}
void AMagicLeapSharedWorldGameMode::DetermineSharedWorldData(FMagicLeapSharedWorldSharedData& NewSharedWorldData) {
    static auto func = (UFunction*)(find_uobject(13491471940608611851)); // Function /Script/MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.DetermineSharedWorldData
    struct Params_DetermineSharedWorldData {
        FMagicLeapSharedWorldSharedData NewSharedWorldData; // 0x0
    }; // Size: 0x10
    Params_DetermineSharedWorldData params{};
    params.NewSharedWorldData = (FMagicLeapSharedWorldSharedData)NewSharedWorldData;
    ProcessEvent(func, &params);
    NewSharedWorldData = params.NewSharedWorldData;
}
