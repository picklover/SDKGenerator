#include "AActor.hpp"
#include "AInstancedFoliageActor.hpp"
AInstancedFoliageActor* AInstancedFoliageActor::StaticClass() {
    static auto res = find_uobject(12859152509007043650); // Class /Script/Foliage.InstancedFoliageActor
    return (AInstancedFoliageActor*)res;
}
