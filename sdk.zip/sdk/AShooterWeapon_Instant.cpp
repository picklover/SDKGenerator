#include "AShooterWeapon.hpp"
#include "AShooterWeapon_Instant.hpp"
#include "FHitResult.hpp"
#include "FInstantHitInfo.hpp"
#include "FInstantWeaponData.hpp"
#include "FVector_NetQuantizeNormal.hpp"
#include "UClass.hpp"
#include "UFunction.hpp"
#include "UParticleSystem.hpp"
AShooterWeapon_Instant* AShooterWeapon_Instant::StaticClass() {
    static auto res = find_uobject(2864472989098878112); // Class /Script/ShooterGame.ShooterWeapon_Instant
    return (AShooterWeapon_Instant*)res;
}
void AShooterWeapon_Instant::OnRep_HitNotify() {
    static auto func = (UFunction*)(find_uobject(1194919985694232591)); // Function /Script/ShooterGame.ShooterWeapon_Instant.OnRep_HitNotify
    struct Params_OnRep_HitNotify {
    }; // Size: 0x0
    Params_OnRep_HitNotify params{};
    ProcessEvent(func, &params);
}
void AShooterWeapon_Instant::ServerNotifyMiss(FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float ReticleSpread) {
    static auto func = (UFunction*)(find_uobject(14796011632741240770)); // Function /Script/ShooterGame.ShooterWeapon_Instant.ServerNotifyMiss
    struct Params_ServerNotifyMiss {
        FVector_NetQuantizeNormal ShootDir; // 0x0
        int32_t RandomSeed; // 0xc
        float ReticleSpread; // 0x10
    }; // Size: 0x14
    Params_ServerNotifyMiss params{};
    params.ShootDir = (FVector_NetQuantizeNormal)ShootDir;
    params.RandomSeed = (int32_t)RandomSeed;
    params.ReticleSpread = (float)ReticleSpread;
    ProcessEvent(func, &params);
}
void AShooterWeapon_Instant::ServerNotifyHit(FHitResult& Impact, FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float ReticleSpread) {
    static auto func = (UFunction*)(find_uobject(3432752429560186619)); // Function /Script/ShooterGame.ShooterWeapon_Instant.ServerNotifyHit
    struct Params_ServerNotifyHit {
        FHitResult Impact; // 0x0
        FVector_NetQuantizeNormal ShootDir; // 0x88
        int32_t RandomSeed; // 0x94
        float ReticleSpread; // 0x98
    }; // Size: 0x9c
    Params_ServerNotifyHit params{};
    params.Impact = (FHitResult)Impact;
    params.ShootDir = (FVector_NetQuantizeNormal)ShootDir;
    params.RandomSeed = (int32_t)RandomSeed;
    params.ReticleSpread = (float)ReticleSpread;
    ProcessEvent(func, &params);
    Impact = params.Impact;
}
