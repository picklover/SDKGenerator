#pragma once
#include <cstdint>
#include "AGameState.hpp"
#pragma pack(push, 1)
class AShooterGameState : public AGameState {
public:
    int32_t NumTeams; // 0x290
    char pad_294[0x4];
    TArray<int32_t> TeamScores; // 0x298
    int32_t RemainingTime; // 0x2a8
    bool bTimerPaused; // 0x2ac
    char pad_2ad[0x3];
    FString ActivityId; // 0x2b0
    bool bEnableGameFeedback; // 0x2c0
    char pad_2c1[0x117];
    static AShooterGameState* StaticClass();
}; // Size: 0x3d8
#pragma pack(pop)
