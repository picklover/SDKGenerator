#pragma once
#include <cstdint>
#include "AActor.hpp"
class UPaperFlipbookComponent;
#pragma pack(push, 1)
class APaperFlipbookActor : public AActor {
public:
    UPaperFlipbookComponent* RenderComponent; // 0x220
    static APaperFlipbookActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
