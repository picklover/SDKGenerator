#pragma once
#include <cstdint>
#pragma pack(push, 1)
enum class EAREye : uint8_t {
    LeftEye = 0,
    RightEye = 1,
    EAREye_MAX = 2,
};
#pragma pack(pop)
