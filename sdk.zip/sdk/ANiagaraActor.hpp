#pragma once
#include <cstdint>
#include "AActor.hpp"
class UNiagaraComponent;
#pragma pack(push, 1)
class ANiagaraActor : public AActor {
public:
    UNiagaraComponent* NiagaraComponent; // 0x220
    uint8_t bDestroyOnSystemFinish : 1; // 0x228
    uint8_t pad_bitfield_228_1 : 7;
    char pad_229[0x7];
    static ANiagaraActor* StaticClass();
    void SetDestroyOnSystemFinish(bool bShouldDestroyOnSystemFinish);
    void OnNiagaraSystemFinished(UNiagaraComponent* FinishedComponent);
}; // Size: 0x230
#pragma pack(pop)
