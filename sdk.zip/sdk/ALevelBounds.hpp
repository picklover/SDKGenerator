#pragma once
#include <cstdint>
#include "AActor.hpp"
class UBoxComponent;
#pragma pack(push, 1)
class ALevelBounds : public AActor {
public:
    UBoxComponent* BoxComponent; // 0x220
    bool bAutoUpdateBounds; // 0x228
    char pad_229[0x7];
    static ALevelBounds* StaticClass();
}; // Size: 0x230
#pragma pack(pop)
