#include "ABoxReflectionCapture.hpp"
#include "AReflectionCapture.hpp"
ABoxReflectionCapture* ABoxReflectionCapture::StaticClass() {
    static auto res = find_uobject(2001834572611496932); // Class /Script/Engine.BoxReflectionCapture
    return (ABoxReflectionCapture*)res;
}
