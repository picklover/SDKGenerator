#include "ABotPawn_C.hpp"
#include "AShooterBot.hpp"
ABotPawn_C* ABotPawn_C::StaticClass() {
    static auto res = find_uobject(8739254039058806518); // BlueprintGeneratedClass /Game/Blueprints/Pawns/BotPawn.BotPawn_C
    return (ABotPawn_C*)res;
}
