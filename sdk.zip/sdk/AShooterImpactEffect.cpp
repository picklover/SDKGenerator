#include "AActor.hpp"
#include "AShooterImpactEffect.hpp"
#include "FDecalData.hpp"
#include "FHitResult.hpp"
#include "UParticleSystem.hpp"
#include "USoundCue.hpp"
AShooterImpactEffect* AShooterImpactEffect::StaticClass() {
    static auto res = find_uobject(17820379582188677949); // Class /Script/ShooterGame.ShooterImpactEffect
    return (AShooterImpactEffect*)res;
}
