#include "ATriggerVolume.hpp"
#include "AVolume.hpp"
ATriggerVolume* ATriggerVolume::StaticClass() {
    static auto res = find_uobject(7290314372930104576); // Class /Script/Engine.TriggerVolume
    return (ATriggerVolume*)res;
}
