#pragma once
#include <cstdint>
#pragma pack(push, 1)
enum Default__UserDefinedEnum {
};
#pragma pack(pop)
