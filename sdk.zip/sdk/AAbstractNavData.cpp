#include "AAbstractNavData.hpp"
#include "ANavigationData.hpp"
AAbstractNavData* AAbstractNavData::StaticClass() {
    static auto res = find_uobject(6108973923209086752); // Class /Script/NavigationSystem.AbstractNavData
    return (AAbstractNavData*)res;
}
