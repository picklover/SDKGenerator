#pragma once
#include <cstdint>
#include "AMagicLeapARPinInfoActorBase.hpp"
#include "FHitResult.hpp"
#include "FPointerToUberGraphFrame.hpp"
#include "FRotator.hpp"
#include "FVector.hpp"
class UStaticMeshComponent;
class UTextRenderComponent;
class USphereComponent;
class USceneComponent;
class UMaterialInstanceDynamic;
class APlayerCameraManager;
#pragma pack(push, 1)
class AMagicLeapARPinInfoActor_C : public AMagicLeapARPinInfoActorBase {
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x238
    UStaticMeshComponent* Right; // 0x240
    UStaticMeshComponent* Forward; // 0x248
    UStaticMeshComponent* Up; // 0x250
    USphereComponent* ValidRadiusVisualizer; // 0x258
    USceneComponent* AxisRoot; // 0x260
    USceneComponent* VisualizerRoot; // 0x268
    UTextRenderComponent* TypeValue; // 0x270
    UTextRenderComponent* TransErrValue; // 0x278
    UTextRenderComponent* RotErrValue; // 0x280
    UTextRenderComponent* ConfidenceValue; // 0x288
    UTextRenderComponent* TransErrLabel; // 0x290
    UTextRenderComponent* RotErrLabel; // 0x298
    UTextRenderComponent* ConfidenceLabel; // 0x2a0
    UTextRenderComponent* PinIDValue; // 0x2a8
    USceneComponent* InfoRoot; // 0x2b0
    USceneComponent* Root; // 0x2b8
    float RotationSmoothSpeed; // 0x2c0
    char pad_2c4[0x4];
    static AMagicLeapARPinInfoActor_C* StaticClass();
    void UpdatePinState();
    void UserConstructionScript(UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue, UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_1, UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2);
    void OnUpdateARPinState0();
    void ReceiveTick(float DeltaSeconds);
    void ExecuteUbergraph_MagicLeapARPinInfoActor(int32_t EntryPoint, APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue, FVector CallFunc_GetCameraLocation_ReturnValue, FRotator CallFunc_K2_GetComponentRotation_ReturnValue, FVector CallFunc_K2_GetComponentLocation_ReturnValue, FRotator CallFunc_FindLookAtRotation_ReturnValue, FVector CallFunc_GetARPinPositionAndOrientation_Position, FRotator CallFunc_GetARPinPositionAndOrientation_Orientation, bool CallFunc_GetARPinPositionAndOrientation_PinFoundInEnvironment, bool CallFunc_GetARPinPositionAndOrientation_ReturnValue, FHitResult CallFunc_K2_SetWorldLocationAndRotation_SweepHitResult, FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult, float K2Node_Event_DeltaSeconds, FRotator CallFunc_RInterpTo_ReturnValue, FString CallFunc_ARPinIdToString_ReturnValue, float CallFunc_BreakRotator_Roll, float CallFunc_BreakRotator_Pitch, float CallFunc_BreakRotator_Yaw);
}; // Size: 0x2c8
#pragma pack(pop)
