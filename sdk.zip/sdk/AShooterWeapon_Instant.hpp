#pragma once
#include <cstdint>
#include "AShooterWeapon.hpp"
#include "FInstantHitInfo.hpp"
#include "FInstantWeaponData.hpp"
#include "FVector_NetQuantizeNormal.hpp"
class UClass;
class UParticleSystem;
struct FHitResult;
#pragma pack(push, 1)
class AShooterWeapon_Instant : public AShooterWeapon {
public:
    FInstantWeaponData InstantConfig; // 0x4a0
    UClass* ImpactTemplate; // 0x4c8
    UParticleSystem* TrailFX; // 0x4d0
    FName TrailTargetParam; // 0x4d8
    FInstantHitInfo HitNotify; // 0x4e0
    char pad_4f4[0x4];
    static AShooterWeapon_Instant* StaticClass();
    void ServerNotifyMiss(FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float ReticleSpread);
    void ServerNotifyHit(FHitResult& Impact, FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float ReticleSpread);
    void OnRep_HitNotify();
}; // Size: 0x4f8
#pragma pack(pop)
