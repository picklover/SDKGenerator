#pragma once
#include <cstdint>
#include "AStaticMeshActor.hpp"
#include "FVector.hpp"
class UCapsuleComponent;
class UPrimitiveComponent;
class AActor;
struct FHitResult;
#pragma pack(push, 1)
class AInteractiveFoliageActor : public AStaticMeshActor {
public:
    UCapsuleComponent* CapsuleComponent; // 0x230
    FVector TouchingActorEntryPosition; // 0x238
    FVector FoliageVelocity; // 0x244
    FVector FoliageForce; // 0x250
    FVector FoliagePosition; // 0x25c
    float FoliageDamageImpulseScale; // 0x268
    float FoliageTouchImpulseScale; // 0x26c
    float FoliageStiffness; // 0x270
    float FoliageStiffnessQuadratic; // 0x274
    float FoliageDamping; // 0x278
    float MaxDamageImpulse; // 0x27c
    float MaxTouchImpulse; // 0x280
    float MaxForce; // 0x284
    float Mass; // 0x288
    char pad_28c[0x4];
    static AInteractiveFoliageActor* StaticClass();
    void CapsuleTouched(UPrimitiveComponent* OverlappedComp, AActor* Other, UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, FHitResult& OverlapInfo);
}; // Size: 0x290
#pragma pack(pop)
