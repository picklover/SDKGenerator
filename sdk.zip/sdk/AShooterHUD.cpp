#include "AHUD.hpp"
#include "AShooterHUD.hpp"
#include "FCanvasIcon.hpp"
#include "UFont.hpp"
#include "UTexture2D.hpp"
AShooterHUD* AShooterHUD::StaticClass() {
    static auto res = find_uobject(7637154154478973011); // Class /Script/ShooterGame.ShooterHUD
    return (AShooterHUD*)res;
}
