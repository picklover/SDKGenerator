#include "AOnlineBeaconClient.hpp"
#include "ATestBeaconClient.hpp"
#include "UFunction.hpp"
void ATestBeaconClient::ClientPing() {
    static auto func = (UFunction*)(find_uobject(15343231781646708269)); // Function /Script/OnlineSubsystemUtils.TestBeaconClient.ClientPing
    struct Params_ClientPing {
    }; // Size: 0x0
    Params_ClientPing params{};
    ProcessEvent(func, &params);
}
ATestBeaconClient* ATestBeaconClient::StaticClass() {
    static auto res = find_uobject(5608133748168231074); // Class /Script/OnlineSubsystemUtils.TestBeaconClient
    return (ATestBeaconClient*)res;
}
void ATestBeaconClient::ServerPong() {
    static auto func = (UFunction*)(find_uobject(3151439697772651871)); // Function /Script/OnlineSubsystemUtils.TestBeaconClient.ServerPong
    struct Params_ServerPong {
    }; // Size: 0x0
    Params_ServerPong params{};
    ProcessEvent(func, &params);
}
