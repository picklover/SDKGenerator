#pragma once
#include <cstdint>
#include "ALevelScriptActor.hpp"
#include "FPointerToUberGraphFrame.hpp"
#pragma pack(push, 1)
class AShooterEntry_C : public ALevelScriptActor {
public:
    FPointerToUberGraphFrame UberGraphFrame; // 0x228
}; // Size: 0x230
#pragma pack(pop)
