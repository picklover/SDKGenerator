#pragma once
#include <cstdint>
#include "AShooterCharacter.hpp"
class UBehaviorTree;
#pragma pack(push, 1)
class AShooterBot : public AShooterCharacter {
public:
    UBehaviorTree* BotBehavior; // 0x6a0
    char pad_6a8[0x8];
    static AShooterBot* StaticClass();
}; // Size: 0x6b0
#pragma pack(pop)
