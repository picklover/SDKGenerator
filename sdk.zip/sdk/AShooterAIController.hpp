#pragma once
#include <cstdint>
#include "AAIController.hpp"
class UBlackboardComponent;
class UBehaviorTreeComponent;
class AShooterCharacter;
#pragma pack(push, 1)
class AShooterAIController : public AAIController {
public:
    UBlackboardComponent* BlackboardComp; // 0x328
    UBehaviorTreeComponent* BehaviorComp; // 0x330
    char pad_338[0x10];
    static AShooterAIController* StaticClass();
    void ShootEnemy();
    bool FindClosestEnemyWithLOS(AShooterCharacter* ExcludeEnemy);
    void FindClosestEnemy();
}; // Size: 0x348
#pragma pack(pop)
