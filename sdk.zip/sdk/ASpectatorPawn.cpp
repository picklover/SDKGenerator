#include "ADefaultPawn.hpp"
#include "ASpectatorPawn.hpp"
ASpectatorPawn* ASpectatorPawn::StaticClass() {
    static auto res = find_uobject(3159294647425817181); // Class /Script/Engine.SpectatorPawn
    return (ASpectatorPawn*)res;
}
