#include "AMatineeActor.hpp"
#include "AMatineeActorCameraAnim.hpp"
#include "UCameraAnim.hpp"
AMatineeActorCameraAnim* AMatineeActorCameraAnim::StaticClass() {
    static auto res = find_uobject(3921190496220244084); // Class /Script/Engine.MatineeActorCameraAnim
    return (AMatineeActorCameraAnim*)res;
}
