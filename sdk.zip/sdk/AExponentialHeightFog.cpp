#include "AExponentialHeightFog.hpp"
#include "AInfo.hpp"
#include "UExponentialHeightFogComponent.hpp"
#include "UFunction.hpp"
AExponentialHeightFog* AExponentialHeightFog::StaticClass() {
    static auto res = find_uobject(5241079849028457378); // Class /Script/Engine.ExponentialHeightFog
    return (AExponentialHeightFog*)res;
}
void AExponentialHeightFog::OnRep_bEnabled() {
    static auto func = (UFunction*)(find_uobject(11716846141642105124)); // Function /Script/Engine.ExponentialHeightFog.OnRep_bEnabled
    struct Params_OnRep_bEnabled {
    }; // Size: 0x0
    Params_OnRep_bEnabled params{};
    ProcessEvent(func, &params);
}
