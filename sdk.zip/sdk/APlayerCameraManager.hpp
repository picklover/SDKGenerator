#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "ECameraShakePlaySpace.hpp"
#include "FCameraCacheEntry.hpp"
#include "FLinearColor.hpp"
#include "FPostProcessSettings.hpp"
#include "FRotator.hpp"
#include "FTViewTarget.hpp"
#include "FVector.hpp"
class USceneComponent;
class APlayerController;
class ACameraActor;
class AEmitterCameraLensEffectBase;
class UClass;
class UCameraModifier;
class UCameraModifier_CameraShake;
class UCameraAnimInst;
class UCameraShakeBase;
class UCameraShakeSourceComponent;
class UCameraAnim;
#pragma pack(push, 1)
class APlayerCameraManager : public AActor {
public:
    APlayerController* PCOwner; // 0x220
    USceneComponent* TransformComponent; // 0x228
    char pad_230[0x8];
    float DefaultFOV; // 0x238
    char pad_23c[0x4];
    float DefaultOrthoWidth; // 0x240
    char pad_244[0x4];
    float DefaultAspectRatio; // 0x248
    char pad_24c[0x44];
    FCameraCacheEntry CameraCache; // 0x290
    FCameraCacheEntry LastFrameCameraCache; // 0x890
    FTViewTarget ViewTarget; // 0xe90
    FTViewTarget PendingViewTarget; // 0x14a0
    char pad_1ab0[0x30];
    FCameraCacheEntry CameraCachePrivate; // 0x1ae0
    FCameraCacheEntry LastFrameCameraCachePrivate; // 0x20e0
    TArray<UCameraModifier*> ModifierList; // 0x26e0
    TArray<UClass*> DefaultModifiers; // 0x26f0
    float FreeCamDistance; // 0x2700
    FVector FreeCamOffset; // 0x2704
    FVector ViewTargetOffset; // 0x2710
    char pad_271c[0x24];
    TArray<AEmitterCameraLensEffectBase*> CameraLensEffects; // 0x2740
    UCameraModifier_CameraShake* CachedCameraShakeMod; // 0x2750
    UCameraAnimInst* AnimInstPool[8]; // 0x2758
    TArray<FPostProcessSettings> PostProcessBlendCache; // 0x2798
    char pad_27a8[0x10];
    TArray<UCameraAnimInst*> ActiveAnims; // 0x27b8
    TArray<UCameraAnimInst*> FreeAnims; // 0x27c8
    ACameraActor* AnimCameraActor; // 0x27d8
    uint8_t bIsOrthographic : 1; // 0x27e0
    uint8_t bDefaultConstrainAspectRatio : 1; // 0x27e0
    uint8_t pad_bitfield_27e0_2 : 4;
    uint8_t bClientSimulatingViewTarget : 1; // 0x27e0
    uint8_t bUseClientSideCameraUpdates : 1; // 0x27e0
    uint8_t pad_bitfield_27e1_0 : 2;
    uint8_t bGameCameraCutThisFrame : 1; // 0x27e1
    uint8_t pad_bitfield_27e1_3 : 5;
    char pad_27e2[0x2];
    float ViewPitchMin; // 0x27e4
    float ViewPitchMax; // 0x27e8
    float ViewYawMin; // 0x27ec
    float ViewYawMax; // 0x27f0
    float ViewRollMin; // 0x27f4
    float ViewRollMax; // 0x27f8
    char pad_27fc[0x4];
    float ServerUpdateCameraTimeout; // 0x2800
    char pad_2804[0xc];
    static APlayerCameraManager* StaticClass();
    void SwapPendingViewTargetWhenUsingClientSideCameraUpdates();
    void StopCameraShake(UCameraShakeBase* ShakeInstance, bool bImmediately);
    void StopCameraFade();
    void StopCameraAnimInst(UCameraAnimInst* AnimInst, bool bImmediate);
    void StopAllInstancesOfCameraShakeFromSource(UClass* Shake, UCameraShakeSourceComponent* SourceComponent, bool bImmediately);
    void StopAllInstancesOfCameraShake(UClass* Shake, bool bImmediately);
    void StopAllInstancesOfCameraAnim(UCameraAnim* Anim, bool bImmediate);
    void StopAllCameraShakesFromSource(UCameraShakeSourceComponent* SourceComponent, bool bImmediately);
    void StopAllCameraShakes(bool bImmediately);
    void StopAllCameraAnims(bool bImmediate);
    UCameraShakeBase* StartCameraShakeFromSource(UClass* ShakeClass, UCameraShakeSourceComponent* SourceComponent, float Scale, ECameraShakePlaySpace PlaySpace, FRotator UserPlaySpaceRot);
    UCameraShakeBase* StartCameraShake(UClass* ShakeClass, float Scale, ECameraShakePlaySpace PlaySpace, FRotator UserPlaySpaceRot);
    void StartCameraFade(float FromAlpha, float ToAlpha, float Duration, FLinearColor Color, bool bShouldFadeAudio, bool bHoldWhenFinished);
    void SetManualCameraFade(float InFadeAmount, FLinearColor Color, bool bInFadeAudio);
    void SetGameCameraCutThisFrame();
    bool RemoveCameraModifier(UCameraModifier* ModifierToRemove);
    void RemoveCameraLensEffect(AEmitterCameraLensEffectBase* Emitter);
    UCameraAnimInst* PlayCameraAnim(UCameraAnim* Anim, float Rate, float Scale, float BlendInTime, float BlendOutTime, bool bLoop, bool bRandomStartTime, float Duration, ECameraShakePlaySpace PlaySpace, FRotator UserPlaySpaceRot);
    void PhotographyCameraModify(FVector NewCameraLocation, FVector PreviousCameraLocation, FVector OriginalCameraLocation, FVector& ResultCameraLocation);
    void OnPhotographySessionStart();
    void OnPhotographySessionEnd();
    void OnPhotographyMultiPartCaptureStart();
    void OnPhotographyMultiPartCaptureEnd();
    APlayerController* GetOwningPlayerController();
    float GetFOVAngle();
    FRotator GetCameraRotation();
    FVector GetCameraLocation();
    UCameraModifier* FindCameraModifierByClass(UClass* ModifierClass);
    void ClearCameraLensEffects();
    bool BlueprintUpdateCamera(AActor* CameraTarget, FVector& NewCameraLocation, FRotator& NewCameraRotation, float& NewCameraFOV);
    UCameraModifier* AddNewCameraModifier(UClass* ModifierClass);
    AEmitterCameraLensEffectBase* AddCameraLensEffect(UClass* LensEffectEmitterClass);
}; // Size: 0x2810
#pragma pack(pop)
