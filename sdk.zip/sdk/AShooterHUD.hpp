#pragma once
#include <cstdint>
#include "AHUD.hpp"
#include "FCanvasIcon.hpp"
class UTexture2D;
class UFont;
#pragma pack(push, 1)
class AShooterHUD : public AHUD {
public:
    char pad_310[0x38];
    FCanvasIcon HitNotifyIcon[8]; // 0x348
    FCanvasIcon KillsBg; // 0x408
    FCanvasIcon TimePlaceBg; // 0x420
    FCanvasIcon PrimaryWeapBg; // 0x438
    FCanvasIcon SecondaryWeapBg; // 0x450
    FCanvasIcon Crosshair[5]; // 0x468
    FCanvasIcon HitNotifyCrosshair; // 0x4e0
    FCanvasIcon DeathMessagesBg; // 0x4f8
    FCanvasIcon HealthBarBg; // 0x510
    FCanvasIcon HealthBar; // 0x528
    FCanvasIcon HealthIcon; // 0x540
    FCanvasIcon KillsIcon; // 0x558
    FCanvasIcon KilledIcon; // 0x570
    FCanvasIcon TimerIcon; // 0x588
    FCanvasIcon PlaceIcon; // 0x5a0
    char pad_5b8[0x90];
    UTexture2D* HitNotifyTexture; // 0x648
    UTexture2D* HUDMainTexture; // 0x650
    UTexture2D* HUDAssets02Texture; // 0x658
    UTexture2D* LowHealthOverlayTexture; // 0x660
    UFont* BigFont; // 0x668
    UFont* NormalFont; // 0x670
    char pad_678[0xc0];
    static AShooterHUD* StaticClass();
}; // Size: 0x738
#pragma pack(pop)
