#include "APostProcessVolume.hpp"
#include "AVolume.hpp"
#include "FPostProcessSettings.hpp"
APostProcessVolume* APostProcessVolume::StaticClass() {
    static auto res = find_uobject(1734970595616793215); // Class /Script/Engine.PostProcessVolume
    return (APostProcessVolume*)res;
}
void APostProcessVolume::AddOrUpdateBlendable() {}
