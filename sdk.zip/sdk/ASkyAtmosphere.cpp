#include "AInfo.hpp"
#include "ASkyAtmosphere.hpp"
#include "USkyAtmosphereComponent.hpp"
ASkyAtmosphere* ASkyAtmosphere::StaticClass() {
    static auto res = find_uobject(6985597706054706827); // Class /Script/Engine.SkyAtmosphere
    return (ASkyAtmosphere*)res;
}
