#pragma once
#include <cstdint>
#include "ASceneCapture2D.hpp"
class UVRNotificationsComponent;
class UOculusMR_PlaneMeshComponent;
class UMaterial;
class UTextureRenderTarget2D;
class UTexture2D;
class UMaterialInstanceDynamic;
class UOculusMR_Settings;
class UOculusMR_State;
#pragma pack(push, 1)
class AOculusMR_CastingCameraActor : public ASceneCapture2D {
public:
    UVRNotificationsComponent* VRNotificationComponent; // 0x238
    UTexture2D* CameraColorTexture; // 0x240
    UTexture2D* CameraDepthTexture; // 0x248
    UOculusMR_PlaneMeshComponent* PlaneMeshComponent; // 0x250
    UMaterial* ChromaKeyMaterial; // 0x258
    UMaterial* OpaqueColoredMaterial; // 0x260
    UMaterialInstanceDynamic* ChromaKeyMaterialInstance; // 0x268
    UMaterialInstanceDynamic* CameraFrameMaterialInstance; // 0x270
    UMaterialInstanceDynamic* BackdropMaterialInstance; // 0x278
    UTexture2D* DefaultTexture_White; // 0x280
    char pad_288[0x50];
    TArray<UTextureRenderTarget2D*> BackgroundRenderTargets; // 0x2d8
    ASceneCapture2D* ForegroundCaptureActor; // 0x2e8
    TArray<UTextureRenderTarget2D*> ForegroundRenderTargets; // 0x2f0
    TArray<double> PoseTimes; // 0x300
    UOculusMR_Settings* MRSettings; // 0x310
    UOculusMR_State* MRState; // 0x318
    static AOculusMR_CastingCameraActor* StaticClass();
}; // Size: 0x320
#pragma pack(pop)
