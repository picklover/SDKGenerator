#pragma once
#include <cstdint>
#include "APlayerController.hpp"
struct FMagicLeapSharedWorldLocalData;
struct FMagicLeapSharedWorldAlignmentTransforms;
#pragma pack(push, 1)
class AMagicLeapSharedWorldPlayerController : public APlayerController {
public:
    char pad_570[0x18];
    static AMagicLeapSharedWorldPlayerController* StaticClass();
    void ServerSetLocalWorldData(FMagicLeapSharedWorldLocalData& LocalWorldReplicationData);
    void ServerSetAlignmentTransforms(FMagicLeapSharedWorldAlignmentTransforms& InAlignmentTransforms);
    bool IsChosenOne();
    void ClientSetChosenOne(bool bChosenOne);
    void ClientMarkReadyForSendingLocalData();
    bool CanSendLocalDataToServer();
}; // Size: 0x588
#pragma pack(pop)
