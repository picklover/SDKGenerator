#pragma once
#include <cstdint>
#include "APlayerStart.hpp"
#pragma pack(push, 1)
class AShooterTeamStart : public APlayerStart {
public:
    int32_t SpawnTeam; // 0x250
    uint8_t bNotForPlayers : 1; // 0x254
    uint8_t bNotForBots : 1; // 0x254
    uint8_t pad_bitfield_254_2 : 6;
    char pad_255[0x3];
    static AShooterTeamStart* StaticClass();
}; // Size: 0x258
#pragma pack(pop)
