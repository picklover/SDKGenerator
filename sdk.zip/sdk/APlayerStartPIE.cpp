#include "APlayerStart.hpp"
#include "APlayerStartPIE.hpp"
APlayerStartPIE* APlayerStartPIE::StaticClass() {
    static auto res = find_uobject(10271052718122795269); // Class /Script/Engine.PlayerStartPIE
    return (APlayerStartPIE*)res;
}
