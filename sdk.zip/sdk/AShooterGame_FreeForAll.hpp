#pragma once
#include <cstdint>
#include "AShooterGameMode.hpp"
class AShooterPlayerState;
#pragma pack(push, 1)
class AShooterGame_FreeForAll : public AShooterGameMode {
public:
    AShooterPlayerState* WinnerPlayerState; // 0x368
    static AShooterGame_FreeForAll* StaticClass();
}; // Size: 0x370
#pragma pack(pop)
