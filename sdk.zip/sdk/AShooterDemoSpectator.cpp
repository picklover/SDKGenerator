#include "APlayerController.hpp"
#include "AShooterDemoSpectator.hpp"
AShooterDemoSpectator* AShooterDemoSpectator::StaticClass() {
    static auto res = find_uobject(232610416957816222); // Class /Script/ShooterGame.ShooterDemoSpectator
    return (AShooterDemoSpectator*)res;
}
