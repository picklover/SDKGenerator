#pragma once
#include <cstdint>
#include "AOnlineBeacon.hpp"
class AOnlineBeaconClient;
#pragma pack(push, 1)
class AOnlineBeaconHost : public AOnlineBeacon {
public:
    int32_t ListenPort; // 0x250
    char pad_254[0x4];
    TArray<AOnlineBeaconClient*> ClientActors; // 0x258
    char pad_268[0xa0];
    static AOnlineBeaconHost* StaticClass();
}; // Size: 0x308
#pragma pack(pop)
