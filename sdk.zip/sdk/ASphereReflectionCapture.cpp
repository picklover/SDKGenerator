#include "AReflectionCapture.hpp"
#include "ASphereReflectionCapture.hpp"
#include "UDrawSphereComponent.hpp"
ASphereReflectionCapture* ASphereReflectionCapture::StaticClass() {
    static auto res = find_uobject(10908200613512829044); // Class /Script/Engine.SphereReflectionCapture
    return (ASphereReflectionCapture*)res;
}
