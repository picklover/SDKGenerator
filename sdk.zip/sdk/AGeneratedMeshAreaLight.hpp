#pragma once
#include <cstdint>
#include "ASpotLight.hpp"
#pragma pack(push, 1)
class AGeneratedMeshAreaLight : public ASpotLight {
public:
    static AGeneratedMeshAreaLight* StaticClass();
}; // Size: 0x238
#pragma pack(pop)
