#include "AActor.hpp"
#include "AInfo.hpp"
AInfo* AInfo::StaticClass() {
    static auto res = find_uobject(3445108601820022470); // Class /Script/Engine.Info
    return (AInfo*)res;
}
