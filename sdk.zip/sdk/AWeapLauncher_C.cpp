#include "AShooterWeapon_Projectile.hpp"
#include "AWeapLauncher_C.hpp"
AWeapLauncher_C* AWeapLauncher_C::StaticClass() {
    static auto res = find_uobject(8995275906661187618); // BlueprintGeneratedClass /Game/Blueprints/Weapons/WeapLauncher.WeapLauncher_C
    return (AWeapLauncher_C*)res;
}
