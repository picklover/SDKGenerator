#include "AAROriginActor.hpp"
#include "ALuminAROrigin.hpp"
#include "UMRMeshComponent.hpp"
#include "UMaterialInterface.hpp"
ALuminAROrigin* ALuminAROrigin::StaticClass() {
    static auto res = find_uobject(8305727567633104198); // Class /Script/MagicLeapAR.LuminAROrigin
    return (ALuminAROrigin*)res;
}
