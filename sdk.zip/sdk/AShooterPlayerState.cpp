#include "APlayerState.hpp"
#include "AShooterPlayerState.hpp"
#include "UDamageType.hpp"
#include "UFunction.hpp"
AShooterPlayerState* AShooterPlayerState::StaticClass() {
    static auto res = find_uobject(10775360848790685592); // Class /Script/ShooterGame.ShooterPlayerState
    return (AShooterPlayerState*)res;
}
void AShooterPlayerState::OnRep_TeamColor() {
    static auto func = (UFunction*)(find_uobject(9485085656975919507)); // Function /Script/ShooterGame.ShooterPlayerState.OnRep_TeamColor
    struct Params_OnRep_TeamColor {
    }; // Size: 0x0
    Params_OnRep_TeamColor params{};
    ProcessEvent(func, &params);
}
void AShooterPlayerState::InformAboutKill(AShooterPlayerState* KillerPlayerState, UDamageType* KillerDamageType, AShooterPlayerState* KilledPlayerState) {
    static auto func = (UFunction*)(find_uobject(2889464449033129190)); // Function /Script/ShooterGame.ShooterPlayerState.InformAboutKill
    struct Params_InformAboutKill {
        AShooterPlayerState* KillerPlayerState; // 0x0
        UDamageType* KillerDamageType; // 0x8
        AShooterPlayerState* KilledPlayerState; // 0x10
    }; // Size: 0x18
    Params_InformAboutKill params{};
    params.KillerPlayerState = (AShooterPlayerState*)KillerPlayerState;
    params.KillerDamageType = (UDamageType*)KillerDamageType;
    params.KilledPlayerState = (AShooterPlayerState*)KilledPlayerState;
    ProcessEvent(func, &params);
}
void AShooterPlayerState::BroadcastDeath(AShooterPlayerState* KillerPlayerState, UDamageType* KillerDamageType, AShooterPlayerState* KilledPlayerState) {
    static auto func = (UFunction*)(find_uobject(17507446951366211107)); // Function /Script/ShooterGame.ShooterPlayerState.BroadcastDeath
    struct Params_BroadcastDeath {
        AShooterPlayerState* KillerPlayerState; // 0x0
        UDamageType* KillerDamageType; // 0x8
        AShooterPlayerState* KilledPlayerState; // 0x10
    }; // Size: 0x18
    Params_BroadcastDeath params{};
    params.KillerPlayerState = (AShooterPlayerState*)KillerPlayerState;
    params.KillerDamageType = (UDamageType*)KillerDamageType;
    params.KilledPlayerState = (AShooterPlayerState*)KilledPlayerState;
    ProcessEvent(func, &params);
}
