#include "AActor.hpp"
#include "APrecomputedVisibilityOverrideVolume.hpp"
#include "AVolume.hpp"
APrecomputedVisibilityOverrideVolume* APrecomputedVisibilityOverrideVolume::StaticClass() {
    static auto res = find_uobject(8064320826110392538); // Class /Script/Engine.PrecomputedVisibilityOverrideVolume
    return (APrecomputedVisibilityOverrideVolume*)res;
}
