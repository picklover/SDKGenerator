#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "EBrushType.hpp"
#include "FColor.hpp"
#include "FGeomSelection.hpp"
class UModel;
class UBrushComponent;
#pragma pack(push, 1)
class ABrush : public AActor {
public:
    EBrushType BrushType; // 0x220
    char pad_221[0x3];
    FColor BrushColor; // 0x224
    int32_t PolyFlags; // 0x228
    uint8_t bColored : 1; // 0x22c
    uint8_t bSolidWhenSelected : 1; // 0x22c
    uint8_t bPlaceableFromClassBrowser : 1; // 0x22c
    uint8_t bNotForClientOrServer : 1; // 0x22c
    uint8_t pad_bitfield_22c_4 : 4;
    char pad_22d[0x3];
    UModel* Brush; // 0x230
    UBrushComponent* BrushComponent; // 0x238
    uint8_t bInManipulation : 1; // 0x240
    uint8_t pad_bitfield_240_1 : 7;
    char pad_241[0x7];
    TArray<FGeomSelection> SavedSelections; // 0x248
    static ABrush* StaticClass();
}; // Size: 0x258
#pragma pack(pop)
