#include "AProjRocket_Explosion_C.hpp"
#include "AShooterExplosionEffect.hpp"
AProjRocket_Explosion_C* AProjRocket_Explosion_C::StaticClass() {
    static auto res = find_uobject(2044075558659798938); // BlueprintGeneratedClass /Game/Blueprints/Weapons/ProjRocket_Explosion.ProjRocket_Explosion_C
    return (AProjRocket_Explosion_C*)res;
}
