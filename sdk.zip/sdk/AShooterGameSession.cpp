#include "AGameSession.hpp"
#include "AShooterGameSession.hpp"
AShooterGameSession* AShooterGameSession::StaticClass() {
    static auto res = find_uobject(9741229855756413344); // Class /Script/ShooterGame.ShooterGameSession
    return (AShooterGameSession*)res;
}
