#pragma once
#include <cstdint>
#include "AGameState.hpp"
#include "FMagicLeapSharedWorldAlignmentTransforms.hpp"
#include "FMagicLeapSharedWorldSharedData.hpp"
#include "FTransform.hpp"
#pragma pack(push, 1)
class AMagicLeapSharedWorldGameState : public AGameState {
public:
    FMagicLeapSharedWorldSharedData SharedWorldData; // 0x290
    FMagicLeapSharedWorldAlignmentTransforms AlignmentTransforms; // 0x2a0
    char pad_2b0[0x20];
    static AMagicLeapSharedWorldGameState* StaticClass();
    void OnReplicate_SharedWorldData();
    void OnReplicate_AlignmentTransforms();
    void MagicLeapSharedWorldEvent__DelegateSignature();
    FTransform CalculateXRCameraRootTransform();
}; // Size: 0x2d0
#pragma pack(pop)
