#include "AActor.hpp"
#include "ANavigationData.hpp"
#include "ERuntimeGenerationType.hpp"
#include "FNavDataConfig.hpp"
#include "FSupportedAreaData.hpp"
#include "UPrimitiveComponent.hpp"
ANavigationData* ANavigationData::StaticClass() {
    static auto res = find_uobject(17132304185820625967); // Class /Script/NavigationSystem.NavigationData
    return (ANavigationData*)res;
}
