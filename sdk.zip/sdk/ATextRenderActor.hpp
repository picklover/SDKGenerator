#pragma once
#include <cstdint>
#include "AActor.hpp"
class UTextRenderComponent;
#pragma pack(push, 1)
class ATextRenderActor : public AActor {
public:
    UTextRenderComponent* TextRender; // 0x220
    static ATextRenderActor* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
