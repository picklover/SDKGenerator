#pragma once
#include <cstdint>
#include "AReflectionCapture.hpp"
class UDrawSphereComponent;
#pragma pack(push, 1)
class ASphereReflectionCapture : public AReflectionCapture {
public:
    UDrawSphereComponent* DrawCaptureRadius; // 0x228
    static ASphereReflectionCapture* StaticClass();
}; // Size: 0x230
#pragma pack(pop)
