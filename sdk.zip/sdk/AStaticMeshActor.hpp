#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "EComponentMobility\Type.hpp"
#include "ENavDataGatheringMode.hpp"
class UStaticMeshComponent;
#pragma pack(push, 1)
class AStaticMeshActor : public AActor {
public:
    UStaticMeshComponent* StaticMeshComponent; // 0x220
    bool bStaticMeshReplicateMovement; // 0x228
    ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x229
    char pad_22a[0x6];
    static AStaticMeshActor* StaticClass();
    void SetMobility(EComponentMobility::Type InMobility);
}; // Size: 0x230
#pragma pack(pop)
