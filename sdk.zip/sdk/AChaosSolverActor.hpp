#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "EClusterConnectionTypeEnum.hpp"
#include "FChaosDebugSubstepControl.hpp"
#include "FChaosSolverConfiguration.hpp"
#include "FSolverBreakingFilterSettings.hpp"
#include "FSolverCollisionFilterSettings.hpp"
#include "FSolverTrailingFilterSettings.hpp"
class UBillboardComponent;
class UChaosGameplayEventDispatcher;
#pragma pack(push, 1)
class AChaosSolverActor : public AActor {
public:
    FChaosSolverConfiguration Properties; // 0x220
    float TimeStepMultiplier; // 0x288
    int32_t CollisionIterations; // 0x28c
    int32_t PushOutIterations; // 0x290
    int32_t PushOutPairIterations; // 0x294
    float ClusterConnectionFactor; // 0x298
    EClusterConnectionTypeEnum ClusterUnionConnectionType; // 0x29c
    bool DoGenerateCollisionData; // 0x29d
    char pad_29e[0x2];
    FSolverCollisionFilterSettings CollisionFilterSettings; // 0x2a0
    bool DoGenerateBreakingData; // 0x2b0
    char pad_2b1[0x3];
    FSolverBreakingFilterSettings BreakingFilterSettings; // 0x2b4
    bool DoGenerateTrailingData; // 0x2c4
    char pad_2c5[0x3];
    FSolverTrailingFilterSettings TrailingFilterSettings; // 0x2c8
    float MassScale; // 0x2d8
    bool bGenerateContactGraph; // 0x2dc
    bool bHasFloor; // 0x2dd
    char pad_2de[0x2];
    float FloorHeight; // 0x2e0
    FChaosDebugSubstepControl ChaosDebugSubstepControl; // 0x2e4
    char pad_2e7[0x1];
    UBillboardComponent* SpriteComponent; // 0x2e8
    char pad_2f0[0x18];
    UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent; // 0x308
    char pad_310[0x8];
    static AChaosSolverActor* StaticClass();
    void SetSolverActive(bool bActive);
    void SetAsCurrentWorldSolver();
}; // Size: 0x318
#pragma pack(pop)
