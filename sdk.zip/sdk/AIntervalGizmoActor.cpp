#include "AGizmoActor.hpp"
#include "AIntervalGizmoActor.hpp"
#include "UGizmoLineHandleComponent.hpp"
AIntervalGizmoActor* AIntervalGizmoActor::StaticClass() {
    static auto res = find_uobject(1718601952795117417); // Class /Script/InteractiveToolsFramework.IntervalGizmoActor
    return (AIntervalGizmoActor*)res;
}
