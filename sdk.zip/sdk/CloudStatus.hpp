#pragma once
#include <cstdint>
#pragma pack(push, 1)
enum class CloudStatus {
    CloudStatus_NotDone = 0,
    CloudStatus_Done = 1,
    CloudStatus_MAX = 2,
};
#pragma pack(pop)
