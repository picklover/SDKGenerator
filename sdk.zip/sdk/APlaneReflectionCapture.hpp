#pragma once
#include <cstdint>
#include "AReflectionCapture.hpp"
#pragma pack(push, 1)
class APlaneReflectionCapture : public AReflectionCapture {
public:
    static APlaneReflectionCapture* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
