#include "AActor.hpp"
#include "AReflectionCapture.hpp"
#include "UReflectionCaptureComponent.hpp"
AReflectionCapture* AReflectionCapture::StaticClass() {
    static auto res = find_uobject(17553767895604757399); // Class /Script/Engine.ReflectionCapture
    return (AReflectionCapture*)res;
}
