#pragma once
#include <cstdint>
#include "AActor.hpp"
class UTextureRenderTarget2D;
class UObject;
struct FTransform;
struct FIntPoint;
#pragma pack(push, 1)
class ALandscapeBlueprintBrushBase : public AActor {
public:
    static ALandscapeBlueprintBrushBase* StaticClass();
    void RequestLandscapeUpdate();
    UTextureRenderTarget2D* Render(bool InIsHeightmap, UTextureRenderTarget2D* InCombinedResult, FName& InWeightmapLayerName);
    void Initialize(FTransform& InLandscapeTransform, FIntPoint& InLandscapeSize, FIntPoint& InLandscapeRenderTargetSize);
    void GetBlueprintRenderDependencies(TArray<UObject*>& OutStreamableAssets);
}; // Size: 0x220
#pragma pack(pop)
