#include "AActor.hpp"
#include "ALandscapeMeshProxyActor.hpp"
#include "ULandscapeMeshProxyComponent.hpp"
ALandscapeMeshProxyActor* ALandscapeMeshProxyActor::StaticClass() {
    static auto res = find_uobject(9024585200950454804); // Class /Script/Landscape.LandscapeMeshProxyActor
    return (ALandscapeMeshProxyActor*)res;
}
