#pragma once
#include <cstdint>
#include "APawn.hpp"
class USkeletalMeshComponent;
class UWheeledVehicleMovementComponent;
#pragma pack(push, 1)
class AWheeledVehicle : public APawn {
public:
    USkeletalMeshComponent* Mesh; // 0x280
    UWheeledVehicleMovementComponent* VehicleMovement; // 0x288
    static AWheeledVehicle* StaticClass();
}; // Size: 0x290
#pragma pack(pop)
