#pragma once
#include <cstdint>
#include "AActor.hpp"
class UDatasmithScene;
#pragma pack(push, 1)
class ADatasmithSceneActor : public AActor {
public:
    UDatasmithScene* Scene; // 0x220
    char pad_228[0x50];
    static ADatasmithSceneActor* StaticClass();
}; // Size: 0x278
#pragma pack(pop)
