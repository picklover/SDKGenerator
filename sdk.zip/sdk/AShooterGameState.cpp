#include "AGameState.hpp"
#include "AShooterGameState.hpp"
AShooterGameState* AShooterGameState::StaticClass() {
    static auto res = find_uobject(17328142591174543833); // Class /Script/ShooterGame.ShooterGameState
    return (AShooterGameState*)res;
}
