#include "AGameModeBase.hpp"
#include "AShooterGame_Menu.hpp"
AShooterGame_Menu* AShooterGame_Menu::StaticClass() {
    static auto res = find_uobject(7983297388804222550); // Class /Script/ShooterGame.ShooterGame_Menu
    return (AShooterGame_Menu*)res;
}
