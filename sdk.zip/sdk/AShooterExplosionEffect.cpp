#include "AActor.hpp"
#include "AShooterExplosionEffect.hpp"
#include "FDecalData.hpp"
#include "FHitResult.hpp"
#include "UParticleSystem.hpp"
#include "UPointLightComponent.hpp"
#include "USoundCue.hpp"
AShooterExplosionEffect* AShooterExplosionEffect::StaticClass() {
    static auto res = find_uobject(3155765386158116504); // Class /Script/ShooterGame.ShooterExplosionEffect
    return (AShooterExplosionEffect*)res;
}
