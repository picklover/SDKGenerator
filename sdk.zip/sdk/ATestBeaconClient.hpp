#pragma once
#include <cstdint>
#include "AOnlineBeaconClient.hpp"
#pragma pack(push, 1)
class ATestBeaconClient : public AOnlineBeaconClient {
public:
    static ATestBeaconClient* StaticClass();
    void ServerPong();
    void ClientPing();
}; // Size: 0x2b0
#pragma pack(pop)
