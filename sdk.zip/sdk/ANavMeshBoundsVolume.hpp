#pragma once
#include <cstdint>
#include "AVolume.hpp"
#include "FNavAgentSelector.hpp"
#pragma pack(push, 1)
class ANavMeshBoundsVolume : public AVolume {
public:
    FNavAgentSelector SupportedAgents; // 0x258
    char pad_25c[0x4];
    static ANavMeshBoundsVolume* StaticClass();
}; // Size: 0x260
#pragma pack(pop)
