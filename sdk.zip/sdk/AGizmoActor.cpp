#include "AGizmoActor.hpp"
#include "AInternalToolFrameworkActor.hpp"
AGizmoActor* AGizmoActor::StaticClass() {
    static auto res = find_uobject(3431446534508131136); // Class /Script/InteractiveToolsFramework.GizmoActor
    return (AGizmoActor*)res;
}
