#pragma once
#include <cstdint>
#include "ATriggerBase.hpp"
#pragma pack(push, 1)
class ATriggerSphere : public ATriggerBase {
public:
    static ATriggerSphere* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
