#pragma once
#include <cstdint>
#include "AActor.hpp"
class UNetDriver;
#pragma pack(push, 1)
class AOnlineBeacon : public AActor {
public:
    char pad_220[0x8];
    float BeaconConnectionInitialTimeout; // 0x228
    float BeaconConnectionTimeout; // 0x22c
    UNetDriver* NetDriver; // 0x230
    char pad_238[0x18];
    static AOnlineBeacon* StaticClass();
}; // Size: 0x250
#pragma pack(pop)
