#include "AActor.hpp"
#include "ARigidBodyBase.hpp"
ARigidBodyBase* ARigidBodyBase::StaticClass() {
    static auto res = find_uobject(14182752745609011896); // Class /Script/Engine.RigidBodyBase
    return (ARigidBodyBase*)res;
}
