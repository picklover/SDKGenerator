#include "AActor.hpp"
#include "ACableActor.hpp"
#include "UCableComponent.hpp"
ACableActor* ACableActor::StaticClass() {
    static auto res = find_uobject(15759459734057381606); // Class /Script/CableComponent.CableActor
    return (ACableActor*)res;
}
