#pragma once
#include <cstdint>
#include "ATriggerBase.hpp"
#pragma pack(push, 1)
class ATriggerCapsule : public ATriggerBase {
public:
    static ATriggerCapsule* StaticClass();
}; // Size: 0x228
#pragma pack(pop)
