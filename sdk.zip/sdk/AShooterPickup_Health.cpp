#include "AShooterPickup.hpp"
#include "AShooterPickup_Health.hpp"
AShooterPickup_Health* AShooterPickup_Health::StaticClass() {
    static auto res = find_uobject(15782316997767772441); // Class /Script/ShooterGame.ShooterPickup_Health
    return (AShooterPickup_Health*)res;
}
