#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "EBlendMode.hpp"
#include "FColor.hpp"
#include "FDebugTextInfo.hpp"
#include "FLinearColor.hpp"
#include "FVector.hpp"
#include "FVector2D.hpp"
class APlayerController;
class APawn;
class UMaterialInterface;
class UCanvas;
class UTexture;
class UClass;
class UFont;
#pragma pack(push, 1)
class AHUD : public AActor {
public:
    APlayerController* PlayerOwner; // 0x220
    uint8_t bLostFocusPaused : 1; // 0x228
    uint8_t bShowHUD : 1; // 0x228
    uint8_t bShowDebugInfo : 1; // 0x228
    uint8_t pad_bitfield_228_3 : 5;
    char pad_229[0x3];
    int32_t CurrentTargetIndex; // 0x22c
    uint8_t bShowHitBoxDebugInfo : 1; // 0x230
    uint8_t bShowOverlays : 1; // 0x230
    uint8_t bEnableDebugTextShadow : 1; // 0x230
    uint8_t pad_bitfield_230_3 : 5;
    char pad_231[0x7];
    TArray<AActor*> PostRenderedActors; // 0x238
    char pad_248[0x8];
    TArray<FName> DebugDisplay; // 0x250
    TArray<FName> ToggledDebugCategories; // 0x260
    UCanvas* Canvas; // 0x270
    UCanvas* DebugCanvas; // 0x278
    TArray<FDebugTextInfo> DebugTextList; // 0x280
    UClass* ShowDebugTargetDesiredClass; // 0x290
    AActor* ShowDebugTargetActor; // 0x298
    char pad_2a0[0x70];
    static AHUD* StaticClass();
    void ShowHUD();
    void ShowDebugToggleSubCategory(FName Category);
    void ShowDebugForReticleTargetToggle(UClass* DesiredClass);
    void ShowDebug(FName DebugType);
    void RemoveDebugText(AActor* SrcActor, bool bLeaveDurationText);
    void RemoveAllDebugStrings();
    void ReceiveHitBoxRelease(FName BoxName);
    void ReceiveHitBoxEndCursorOver(FName BoxName);
    void ReceiveHitBoxClick(FName BoxName);
    void ReceiveHitBoxBeginCursorOver(FName BoxName);
    void ReceiveDrawHUD(int32_t SizeX, int32_t SizeY);
    FVector Project(FVector Location);
    void PreviousDebugTarget();
    void NextDebugTarget();
    void GetTextSize(FString Text, float& OutWidth, float& OutHeight, UFont* Font, float Scale);
    APlayerController* GetOwningPlayerController();
    APawn* GetOwningPawn();
    void GetActorsInSelectionRectangle(UClass* ClassFilter, FVector2D& FirstPoint, FVector2D& SecondPoint, TArray<AActor*>& OutActors, bool bIncludeNonCollidingComponents, bool bActorMustBeFullyEnclosed);
    void DrawTextureSimple(UTexture* Texture, float ScreenX, float ScreenY, float Scale, bool bScalePosition);
    void DrawTexture(UTexture* Texture, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float TextureU, float TextureV, float TextureUWidth, float TextureVHeight, FLinearColor TintColor, EBlendMode BlendMode, float Scale, bool bScalePosition, float Rotation, FVector2D RotPivot);
    void DrawText(FString Text, FLinearColor TextColor, float ScreenX, float ScreenY, UFont* Font, float Scale, bool bScalePosition);
    void DrawRect(FLinearColor RectColor, float ScreenX, float ScreenY, float ScreenW, float ScreenH);
    void DrawMaterialTriangle(UMaterialInterface* Material, FVector2D V0_Pos, FVector2D V1_Pos, FVector2D V2_Pos, FVector2D V0_UV, FVector2D V1_UV, FVector2D V2_UV, FLinearColor V0_Color, FLinearColor V1_Color, FLinearColor V2_Color);
    void DrawMaterialSimple(UMaterialInterface* Material, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float Scale, bool bScalePosition);
    void DrawMaterial(UMaterialInterface* Material, float ScreenX, float ScreenY, float ScreenW, float ScreenH, float MaterialU, float MaterialV, float MaterialUWidth, float MaterialVHeight, float Scale, bool bScalePosition, float Rotation, FVector2D RotPivot);
    void DrawLine(float StartScreenX, float StartScreenY, float EndScreenX, float EndScreenY, FLinearColor LineColor, float LineThickness);
    void Deproject(float ScreenX, float ScreenY, FVector& WorldPosition, FVector& WorldDirection);
    void AddHitBox(FVector2D Position, FVector2D Size, FName InName, bool bConsumesInput, int32_t Priority);
    void AddDebugText(FString DebugText, AActor* SrcActor, float Duration, FVector Offset, FVector DesiredOffset, FColor TextColor, bool bSkipOverwriteCheck, bool bAbsoluteLocation, bool bKeepAttachedToActor, UFont* InFont, float FontScale, bool bDrawShadow);
}; // Size: 0x310
#pragma pack(pop)
