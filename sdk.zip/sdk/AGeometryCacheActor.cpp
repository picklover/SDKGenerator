#include "AActor.hpp"
#include "AGeometryCacheActor.hpp"
#include "UFunction.hpp"
#include "UGeometryCacheComponent.hpp"
AGeometryCacheActor* AGeometryCacheActor::StaticClass() {
    static auto res = find_uobject(13593139768457771477); // Class /Script/GeometryCache.GeometryCacheActor
    return (AGeometryCacheActor*)res;
}
UGeometryCacheComponent* AGeometryCacheActor::GetGeometryCacheComponent() {
    static auto func = (UFunction*)(find_uobject(8225313153620771132)); // Function /Script/GeometryCache.GeometryCacheActor.GetGeometryCacheComponent
    struct Params_GetGeometryCacheComponent {
        UGeometryCacheComponent* ReturnValue; // 0x0
    }; // Size: 0x8
    Params_GetGeometryCacheComponent params{};
    ProcessEvent(func, &params);
    return (UGeometryCacheComponent*)params.ReturnValue;
}
