#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "ENavSystemOverridePolicy.hpp"
class UNavigationSystemConfig;
#pragma pack(push, 1)
class ANavSystemConfigOverride : public AActor {
public:
    UNavigationSystemConfig* NavigationSystemConfig; // 0x220
    ENavSystemOverridePolicy OverridePolicy; // 0x228
    uint8_t bLoadOnClient : 1; // 0x229
    uint8_t pad_bitfield_229_1 : 7;
    char pad_22a[0x6];
    static ANavSystemConfigOverride* StaticClass();
}; // Size: 0x230
#pragma pack(pop)
