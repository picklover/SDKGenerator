#pragma once
#include <cstdint>
#include "AActor.hpp"
class UCapsuleComponent;
class UBillboardComponent;
#pragma pack(push, 1)
class ANavigationObjectBase : public AActor {
public:
    char pad_220[0x8];
    UCapsuleComponent* CapsuleComponent; // 0x228
    UBillboardComponent* GoodSprite; // 0x230
    UBillboardComponent* BadSprite; // 0x238
    uint8_t bIsPIEPlayerStart : 1; // 0x240
    uint8_t pad_bitfield_240_1 : 7;
    char pad_241[0x7];
    static ANavigationObjectBase* StaticClass();
}; // Size: 0x248
#pragma pack(pop)
