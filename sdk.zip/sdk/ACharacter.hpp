#pragma once
#include <cstdint>
#include "APawn.hpp"
#include "EMovementMode.hpp"
#include "FBasedMovementInfo.hpp"
#include "FQuat.hpp"
#include "FRepRootMotionMontage.hpp"
#include "FRootMotionMovementParams.hpp"
#include "FRootMotionSourceGroup.hpp"
#include "FRotator.hpp"
#include "FSimulatedRootMotionReplicatedMove.hpp"
#include "FVector.hpp"
#include "FVector_NetQuantize10.hpp"
#include "FVector_NetQuantize100.hpp"
#include "FVector_NetQuantizeNormal.hpp"
class USkeletalMeshComponent;
class UCharacterMovementComponent;
class UCapsuleComponent;
struct FCharacterServerMovePackedBits;
class UPrimitiveComponent;
class UAnimMontage;
struct FHitResult;
struct FCharacterMoveResponsePackedBits;
#pragma pack(push, 1)
class ACharacter : public APawn {
public:
    USkeletalMeshComponent* Mesh; // 0x280
    UCharacterMovementComponent* CharacterMovement; // 0x288
    UCapsuleComponent* CapsuleComponent; // 0x290
    FBasedMovementInfo BasedMovement; // 0x298
    FBasedMovementInfo ReplicatedBasedMovement; // 0x2c8
    float AnimRootMotionTranslationScale; // 0x2f8
    FVector BaseTranslationOffset; // 0x2fc
    char pad_308[0x8];
    FQuat BaseRotationOffset; // 0x310
    float ReplicatedServerLastTransformUpdateTimeStamp; // 0x320
    float ReplayLastTransformUpdateTimeStamp; // 0x324
    uint8_t ReplicatedMovementMode; // 0x328
    bool bInBaseReplication; // 0x329
    char pad_32a[0x2];
    float CrouchedEyeHeight; // 0x32c
    uint8_t bIsCrouched : 1; // 0x330
    uint8_t bProxyIsJumpForceApplied : 1; // 0x330
    uint8_t bPressedJump : 1; // 0x330
    uint8_t bClientUpdating : 1; // 0x330
    uint8_t bClientWasFalling : 1; // 0x330
    uint8_t bClientResimulateRootMotion : 1; // 0x330
    uint8_t bClientResimulateRootMotionSources : 1; // 0x330
    uint8_t bSimGravityDisabled : 1; // 0x330
    uint8_t bClientCheckEncroachmentOnNetUpdate : 1; // 0x331
    uint8_t bServerMoveIgnoreRootMotion : 1; // 0x331
    uint8_t bWasJumping : 1; // 0x331
    uint8_t pad_bitfield_331_3 : 5;
    char pad_332[0x2];
    float JumpKeyHoldTime; // 0x334
    float JumpForceTimeRemaining; // 0x338
    float ProxyJumpForceStartedTime; // 0x33c
    float JumpMaxHoldTime; // 0x340
    int32_t JumpMaxCount; // 0x344
    int32_t JumpCurrentCount; // 0x348
    int32_t JumpCurrentCountPreJump; // 0x34c
    char pad_350[0x48];
    FRootMotionSourceGroup SavedRootMotion; // 0x398
    FRootMotionMovementParams ClientRootMotionParams; // 0x3d0
    TArray<FSimulatedRootMotionReplicatedMove> RootMotionRepMoves; // 0x410
    FRepRootMotionMontage RepRootMotion; // 0x420
    char pad_4b8[0x8];
    static ACharacter* StaticClass();
    void UnCrouch(bool bClientSimulation);
    void StopJumping();
    void StopAnimMontage(UAnimMontage* AnimMontage);
    void ServerMovePacked(FCharacterServerMovePackedBits& PackedBits);
    void ServerMoveOld(float OldTimeStamp, FVector_NetQuantize10 OldAccel, uint8_t OldMoveFlags);
    void ServerMoveNoBase(float Timestamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8_t CompressedMoveFlags, uint8_t ClientRoll, uint32_t View, uint8_t ClientMovementMode);
    void ServerMoveDualNoBase(float TimeStamp0, FVector_NetQuantize10 InAccel0, uint8_t PendingFlags, uint32_t View0, float Timestamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8_t NewFlags, uint8_t ClientRoll, uint32_t View, uint8_t ClientMovementMode);
    void ServerMoveDualHybridRootMotion(float TimeStamp0, FVector_NetQuantize10 InAccel0, uint8_t PendingFlags, uint32_t View0, float Timestamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8_t NewFlags, uint8_t ClientRoll, uint32_t View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8_t ClientMovementMode);
    void ServerMoveDual(float TimeStamp0, FVector_NetQuantize10 InAccel0, uint8_t PendingFlags, uint32_t View0, float Timestamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8_t NewFlags, uint8_t ClientRoll, uint32_t View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8_t ClientMovementMode);
    void ServerMove(float Timestamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8_t CompressedMoveFlags, uint8_t ClientRoll, uint32_t View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8_t ClientMovementMode);
    void RootMotionDebugClientPrintOnScreen(FString inString);
    float PlayAnimMontage(UAnimMontage* AnimMontage, float InPlayRate, FName StartSectionName);
    void OnWalkingOffLedge(FVector& PreviousFloorImpactNormal, FVector& PreviousFloorContactNormal, FVector& PreviousLocation, float TimeDelta);
    void OnRep_RootMotion();
    void OnRep_ReplicatedBasedMovement();
    void OnRep_ReplayLastTransformUpdateTimeStamp();
    void OnRep_IsCrouched();
    void OnLaunched(FVector LaunchVelocity, bool bXYOverride, bool bZOverride);
    void OnLanded(FHitResult& Hit);
    void OnJumped();
    void LaunchCharacter(FVector LaunchVelocity, bool bXYOverride, bool bZOverride);
    void K2_UpdateCustomMovement(float DeltaTime);
    void K2_OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
    void K2_OnMovementModeChanged(EMovementMode PrevMovementMode, EMovementMode NewMovementMode, uint8_t PrevCustomMode, uint8_t NewCustomMode);
    void K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust);
    void Jump();
    bool IsPlayingRootMotion();
    bool IsPlayingNetworkedRootMotionMontage();
    bool IsJumpProvidingForce();
    bool HasAnyRootMotion();
    UAnimMontage* GetCurrentMontage();
    FVector GetBaseTranslationOffset();
    FRotator GetBaseRotationOffsetRotator();
    float GetAnimRootMotionTranslationScale();
    void Crouch(bool bClientSimulation);
    void ClientVeryShortAdjustPosition(float Timestamp, FVector NewLoc, UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8_t ServerMovementMode);
    void ClientMoveResponsePacked(FCharacterMoveResponsePackedBits& PackedBits);
    void ClientCheatWalk();
    void ClientCheatGhost();
    void ClientCheatFly();
    void ClientAdjustRootMotionSourcePosition(float Timestamp, FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, FVector ServerLoc, FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, uint8_t ServerMovementMode);
    void ClientAdjustRootMotionPosition(float Timestamp, float ServerMontageTrackPosition, FVector ServerLoc, FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, uint8_t ServerMovementMode);
    void ClientAdjustPosition(float Timestamp, FVector NewLoc, FVector NewVel, UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8_t ServerMovementMode);
    void ClientAckGoodMove(float Timestamp);
    bool CanJumpInternal();
    bool CanJump();
    bool CanCrouch();
    void CacheInitialMeshOffset(FVector MeshRelativeLocation, FRotator MeshRelativeRotation);
}; // Size: 0x4c0
#pragma pack(pop)
