#pragma once
#include <cstdint>
#include "AGameModeBase.hpp"
#pragma pack(push, 1)
class AShooterGame_Menu : public AGameModeBase {
public:
    static AShooterGame_Menu* StaticClass();
}; // Size: 0x2c0
#pragma pack(pop)
