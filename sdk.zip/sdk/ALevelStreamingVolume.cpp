#include "ALevelStreamingVolume.hpp"
#include "AVolume.hpp"
#include "EStreamingVolumeUsage.hpp"
ALevelStreamingVolume* ALevelStreamingVolume::StaticClass() {
    static auto res = find_uobject(17964841025351524222); // Class /Script/Engine.LevelStreamingVolume
    return (ALevelStreamingVolume*)res;
}
