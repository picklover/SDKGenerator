#pragma once
#include <cstdint>
#include "AShooterWeapon_Projectile.hpp"
#pragma pack(push, 1)
class AWeapLauncher_C : public AShooterWeapon_Projectile {
public:
    static AWeapLauncher_C* StaticClass();
}; // Size: 0x4c0
#pragma pack(pop)
