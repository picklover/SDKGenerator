#include "AActor.hpp"
#include "AMagicLeapARPinInfoActorBase.hpp"
#include "FGuid.hpp"
#include "UFunction.hpp"
AMagicLeapARPinInfoActorBase* AMagicLeapARPinInfoActorBase::StaticClass() {
    static auto res = find_uobject(3171869339738809954); // Class /Script/MagicLeapARPin.MagicLeapARPinInfoActorBase
    return (AMagicLeapARPinInfoActorBase*)res;
}
void AMagicLeapARPinInfoActorBase::OnUpdateARPinState() {
    static auto func = (UFunction*)(find_uobject(9443214375920902445)); // Function /Script/MagicLeapARPin.MagicLeapARPinInfoActorBase.OnUpdateARPinState
    struct Params_OnUpdateARPinState {
    }; // Size: 0x0
    Params_OnUpdateARPinState params{};
    ProcessEvent(func, &params);
}
