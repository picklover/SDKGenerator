#pragma once
#include <cstdint>
#include "AActor.hpp"
class USceneComponent;
class USplineComponent;
#pragma pack(push, 1)
class ACameraRig_Rail : public AActor {
public:
    float CurrentPositionOnRail; // 0x220
    bool bLockOrientationToRail; // 0x224
    char pad_225[0x3];
    USceneComponent* TransformComponent; // 0x228
    USplineComponent* RailSplineComponent; // 0x230
    USceneComponent* RailCameraMount; // 0x238
    static ACameraRig_Rail* StaticClass();
    USplineComponent* GetRailSplineComponent();
}; // Size: 0x240
#pragma pack(pop)
