#include "AActor.hpp"
#include "AOnlineBeacon.hpp"
#include "UNetDriver.hpp"
AOnlineBeacon* AOnlineBeacon::StaticClass() {
    static auto res = find_uobject(1765475126216754862); // Class /Script/OnlineSubsystemUtils.OnlineBeacon
    return (AOnlineBeacon*)res;
}
