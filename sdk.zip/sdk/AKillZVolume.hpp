#pragma once
#include <cstdint>
#include "APhysicsVolume.hpp"
#pragma pack(push, 1)
class AKillZVolume : public APhysicsVolume {
public:
    static AKillZVolume* StaticClass();
}; // Size: 0x268
#pragma pack(pop)
