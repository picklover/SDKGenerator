#include "APawn.hpp"
#include "AWheeledVehicle.hpp"
#include "USkeletalMeshComponent.hpp"
#include "UWheeledVehicleMovementComponent.hpp"
AWheeledVehicle* AWheeledVehicle::StaticClass() {
    static auto res = find_uobject(9066200406040360141); // Class /Script/PhysXVehicles.WheeledVehicle
    return (AWheeledVehicle*)res;
}
