#include "AARSkyLight.hpp"
#include "ASkyLight.hpp"
#include "UAREnvironmentCaptureProbe.hpp"
#include "UFunction.hpp"
AARSkyLight* AARSkyLight::StaticClass() {
    static auto res = find_uobject(7520789856072412274); // Class /Script/AugmentedReality.ARSkyLight
    return (AARSkyLight*)res;
}
void AARSkyLight::SetEnvironmentCaptureProbe(UAREnvironmentCaptureProbe* InCaptureProbe) {
    static auto func = (UFunction*)(find_uobject(2182426135927614539)); // Function /Script/AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe
    struct Params_SetEnvironmentCaptureProbe {
        UAREnvironmentCaptureProbe* InCaptureProbe; // 0x0
    }; // Size: 0x8
    Params_SetEnvironmentCaptureProbe params{};
    params.InCaptureProbe = (UAREnvironmentCaptureProbe*)InCaptureProbe;
    ProcessEvent(func, &params);
}
