#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "FGuid.hpp"
#pragma pack(push, 1)
class AMagicLeapARPinInfoActorBase : public AActor {
public:
    FGuid PinId; // 0x220
    bool bVisibilityOverride; // 0x230
    char pad_231[0x7];
    static AMagicLeapARPinInfoActorBase* StaticClass();
    void OnUpdateARPinState();
}; // Size: 0x238
#pragma pack(pop)
