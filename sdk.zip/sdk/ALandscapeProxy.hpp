#pragma once
#include <cstdint>
#include "AActor.hpp"
#include "ELandscapeLODFalloff\Type.hpp"
#include "ENavDataGatheringMode.hpp"
#include "ERendererStencilMask.hpp"
#include "ERuntimeVirtualTextureMainPassType.hpp"
#include "FBodyInstance.hpp"
#include "FGuid.hpp"
#include "FIntPoint.hpp"
#include "FLandscapeProxyMaterialOverride.hpp"
#include "FLightingChannels.hpp"
#include "FLightmassPrimitiveSettings.hpp"
#include "FLinearColor.hpp"
class UPhysicalMaterial;
class ULandscapeSplinesComponent;
class UTexture;
class UMaterialInterface;
class ULandscapeHeightfieldCollisionComponent;
class ULandscapeComponent;
class URuntimeVirtualTexture;
class UHierarchicalInstancedStaticMeshComponent;
class UTextureRenderTarget2D;
class USplineComponent;
class ULandscapeLayerInfoObject;
#pragma pack(push, 1)
class ALandscapeProxy : public AActor {
public:
    ULandscapeSplinesComponent* SplineComponent; // 0x220
    FGuid LandscapeGuid; // 0x228
    FIntPoint LandscapeSectionOffset; // 0x238
    int32_t MaxLODLevel; // 0x240
    float LODDistanceFactor; // 0x244
    ELandscapeLODFalloff::Type LODFalloff; // 0x248
    char pad_249[0x3];
    float ComponentScreenSizeToUseSubSections; // 0x24c
    float LOD0ScreenSize; // 0x250
    float LOD0DistributionSetting; // 0x254
    float LODDistributionSetting; // 0x258
    float TessellationComponentScreenSize; // 0x25c
    bool UseTessellationComponentScreenSizeFalloff; // 0x260
    char pad_261[0x3];
    float TessellationComponentScreenSizeFalloff; // 0x264
    int32_t OccluderGeometryLOD; // 0x268
    int32_t StaticLightingLOD; // 0x26c
    UPhysicalMaterial* DefaultPhysMaterial; // 0x270
    float StreamingDistanceMultiplier; // 0x278
    char pad_27c[0x4];
    UMaterialInterface* LandscapeMaterial; // 0x280
    char pad_288[0x20];
    UMaterialInterface* LandscapeHoleMaterial; // 0x2a8
    TArray<FLandscapeProxyMaterialOverride> LandscapeMaterialsOverride; // 0x2b0
    bool bMeshHoles; // 0x2c0
    uint8_t MeshHolesMaxLod; // 0x2c1
    char pad_2c2[0x6];
    TArray<URuntimeVirtualTexture*> RuntimeVirtualTextures; // 0x2c8
    int32_t VirtualTextureNumLods; // 0x2d8
    int32_t VirtualTextureLodBias; // 0x2dc
    ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType; // 0x2e0
    char pad_2e1[0x3];
    float NegativeZBoundsExtension; // 0x2e4
    float PositiveZBoundsExtension; // 0x2e8
    char pad_2ec[0x4];
    TArray<ULandscapeComponent*> LandscapeComponents; // 0x2f0
    TArray<ULandscapeHeightfieldCollisionComponent*> CollisionComponents; // 0x300
    TArray<UHierarchicalInstancedStaticMeshComponent*> FoliageComponents; // 0x310
    char pad_320[0x64];
    bool bHasLandscapeGrass; // 0x384
    char pad_385[0x3];
    float StaticLightingResolution; // 0x388
    uint8_t CastShadow : 1; // 0x38c
    uint8_t bCastDynamicShadow : 1; // 0x38c
    uint8_t bCastStaticShadow : 1; // 0x38c
    uint8_t pad_bitfield_38c_3 : 5;
    char pad_38d[0x3];
    uint8_t bCastFarShadow : 1; // 0x390
    uint8_t pad_bitfield_390_1 : 7;
    char pad_391[0x3];
    uint8_t bCastHiddenShadow : 1; // 0x394
    uint8_t pad_bitfield_394_1 : 7;
    char pad_395[0x3];
    uint8_t bCastShadowAsTwoSided : 1; // 0x398
    uint8_t pad_bitfield_398_1 : 7;
    char pad_399[0x3];
    uint8_t bAffectDistanceFieldLighting : 1; // 0x39c
    uint8_t pad_bitfield_39c_1 : 7;
    FLightingChannels LightingChannels; // 0x39d
    char pad_39e[0x2];
    uint8_t bUseMaterialPositionOffsetInStaticLighting : 1; // 0x3a0
    uint8_t bRenderCustomDepth : 1; // 0x3a0
    uint8_t pad_bitfield_3a0_2 : 6;
    char pad_3a1[0x3];
    ERendererStencilMask CustomDepthStencilWriteMask; // 0x3a4
    char pad_3a5[0x3];
    int32_t CustomDepthStencilValue; // 0x3a8
    float LDMaxDrawDistance; // 0x3ac
    FLightmassPrimitiveSettings LightmassSettings; // 0x3b0
    int32_t CollisionMipLevel; // 0x3c8
    int32_t SimpleCollisionMipLevel; // 0x3cc
    float CollisionThickness; // 0x3d0
    char pad_3d4[0x4];
    FBodyInstance BodyInstance; // 0x3d8
    uint8_t bGenerateOverlapEvents : 1; // 0x530
    uint8_t bBakeMaterialPositionOffsetIntoCollision : 1; // 0x530
    uint8_t pad_bitfield_530_2 : 6;
    char pad_531[0x3];
    int32_t ComponentSizeQuads; // 0x534
    int32_t SubsectionSizeQuads; // 0x538
    int32_t NumSubsections; // 0x53c
    uint8_t bUsedForNavigation : 1; // 0x540
    uint8_t bFillCollisionUnderLandscapeForNavmesh : 1; // 0x540
    uint8_t pad_bitfield_540_2 : 6;
    char pad_541[0x3];
    bool bUseDynamicMaterialInstance; // 0x544
    ENavDataGatheringMode NavigationGeometryGatheringMode; // 0x545
    bool bUseLandscapeForCullingInvisibleHLODVertices; // 0x546
    bool bHasLayersContent; // 0x547
    char pad_548[0x50];
    static ALandscapeProxy* StaticClass();
    void SetLandscapeMaterialVectorParameterValue(FName ParameterName, FLinearColor Value);
    void SetLandscapeMaterialTextureParameterValue(FName ParameterName, UTexture* Value);
    void SetLandscapeMaterialScalarParameterValue(FName ParameterName, float Value);
    bool LandscapeExportHeightmapToRenderTarget(UTextureRenderTarget2D* InRenderTarget, bool InExportHeightIntoRGChannel, bool InExportLandscapeProxies);
    void EditorSetLandscapeMaterial(UMaterialInterface* NewLandscapeMaterial);
    void EditorApplySpline(USplineComponent* InSplineComponent, float StartWidth, float EndWidth, float StartSideFalloff, float EndSideFalloff, float StartRoll, float EndRoll, int32_t NumSubdivisions, bool bRaiseHeights, bool bLowerHeights, ULandscapeLayerInfoObject* PaintLayer, FName EditLayerName);
    void ChangeUseTessellationComponentScreenSizeFalloff(bool InComponentScreenSizeToUseSubSections);
    void ChangeTessellationComponentScreenSizeFalloff(float InUseTessellationComponentScreenSizeFalloff);
    void ChangeTessellationComponentScreenSize(float InTessellationComponentScreenSize);
    void ChangeLODDistanceFactor(float InLODDistanceFactor);
    void ChangeComponentScreenSizeToUseSubSections(float InComponentScreenSizeToUseSubSections);
}; // Size: 0x598
#pragma pack(pop)
