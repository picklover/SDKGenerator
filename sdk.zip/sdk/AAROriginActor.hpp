#pragma once
#include <cstdint>
#include "AActor.hpp"
#pragma pack(push, 1)
class AAROriginActor : public AActor {
public:
    static AAROriginActor* StaticClass();
}; // Size: 0x220
#pragma pack(pop)
