#pragma once
#include <cstdint>
#include "ASpectatorPawn.hpp"
#pragma pack(push, 1)
class AShooterSpectatorPawn : public ASpectatorPawn {
public:
    static AShooterSpectatorPawn* StaticClass();
}; // Size: 0x2a8
#pragma pack(pop)
