#include "AVolume.hpp"
#include "AVolumetricLightmapDensityVolume.hpp"
#include "FInt32Interval.hpp"
AVolumetricLightmapDensityVolume* AVolumetricLightmapDensityVolume::StaticClass() {
    static auto res = find_uobject(9847650656059885374); // Class /Script/Engine.VolumetricLightmapDensityVolume
    return (AVolumetricLightmapDensityVolume*)res;
}
