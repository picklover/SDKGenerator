#include "ALightmassCharacterIndirectDetailVolume.hpp"
#include "AVolume.hpp"
ALightmassCharacterIndirectDetailVolume* ALightmassCharacterIndirectDetailVolume::StaticClass() {
    static auto res = find_uobject(11318339944836081872); // Class /Script/Engine.LightmassCharacterIndirectDetailVolume
    return (ALightmassCharacterIndirectDetailVolume*)res;
}
