#pragma once
#include <cstdint>
#include "AGameStateBase.hpp"
#pragma pack(push, 1)
class AGameState : public AGameStateBase {
public:
    FName MatchState; // 0x270
    FName PreviousMatchState; // 0x278
    int32_t ElapsedTime; // 0x280
    char pad_284[0xc];
    static AGameState* StaticClass();
    void OnRep_MatchState();
    void OnRep_ElapsedTime();
}; // Size: 0x290
#pragma pack(pop)
