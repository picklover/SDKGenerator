#include "APlaneReflectionCapture.hpp"
#include "AReflectionCapture.hpp"
APlaneReflectionCapture* APlaneReflectionCapture::StaticClass() {
    static auto res = find_uobject(17667391959636808833); // Class /Script/Engine.PlaneReflectionCapture
    return (APlaneReflectionCapture*)res;
}
