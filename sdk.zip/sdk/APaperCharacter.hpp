#pragma once
#include <cstdint>
#include "ACharacter.hpp"
class UPaperFlipbookComponent;
#pragma pack(push, 1)
class APaperCharacter : public ACharacter {
public:
    static APaperCharacter* StaticClass();
}; // Size: 0x4c0
#pragma pack(pop)
