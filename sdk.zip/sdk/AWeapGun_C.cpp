#include "AShooterWeapon_Instant.hpp"
#include "AWeapGun_C.hpp"
AWeapGun_C* AWeapGun_C::StaticClass() {
    static auto res = find_uobject(6083699427294475608); // BlueprintGeneratedClass /Game/Blueprints/Weapons/WeapGun.WeapGun_C
    return (AWeapGun_C*)res;
}
