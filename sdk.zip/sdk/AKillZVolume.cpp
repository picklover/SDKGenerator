#include "AKillZVolume.hpp"
#include "APhysicsVolume.hpp"
AKillZVolume* AKillZVolume::StaticClass() {
    static auto res = find_uobject(365683842732273778); // Class /Script/Engine.KillZVolume
    return (AKillZVolume*)res;
}
