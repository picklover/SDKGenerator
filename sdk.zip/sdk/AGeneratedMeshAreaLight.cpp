#include "AGeneratedMeshAreaLight.hpp"
#include "ASpotLight.hpp"
AGeneratedMeshAreaLight* AGeneratedMeshAreaLight::StaticClass() {
    static auto res = find_uobject(9563844776639541097); // Class /Script/Engine.GeneratedMeshAreaLight
    return (AGeneratedMeshAreaLight*)res;
}
